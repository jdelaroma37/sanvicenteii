<?php
session_start();
require '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

header('Content-Type: application/json');

$request_id = $_POST['request_id'] ?? $_GET['request_id'] ?? '';

if (empty($request_id)) {
    echo json_encode(['status' => 'error', 'message' => 'Request ID is required']);
    exit;
}

// Load request data
$requests_dir = __DIR__ . '/../data/requests';
$request_data = null;
$found_file = null;

$files = glob("$requests_dir/*.json");
foreach ($files as $file) {
    $filename = basename($file);
    if ($filename === 'requests.json') {
        continue;
    }
    
    $content = json_decode(file_get_contents($file), true);
    if (!$content) continue;
    
    // Check if it's a user summary file
    if (preg_match('/^\d+_requests\.json$/', $filename) && is_array($content)) {
        foreach ($content as $req) {
            if (is_array($req) && isset($req['id']) && $req['id'] === $request_id) {
                $request_data = $req;
                $found_file = $file;
                break 2;
            }
        }
    } 
    // Check if it's an individual request file
    else if (is_array($content) && isset($content['id']) && $content['id'] === $request_id) {
        $request_data = $content;
        $found_file = $file;
        break;
    }
}

if (!$request_data) {
    echo json_encode(['status' => 'error', 'message' => 'Request not found']);
    exit;
}

// Load officials data
$officials_file = __DIR__ . '/../data/officials/officials.json';
$officials = [];
if (file_exists($officials_file)) {
    $officials = json_decode(file_get_contents($officials_file), true) ?? [];
}
if (!is_array($officials)) {
    $officials = [];
}

// Get Punong Barangay and Kagawads
$punong_barangay = null;
$kagawads = [];
foreach ($officials as $off) {
    if (($off['position'] ?? '') === 'Punong Barangay') {
        $punong_barangay = $off;
    } elseif (($off['position'] ?? '') === 'Kagawad') {
        $kagawads[] = $off;
    }
}

// Generate PDF using dompdf
require_once __DIR__ . '/../dompdf/vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$options = new Options();
$options->set('isRemoteEnabled', true);
$options->set('isHtml5ParserEnabled', true);

$dompdf = new Dompdf($options);

// Build HTML content for PDF
$fullname = htmlspecialchars($request_data['fullname'] ?? 'N/A');
$documentType = htmlspecialchars($request_data['documentType'] ?? 'N/A');
$dateRequested = htmlspecialchars($request_data['dateRequested'] ?? date('F d, Y h:i A'));
$otherDetails = $request_data['otherDetails'] ?? [];

// Generate clearance number
$clearance_no = date('Y') . '-' . str_pad(rand(1000, 9999), 4, '0', STR_PAD_LEFT);

// Extract details
$age = $otherDetails['age'] ?? '';
$gender = $otherDetails['gender'] ?? '';
$dob = $otherDetails['dob'] ?? '';
$civil_status = $otherDetails['civil_status'] ?? '';
$address = $otherDetails['address'] ?? '';
$purpose = $otherDetails['purpose'] ?? '';
$place_of_birth = $otherDetails['place_of_birth'] ?? 'Silang, Cavite';

// Format date
$current_date = date('F d, Y h:i A');
$pb_name = $punong_barangay ? htmlspecialchars($punong_barangay['name']) : 'Hon. Angelina S. Duguran';

// Logo path
$logo_path = __DIR__ . '/../images/logo.jpg';
$logo_base64 = '';
if (file_exists($logo_path)) {
    $logo_data = file_get_contents($logo_path);
    $logo_base64 = 'data:image/jpeg;base64,' . base64_encode($logo_data);
}

$html = <<<HTML
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        @page { margin: 18mm; }
        body {
            font-family: "Times New Roman", serif;
            margin: 0;
            padding: 0;
            color: #000;
            font-size: 11pt;
            line-height: 1.5;
        }
        .page {
            width: 100%;
            box-sizing: border-box;
        }
        .header-wrap {
            text-align: center;
            border-bottom: 2px solid #000;
            padding-bottom: 10px;
            margin-bottom: 14px;
        }
        .header-table {
            margin: 0 auto;
        }
        .logo-cell {
            width: 120px;
            text-align: center;
            vertical-align: middle;
        }
        .logo {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border: 2px solid #d4af37;
            border-radius: 50%;
        }
        .org-info {
            text-align: center;
            font-size: 11pt;
            line-height: 1.4;
        }
        .org-info .barangay { font-weight: bold; font-size: 12pt; }
        .title {
            text-align: center;
            font-size: 17pt;
            font-weight: bold;
            margin: 10px 0 6px 0;
            letter-spacing: 0.5px;
        }
        .meta {
            width: 100%;
            margin: 0 0 10px 0;
            font-size: 10.5pt;
        }
        .meta td { padding: 3px 0; }
        .label { font-weight: bold; padding-right: 6px; }
        .body-text { text-align: justify; margin: 12px 0; }
        .purpose { margin: 10px 0; }
        .record { text-align: center; font-weight: bold; margin: 16px 0 6px 0; }
        .reminder {
            margin-top: 14px;
            padding: 10px;
            border: 1px solid #000;
            font-size: 10pt;
            text-align: justify;
        }
        .signatures {
            width: 100%;
            margin-top: 40px;
            text-align: center;
        }
        .signatures td { width: 50%; vertical-align: bottom; }
        .sig-line {
            border-top: 1px solid #000;
            width: 200px;
            margin: 40px auto 6px auto;
        }
        .sig-name { font-weight: bold; }
        .officials {
            margin-top: 18px;
            font-size: 10pt;
        }
        .officials-title { font-weight: bold; margin-bottom: 4px; }
    </style>
</head>
<body>
    <div class="page">
        <div class="header-wrap">
            <table class="header-table" cellspacing="0" cellpadding="0">
                <tr>
                    <td class="logo-cell">
HTML;

if ($logo_base64) {
    $html .= '<img class="logo" src="' . $logo_base64 . '" alt="Barangay Logo">';
}

$html .= <<<HTML
                    </td>
                    <td class="org-info">
                        <div>Republic of the Philippines</div>
                        <div>Province of Cavite</div>
                        <div>Municipality of Silang</div>
                        <div class="barangay">Barangay San Vicente II</div>
                        <div>Brgy. San Vicente II, Silang, Cavite</div>
                    </td>
                </tr>
            </table>
        </div>

        <div class="title">{$documentType}</div>

        <table class="meta" cellspacing="0" cellpadding="0">
            <tr>
                <td class="label">Date:</td>
                <td>{$current_date}</td>
            </tr>
            <tr>
                <td class="label">Clearance No.:</td>
                <td>{$clearance_no}</td>
            </tr>
        </table>

        <div class="body-text">
            This is to certify that <strong>{$fullname}</strong>
HTML;

if ($civil_status && $gender && $dob) {
    $html .= " is a <strong>{$civil_status}, {$gender}</strong>, born on <strong>{$dob}</strong>";
    if ($place_of_birth) {
        $html .= " in <strong>" . htmlspecialchars($place_of_birth) . "</strong>";
    }
    $html .= ". ";
}

$html .= "is a bona fide resident of ";

if ($address) {
    $html .= "<strong>" . htmlspecialchars($address) . "</strong>, ";
}

$html .= "San Vicente II, Silang, Cavite. Upon verification of barangay records, the subject individual was found to have <strong>NO DEROGATORY RECORD</strong> on file.";

if ($purpose) {
    $html .= "</div><div class=\"purpose\">This certification is issued for the purpose of <strong>" . htmlspecialchars($purpose) . "</strong>.";
}

$html .= <<<HTML
        </div>

        <div class="record">Certified true and correct.</div>

        <div class="reminder">
            This {$documentType} is subject for cancellation for any violation of existing rules, regulations, and ordinances of this barangay. It is not valid without the official barangay seal and signature of the Punong Barangay.
        </div>

        <table class="signatures" cellspacing="0" cellpadding="0">
            <tr>
                <td>
                    <div class="sig-line"></div>
                    <div class="sig-name">Resident's Signature</div>
                </td>
                <td>
                    <div class="sig-line"></div>
                    <div class="sig-name">{$pb_name}</div>
                    <div>Punong Barangay</div>
                </td>
            </tr>
        </table>

    </div>
</body>
</html>
HTML;

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Generate unique filename
$pdf_filename = 'document_' . $request_id . '_' . time() . '.pdf';
$pdf_dir = __DIR__ . '/../data/generated_pdfs';
if (!is_dir($pdf_dir)) {
    mkdir($pdf_dir, 0777, true);
}

$pdf_path = $pdf_dir . '/' . $pdf_filename;
file_put_contents($pdf_path, $dompdf->output());

// Update request data with PDF filename
$request_data['pdf_name'] = $pdf_filename;

// Update the file
if (preg_match('/^\d+_requests\.json$/', basename($found_file))) {
    // Update in user summary file
    $all_requests = json_decode(file_get_contents($found_file), true);
    foreach ($all_requests as $index => $req) {
        if (isset($req['id']) && $req['id'] === $request_id) {
            $all_requests[$index] = $request_data;
            break;
        }
    }
    file_put_contents($found_file, json_encode($all_requests, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
} else {
    // Update individual file
    file_put_contents($found_file, json_encode($request_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

echo json_encode([
    'status' => 'success',
    'message' => 'PDF generated successfully',
    'pdf_name' => $pdf_filename,
    'pdf_url' => '../data/generated_pdfs/' . $pdf_filename
]);
?>

