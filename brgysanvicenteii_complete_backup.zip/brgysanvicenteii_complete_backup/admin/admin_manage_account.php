<?php
// admin/admin_manage_account.php
session_start();
require '../config.php';
require_once __DIR__ . '/../lang/language_helper.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin_role_data = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin_role_data['role']) ? $admin_role_data['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Get admin info
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    session_destroy();
    header('Location: admin_login.php');
    exit;
}

// Get admin username/user_id (unique encrypted/scrambled identifier)
$user_id = $admin['id'] ?? 0;
if ($user_id > 0) {
    // Create unique encrypted identifier using admin ID, email, and created_at
    $unique_string = $user_id . '_' . ($admin['email'] ?? '') . '_' . ($admin['created_at'] ?? date('Y-m-d H:i:s'));
    // Generate hash and take first 12 characters for readable format
    $hash = hash('sha256', $unique_string);
    // Create scrambled format: first 4 chars + next 4 chars (uppercase)
    $scrambled = strtoupper(substr($hash, 0, 4) . '-' . substr($hash, 8, 4));
    $username = 'ADM-' . $scrambled;
} else {
    $username = 'N/A';
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_personal') {
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        
        if (!$full_name) {
            $error = 'Full name is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = 'Invalid email address.';
        } else {
            // Check if email is already taken by another admin
            $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ? AND id != ?");
            $stmt->execute([$email, $admin_id]);
            if ($stmt->fetch()) {
                $error = 'Email already taken by another admin.';
            } else {
                $stmt = $pdo->prepare("UPDATE admins SET full_name = ?, email = ? WHERE id = ?");
                $stmt->execute([$full_name, $email, $admin_id]);
                $success = 'Personal information updated successfully!';
                
                // Log activity
                try {
                    $stmt = $pdo->prepare("INSERT INTO activity_log (admin_id, action_type, table_name, record_id, description) VALUES (?, 'UPDATE', 'admins', ?, ?)");
                    $stmt->execute([$admin_id, $admin_id, "Updated personal information"]);
                } catch (Exception $e) {
                    // Activity log might not exist, ignore
                }
                
                // Refresh admin data
                $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
            }
        }
    } elseif ($action === 'update_password') {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($current_password)) {
            $error = 'Current password is required.';
        } elseif (!password_verify($current_password, $admin['password'])) {
            $error = 'Current password is incorrect.';
        } elseif (strlen($new_password) < 6) {
            $error = 'New password must be at least 6 characters.';
        } elseif ($new_password !== $confirm_password) {
            $error = 'New passwords do not match.';
        } else {
            $hash = password_hash(trim($new_password), PASSWORD_DEFAULT);
            if ($hash === false) {
                $error = 'Failed to hash password. Please try again.';
            } else {
                $stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE id = ?");
                $stmt->execute([$hash, $admin_id]);
                $success = 'Password updated successfully!';
                
                // Log activity
                try {
                    $stmt = $pdo->prepare("INSERT INTO activity_log (admin_id, action_type, table_name, record_id, description) VALUES (?, 'UPDATE', 'admins', ?, ?)");
                    $stmt->execute([$admin_id, $admin_id, "Changed password"]);
                } catch (Exception $e) {
                    // Activity log might not exist, ignore
                }
                
                // Create admin notification (super admin only)
                if (file_exists(__DIR__ . '/admin_notification_helper.php')) {
                    require_once __DIR__ . '/admin_notification_helper.php';
                    $admin_name = $admin['full_name'] ?? $admin['email'] ?? 'Admin';
                    createAdminNotification(
                        'password_changed',
                        'Password Changed',
                        "Password has been changed for admin: {$admin_name}",
                        'super_admin',
                        [
                            'admin_id' => $admin_id,
                            'admin_name' => $admin_name,
                            'admin_email' => $admin['email'] ?? ''
                        ]
                    );
                }
            }
        }
    } elseif ($action === 'toggle_2fa') {
        // Toggle 2FA (for future implementation)
        $two_fa_enabled = isset($_POST['two_fa_enabled']) ? 1 : 0;
        try {
            // Check if column exists, if not we'll skip
            $stmt = $pdo->prepare("UPDATE admins SET two_fa_enabled = ? WHERE id = ?");
            $stmt->execute([$two_fa_enabled, $admin_id]);
            $success = $two_fa_enabled ? 'Two-Factor Authentication enabled.' : 'Two-Factor Authentication disabled.';
        } catch (Exception $e) {
            // Column might not exist, that's okay
            $error = '2FA feature is not yet available.';
        }
    } elseif ($action === 'toggle_account_status') {
        // Only super admin can toggle their own account status
        if ($admin_role === 'super_admin') {
            $status = $_POST['status'] ?? 'active';
            $stmt = $pdo->prepare("UPDATE admins SET status = ? WHERE id = ?");
            $stmt->execute([$status, $admin_id]);
            $success = 'Account status updated successfully!';
        }
    } elseif ($action === 'logout_other_sessions') {
        // For future implementation - session management
        $success = 'Other sessions will be logged out. (Feature coming soon)';
    } elseif ($action === 'update_language') {
        $selected_lang = $_POST['lang'] ?? '';
        $available = lang_available_languages();
        if (!array_key_exists($selected_lang, $available)) {
            $error = trans('language_select_error');
        } else {
            lang_set_language($selected_lang, true);
            $current_lang = lang_current_language();
            $success = trans('language_update_success');
        }
    }
}

// Get activity logs for this admin
$activity_logs = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM activity_log WHERE admin_id = ? ORDER BY created_at DESC LIMIT 10");
    $stmt->execute([$admin_id]);
    $activity_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Table might not exist
}

// Get login history (using last_login and activity logs)
$login_history = [];
if (!empty($admin['last_login'])) {
    $login_history[] = [
        'date' => $admin['last_login'],
        'ip' => getRealIPAddress(),
        'status' => 'Success'
    ];
}

// Function to get real IP address (works for both localhost and production)
function getRealIPAddress() {
    // Check for IP from proxy/load balancer first
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
        // Validate IP
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return $ip;
        }
    }
    
    // Check other proxy headers
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return $ip;
        }
    }
    
    // Fallback to REMOTE_ADDR
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    
    // Handle localhost addresses
    if ($ip === '::1' || $ip === '::ffff:127.0.0.1') {
        return '127.0.0.1 (Localhost)';
    } elseif ($ip === '127.0.0.1') {
        return '127.0.0.1 (Localhost)';
    }
    
    return $ip;
}

// Get IP address
$ip_address = getRealIPAddress();

// Format dates
$created_at = !empty($admin['created_at']) ? date('F d, Y h:i A', strtotime($admin['created_at'])) : 'N/A';
$last_login = !empty($admin['last_login']) ? date('F d, Y h:i A', strtotime($admin['last_login'])) : 'Never';

// Get account status
$account_status = $admin['status'] ?? 'active';
$role_display = ucwords(str_replace('_', ' ', $admin['role'] ?? 'regular_admin'));
$current_lang = lang_current_language();
$language_options = lang_available_languages();
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($current_lang); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars(trans('manage_account_page_title', 'Manage Account - Barangay San Vicente II')); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar CSS - Same as dashboard */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: none;
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        .page-header {
            margin-bottom: 20px;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 10px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-subtitle {
            color: #6b7280;
            font-size: 18px;
            font-weight: 600;
            margin-left: 36px;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Section Cards */
        .section-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }
        .section-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .section-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .section-header svg {
            width: 24px;
            height: 24px;
            color: #2c3e2d;
            opacity: 0.6;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            letter-spacing: -0.3px;
        }
        .section-subtitle {
            font-size: 18px;
            color: #6b7280;
            margin-top: 4px;
            font-weight: 600;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 700;
            font-size: 16px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .form-group input[readonly] {
            background: #f0f0f0;
            cursor: not-allowed;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }
        .language-options {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
        }
        .language-option {
            flex: 1;
            min-width: 220px;
            border: 2px solid transparent;
            border-radius: 12px;
            padding: 16px;
            background: rgba(255, 255, 255, 0.6);
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
            overflow: hidden;
        }
        .language-option input {
            position: absolute;
            inset: 0;
            width: 100%;
            height: 100%;
            margin: 0;
            opacity: 0;
            cursor: pointer;
        }
        .language-option.active {
            border-color: #2c3e2d;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            background: white;
        }
        .language-option span {
            display: block;
            font-weight: 700;
            color: #2c3e2d;
            font-size: 18px;
        }
        .language-option small {
            display: block;
            margin-top: 6px;
            color: #6b7280;
            font-size: 13px;
        }
        .language-note {
            font-size: 13px;
            color: #555;
            margin-bottom: 15px;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }
        .password-strength {
            margin-top: 8px;
            height: 4px;
            background: #e0e0e0;
            border-radius: 2px;
            overflow: hidden;
        }
        .password-strength-bar {
            height: 100%;
            transition: all 0.3s;
            border-radius: 2px;
        }
        .password-strength-weak { background: #c33; width: 33%; }
        .password-strength-medium { background: #d4af37; width: 66%; }
        .password-strength-strong { background: #3c3; width: 100%; }
        .password-strength-text {
            font-size: 12px;
            color: #666;
            margin-top: 4px;
        }
        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #2c3e2d;
            color: white;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .btn-secondary {
            background: #d4af37;
            color: white;
        }
        .btn-secondary:hover {
            background: #e6c55a;
            transform: translateY(-2px);
        }
        .btn-danger {
            background: #c33;
            color: white;
        }
        .btn-danger:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .toggle-switch {
            position: relative;
            display: inline-block;
            width: 50px;
            height: 26px;
        }
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 26px;
        }
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 20px;
            width: 20px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        input:checked + .toggle-slider {
            background-color: #1a5f3f;
        }
        input:checked + .toggle-slider:before {
            transform: translateX(24px);
        }
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 700;
            color: #2c3e2d;
            font-size: 16px;
        }
        .info-value {
            color: #6b7280;
            font-size: 16px;
            font-weight: 500;
            text-align: right;
        }
        .badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        .badge-success {
            background: #efe;
            color: #3c3;
        }
        .badge-warning {
            background: #ffe;
            color: #d4af37;
        }
        .badge-danger {
            background: #fee;
            color: #c33;
        }
        .badge-info {
            background: #eef;
            color: #1a5f3f;
        }
        .activity-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .activity-item {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: start;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .activity-details {
            flex: 1;
        }
        .activity-action {
            font-weight: 700;
            color: #2c3e2d;
            font-size: 16px;
        }
        .activity-description {
            color: #6b7280;
            font-size: 16px;
            font-weight: 500;
            margin-top: 4px;
        }
        .activity-date {
            color: #6b7280;
            font-size: 14px;
            font-weight: 500;
            white-space: nowrap;
            margin-left: 15px;
        }
        .login-history-item {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .login-history-item:last-child {
            border-bottom: none;
        }
        .login-info {
            flex: 1;
        }
        .login-date {
            font-weight: 700;
            color: #2c3e2d;
            font-size: 16px;
        }
        .login-ip {
            color: #6b7280;
            font-size: 14px;
            font-weight: 500;
            margin-top: 4px;
            font-family: monospace;
        }
        .login-status {
            margin-left: 15px;
        }
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        .empty-state svg {
            width: 48px;
            height: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <span class="page-title-bar"></span>
                <span class="page-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                    </svg>
                </span>
                Manage Account
            </h1>
            <p class="page-subtitle">Manage your personal information, security settings, and account preferences</p>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- 1. Personal Information -->
        <div class="section-card">
            <div class="section-header">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8" cy="5" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M3 13.5c0-2 2-3.5 5-3.5s5 1.5 5 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <div>
                    <div class="section-title">Personal Information</div>
                    <div class="section-subtitle">Update your name and email address</div>
                </div>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="action" value="update_personal">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($admin['full_name'] ?? ''); ?>" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="username">Username / User ID</label>
                        <input type="text" id="username" value="<?php echo htmlspecialchars($username); ?>" readonly style="font-family: 'Courier New', monospace; font-weight: 600; letter-spacing: 1px; color: #1a5f3f;">
                        <small style="color: #999; font-size: 12px; margin-top: 4px; display: block;">Admin User ID - Cannot be changed</small>
                    </div>
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin['email'] ?? ''); ?>" required>
                        <small style="color: #999; font-size: 12px; margin-top: 4px; display: block;">For notifications and password recovery</small>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 3l-8 8M5 3h8v8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Save Changes
                </button>
            </form>
        </div>

        <!-- Language & Localization -->
        <div class="section-card">
            <div class="section-header">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M4.5 6h7M4.5 10h7" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <div>
                    <div class="section-title"><?php echo htmlspecialchars(trans('language_settings_title')); ?></div>
                    <div class="section-subtitle"><?php echo htmlspecialchars(trans('language_settings_subtitle')); ?></div>
                </div>
            </div>
            <form method="POST" action="">
                <input type="hidden" name="action" value="update_language">
                <div class="language-options">
                    <?php foreach ($language_options as $code => $label): ?>
                        <?php 
                            $is_active = $current_lang === $code; 
                            $input_id = 'language_option_' . $code;
                        ?>
                        <label class="language-option <?php echo $is_active ? 'active' : ''; ?>" for="<?php echo htmlspecialchars($input_id); ?>">
                            <input type="radio" id="<?php echo htmlspecialchars($input_id); ?>" name="lang" value="<?php echo htmlspecialchars($code); ?>" <?php echo $is_active ? 'checked' : ''; ?>>
                            <span><?php echo htmlspecialchars(lang_language_label($code)); ?></span>
                            <small><?php echo htmlspecialchars($is_active ? trans('language_option_active_hint') : trans('language_option_inactive_hint')); ?></small>
                        </label>
                    <?php endforeach; ?>
                </div>
                <p class="language-note"><?php echo htmlspecialchars(trans('language_settings_note')); ?></p>
                <button type="submit" class="btn btn-secondary">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 3l-8 8M5 3h8v8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <?php echo htmlspecialchars(trans('language_apply_button')); ?>
                </button>
            </form>
        </div>

        <!-- 2. Password Management -->
        <div class="section-card">
            <div class="section-header">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="3" y="7" width="10" height="6" rx="1" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M5 7V5a3 3 0 0 1 6 0v2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <div>
                    <div class="section-title">Password Management</div>
                    <div class="section-subtitle">Change your account password</div>
                </div>
            </div>
            <form method="POST" action="" id="passwordForm">
                <input type="hidden" name="action" value="update_password">
                <div class="form-group">
                    <label for="current_password">Current Password</label>
                    <input type="password" id="current_password" name="current_password" autocomplete="current-password" required>
                </div>
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <input type="password" id="new_password" name="new_password" autocomplete="new-password" required>
                    <div class="password-strength" id="passwordStrength">
                        <div class="password-strength-bar" id="passwordStrengthBar"></div>
                    </div>
                    <div class="password-strength-text" id="passwordStrengthText">Enter a password to check strength</div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm New Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" autocomplete="new-password" required>
                </div>
                <button type="submit" class="btn btn-primary">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M13 3l-8 8M5 3h8v8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Update Password
                </button>
            </form>
        </div>

        <!-- 3. Security Settings -->
        <div class="section-card">
            <div class="section-header">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="2" y="6" width="12" height="8" rx="1" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M4 6V4a4 4 0 0 1 8 0v2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <circle cx="8" cy="10" r="1" fill="currentColor"/>
                </svg>
                <div>
                    <div class="section-title">Security Settings</div>
                    <div class="section-subtitle">Manage your account security and authentication</div>
                </div>
            </div>
            
            <div class="form-group">
                <label style="display: flex; align-items: center; justify-content: space-between;">
                    <span>Two-Factor Authentication (2FA)</span>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="toggle_2fa">
                        <label class="toggle-switch">
                            <input type="checkbox" name="two_fa_enabled" onchange="this.form.submit()">
                            <span class="toggle-slider"></span>
                        </label>
                    </form>
                </label>
                <small style="color: #999; font-size: 12px; margin-top: 4px; display: block;">Optional: Add an extra layer of security to your account</small>
            </div>

            <div class="form-group">
                <label>Security Questions</label>
                <small style="color: #999; font-size: 12px; margin-top: 4px; display: block;">Optional: Set up security questions for account recovery (Coming soon)</small>
            </div>

            <div class="info-item">
                <span class="info-label">Last Login</span>
                <span class="info-value"><?php echo htmlspecialchars($last_login); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">IP Address</span>
                <span class="info-value" style="font-family: monospace;"><?php echo htmlspecialchars($ip_address); ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Active Sessions</span>
                <span class="info-value">
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="logout_other_sessions">
                        <button type="submit" class="btn btn-secondary" style="padding: 6px 12px; font-size: 12px;">Log Out Other Sessions</button>
                    </form>
                </span>
            </div>
        </div>

        <!-- 4. Account Status -->
        <div class="section-card">
            <div class="section-header">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M8 4v4l3 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <div>
                    <div class="section-title">Account Status</div>
                    <div class="section-subtitle">View your account information and status</div>
                </div>
            </div>
            
            <?php if ($admin_role === 'super_admin'): ?>
            <div class="form-group">
                <label style="display: flex; align-items: center; justify-content: space-between;">
                    <span>Account Status</span>
                    <form method="POST" action="" style="display: inline;">
                        <input type="hidden" name="action" value="toggle_account_status">
                        <input type="hidden" name="status" value="<?php echo $account_status === 'active' ? 'inactive' : 'active'; ?>">
                        <label class="toggle-switch">
                            <input type="checkbox" <?php echo $account_status === 'active' ? 'checked' : ''; ?> onchange="this.form.submit()">
                            <span class="toggle-slider"></span>
                        </label>
                    </form>
                </label>
                <small style="color: #999; font-size: 12px; margin-top: 4px; display: block;">Toggle account active/inactive (for emergency lockout)</small>
            </div>
            <?php endif; ?>

            <div class="info-item">
                <span class="info-label">Role</span>
                <span class="info-value">
                    <span class="badge badge-info"><?php echo htmlspecialchars($role_display); ?></span>
                </span>
            </div>
            <div class="info-item">
                <span class="info-label">Account Status</span>
                <span class="info-value">
                    <span class="badge <?php echo $account_status === 'active' ? 'badge-success' : 'badge-danger'; ?>">
                        <?php echo ucfirst($account_status); ?>
                    </span>
                </span>
            </div>
            <div class="info-item">
                <span class="info-label">Date Account Created</span>
                <span class="info-value"><?php echo htmlspecialchars($created_at); ?></span>
            </div>
        </div>

        <!-- 5. Audit / Activity Logs -->
        <div class="section-card">
            <div class="section-header">
                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="3" y="3" width="10" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M6 7h4M6 10h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <div>
                    <div class="section-title">Activity Logs</div>
                    <div class="section-subtitle">Recent actions performed by this account</div>
                </div>
            </div>
            
            <div class="activity-list">
                <?php if (empty($activity_logs)): ?>
                    <div class="empty-state">
                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="3" y="3" width="10" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M6 7h4M6 10h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        <p>No activity logs available</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($activity_logs as $log): ?>
                        <div class="activity-item">
                            <div class="activity-details">
                                <div class="activity-action"><?php echo htmlspecialchars($log['action_type'] ?? 'Action'); ?></div>
                                <div class="activity-description"><?php echo htmlspecialchars($log['description'] ?? 'No description'); ?></div>
                            </div>
                            <div class="activity-date">
                                <?php echo !empty($log['created_at']) ? date('M d, Y h:i A', strtotime($log['created_at'])) : 'N/A'; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div style="margin-top: 20px; padding-top: 20px; border-top: 2px solid #e0e0e0;">
                <h3 style="font-size: 16px; color: #1a5f3f; margin-bottom: 15px;">Login History</h3>
                <div>
                    <?php if (empty($login_history)): ?>
                        <div class="empty-state" style="padding: 20px;">
                            <p>No login history available</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($login_history as $login): ?>
                            <div class="login-history-item">
                                <div class="login-info">
                                    <div class="login-date"><?php echo date('F d, Y h:i A', strtotime($login['date'])); ?></div>
                                    <div class="login-ip">IP: <?php echo htmlspecialchars($login['ip']); ?></div>
                                </div>
                                <div class="login-status">
                                    <span class="badge badge-success"><?php echo htmlspecialchars($login['status']); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Password strength indicator
        const passwordInput = document.getElementById('new_password');
        const strengthBar = document.getElementById('passwordStrengthBar');
        const strengthText = document.getElementById('passwordStrengthText');

        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            let text = 'Enter a password to check strength';
            let className = '';

            if (password.length > 0) {
                if (password.length >= 6) strength++;
                if (password.length >= 8) strength++;
                if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
                if (/[0-9]/.test(password)) strength++;
                if (/[^a-zA-Z0-9]/.test(password)) strength++;

                if (strength <= 2) {
                    text = 'Weak password';
                    className = 'password-strength-weak';
                } else if (strength <= 3) {
                    text = 'Medium password';
                    className = 'password-strength-medium';
                } else {
                    text = 'Strong password';
                    className = 'password-strength-strong';
                }
            }

            strengthBar.className = 'password-strength-bar ' + className;
            strengthText.textContent = text;
        });

        // Password confirmation validation
        const confirmPasswordInput = document.getElementById('confirm_password');
        const passwordForm = document.getElementById('passwordForm');

        passwordForm.addEventListener('submit', function(e) {
            const password = passwordInput.value;
            const confirmPassword = confirmPasswordInput.value;

            if (password !== confirmPassword) {
                e.preventDefault();
                alert('New passwords do not match!');
                return false;
            }

            if (password.length < 6) {
                e.preventDefault();
                alert('Password must be at least 6 characters long!');
                return false;
            }
        });

        // Language toggle visual feedback
        const languageInputs = document.querySelectorAll('.language-options input[name="lang"]');
        languageInputs.forEach((input) => {
            input.addEventListener('change', function() {
                document.querySelectorAll('.language-option').forEach((option) => option.classList.remove('active'));
                const parent = this.closest('.language-option');
                if (parent) {
                    parent.classList.add('active');
                }
            });
        });
    </script>
</body>
</html>
