<?php
// admin/admin_programs_events.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

$programs_file = __DIR__ . '/../data/programs_events.json';

// Load programs and events
$programs = [];
if (file_exists($programs_file)) {
    $programs = json_decode(file_get_contents($programs_file), true) ?? [];
}
if (!is_array($programs)) {
    $programs = [];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'edit') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $type = trim($_POST['type'] ?? 'Program');
        $location = trim($_POST['location'] ?? '');
        $start_date = trim($_POST['start_date'] ?? date('Y-m-d'));
        $end_date = trim($_POST['end_date'] ?? date('Y-m-d'));
        $start_time = trim($_POST['start_time'] ?? '');
        $end_time = trim($_POST['end_time'] ?? '');
        
        if (!$title || !$description) {
            $_SESSION['error'] = 'Title and description are required.';
            header('Location: admin_programs_events.php');
            exit;
        }
        
        // Handle image upload
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/../uploads/programs/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (in_array($file_ext, $allowed_ext)) {
                $new_filename = 'program_' . time() . '_' . uniqid() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $image_path = 'uploads/programs/' . $new_filename;
                }
            }
        }
        
        if ($action === 'create') {
            $new_program = [
                'id' => uniqid('prog_'),
                'title' => $title,
                'description' => $description,
                'type' => $type,
                'location' => $location,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'start_time' => $start_time,
                'end_time' => $end_time,
                'image' => $image_path,
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $admin_id
            ];
            $programs[] = $new_program;
            $success = 'Program/Event created successfully!';
        } else {
            // Edit existing
            $id = $_POST['id'] ?? '';
            $found = false;
            foreach ($programs as &$prog) {
                if (isset($prog['id']) && $prog['id'] === $id) {
                    $prog['title'] = $title;
                    $prog['description'] = $description;
                    $prog['type'] = $type;
                    $prog['location'] = $location;
                    $prog['start_date'] = $start_date;
                    $prog['end_date'] = $end_date;
                    $prog['start_time'] = $start_time;
                    $prog['end_time'] = $end_time;
                    if ($image_path) {
                        if (!empty($prog['image']) && file_exists(__DIR__ . '/../' . $prog['image'])) {
                            unlink(__DIR__ . '/../' . $prog['image']);
                        }
                        $prog['image'] = $image_path;
                    }
                    $prog['updated_at'] = date('Y-m-d H:i:s');
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $success = 'Program/Event updated successfully!';
            } else {
                $_SESSION['error'] = 'Program/Event not found.';
                header('Location: admin_programs_events.php');
                exit;
            }
        }
        
        file_put_contents($programs_file, json_encode($programs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $_SESSION['success'] = $success;
        header('Location: admin_programs_events.php');
        exit;
    } elseif ($action === 'delete') {
        $id = $_POST['id'] ?? '';
        $found = false;
        foreach ($programs as $key => $prog) {
            if (isset($prog['id']) && $prog['id'] === $id) {
                if (!empty($prog['image']) && file_exists(__DIR__ . '/../' . $prog['image'])) {
                    unlink(__DIR__ . '/../' . $prog['image']);
                }
                unset($programs[$key]);
                $programs = array_values($programs);
                $found = true;
                break;
            }
        }
        if ($found) {
            file_put_contents($programs_file, json_encode($programs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['success'] = 'Program/Event deleted successfully!';
        } else {
            $_SESSION['error'] = 'Program/Event not found.';
        }
        header('Location: admin_programs_events.php');
        exit;
    }
}

// Sort by start date
usort($programs, function($a, $b) {
    $dateA = $a['start_date'] ?? $a['created_at'] ?? '';
    $dateB = $b['start_date'] ?? $b['created_at'] ?? '';
    if ($dateA && $dateB) {
        return strcmp($dateA, $dateB);
    }
    return strcmp($a['created_at'] ?? '', $b['created_at'] ?? '');
});

// Group by type
$grouped_programs = [];
foreach ($programs as $prog) {
    $type = $prog['type'] ?? 'Program';
    if (!isset($grouped_programs[$type])) {
        $grouped_programs[$type] = [];
    }
    $grouped_programs[$type][] = $prog;
}

$types = ['Program', 'Event', 'Activity', 'Workshop', 'Seminar'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Programs and Events - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        /* Quick reminders (soft blue cards) */
        .quick-reminders {
            background: #eef5fb;
            border: 1px solid rgba(44, 95, 141, 0.12);
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 6px 20px rgba(44, 95, 141, 0.08);
            margin-bottom: 24px;
        }
        .quick-reminders h3 {
            margin: 0 0 4px 0;
            font-size: 22px;
            font-weight: 800;
            color: #1a3a52;
        }
        .quick-reminders p.sub {
            margin: 0 0 14px 0;
            font-size: 14px;
            color: #5a6c7d;
            font-weight: 600;
        }
        .quick-programs-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .quick-program-card {
            background: #f5f9fd;
            border: 1px solid rgba(44, 95, 141, 0.12);
            border-radius: 16px;
            padding: 14px;
            box-shadow: 0 4px 14px rgba(44, 95, 141, 0.08);
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 10px;
            align-items: center;
        }
        .quick-program-icon {
            width: 38px;
            height: 38px;
            border-radius: 12px;
            background: rgba(44, 95, 141, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
        }
        .quick-program-body h4 {
            margin: 0 0 2px 0;
            font-size: 15px;
            font-weight: 800;
            color: #1a3a52;
        }
        .quick-program-body p {
            margin: 0;
            font-size: 13px;
            font-weight: 600;
            color: #5a6c7d;
        }
        .quick-program-dots {
            display: flex;
            gap: 4px;
        }
        .quick-program-dots span {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(44, 95, 141, 0.35);
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .page-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-secondary,
        .page-actions .btn-secondary {
            background: #4b5563 !important;
            color: white !important;
        }
        .btn-secondary:hover,
        .page-actions .btn-secondary:hover {
            background: #374151 !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(75, 85, 99, 0.3);
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .btn-primary {
            padding: 12px 24px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .error, .success {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        .error {
            background: #fee;
            color: #c33;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            border-left: 3px solid #3c3;
        }
        .programs-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }
        .program-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: all 0.3s;
            border-left: 4px solid #d4af37;
        }
        .program-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .program-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f0f0f0;
        }
        .program-body {
            padding: 20px;
        }
        .program-type {
            display: inline-block;
            padding: 4px 12px;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            margin-bottom: 12px;
        }
        .program-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a5f3f;
            margin-bottom: 10px;
        }
        .program-description {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 15px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .program-info {
            font-size: 13px;
            color: #999;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .program-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .btn-edit, .btn-delete {
            flex: 1;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        .btn-edit {
            background: #d4af37;
            color: white;
        }
        .btn-edit:hover {
            background: #e6c55a;
            transform: translateY(-2px);
        }
        .btn-delete {
            background: #c33;
            color: white;
        }
        .btn-delete:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .category-section {
            margin-bottom: 40px;
        }
        .category-header {
            font-size: 22px;
            color: #1a5f3f;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid #d4af37;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .category-count {
            font-size: 14px;
            color: #666;
            font-weight: 500;
            background: rgba(212, 175, 55, 0.1);
            padding: 4px 12px;
            border-radius: 12px;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        /* Modal styles - similar to announcement management */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 35px;
            width: 100%;
            max-width: 750px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            border-left: 4px solid #d4af37;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }
        .modal-header h2 {
            font-size: 24px;
            color: #1a5f3f;
            font-weight: 700;
        }
        .close-modal {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 24px;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #1a5f3f;
            font-weight: 600;
            font-size: 14px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel, .btn-submit {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel {
            background: #e0e0e0;
            color: #333;
        }
        .btn-submit {
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
        }
        @media (max-width: 1024px) {
            .programs-grid {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php 
    if (!isset($admin_role)) {
        $admin_id = $_SESSION['user_id'] ?? 0;
        if (isset($_SESSION['admin_role'])) {
            $admin_role = $_SESSION['admin_role'];
        } elseif (isset($pdo) && $admin_id) {
            try {
                $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
                $_SESSION['admin_role'] = $admin_role;
            } catch (Exception $e) {
                $admin_role = 'regular_admin';
            }
        } else {
            $admin_role = 'regular_admin';
        }
    }
    include 'admin_dashboard_sidebar.php'; 
    ?>

    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                </svg>
            </span>
            Programs and Events
        </h1>

        <div class="page-actions">
            <a href="admin_announcement_management.php" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Announcement Management
            </a>
        </div>

        <!-- Quick Programs & Reminders -->
        <div class="quick-reminders">
            <h3>Programs & Reminders</h3>
            <p class="sub">Stay updated with regular schedules and advisories.</p>
            <div class="quick-programs-list">
                <div class="quick-program-card">
                    <div class="quick-program-icon">🗓</div>
                    <div class="quick-program-body">
                        <h4>Garbage Collection</h4>
                        <p>Tue - Fri - Sun at 7:00 AM</p>
                    </div>
                    <div class="quick-program-dots"><span></span><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="quick-program-card">
                    <div class="quick-program-icon">🔔</div>
                    <div class="quick-program-body">
                        <h4>Curfew Advisory</h4>
                        <p>Observe local curfew hours for minors.</p>
                    </div>
                    <div class="quick-program-dots"><span></span><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="quick-program-card">
                    <div class="quick-program-icon">♻️</div>
                    <div class="quick-program-body">
                        <h4>No Burning of Trash</h4>
                        <p>Avoid open burning. Violations may be penalized.</p>
                    </div>
                    <div class="quick-program-dots"><span></span><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="quick-program-card">
                    <div class="quick-program-icon">🧹</div>
                    <div class="quick-program-body">
                        <h4>Clean-Up Drive</h4>
                        <p>Join our monthly barangay clean-up event.</p>
                    </div>
                    <div class="quick-program-dots"><span></span><span></span><span></span><span></span><span></span></div>
                </div>
                <div class="quick-program-card">
                    <div class="quick-program-icon">🪪</div>
                    <div class="quick-program-body">
                        <h4>Barangay Clearance Reminder</h4>
                        <p>Bring valid ID & proof of residency.</p>
                    </div>
                    <div class="quick-program-dots"><span></span><span></span><span></span><span></span><span></span></div>
                </div>
            </div>
        </div>

        <div style="display: flex; justify-content: flex-end; margin-bottom: 30px;">
            <button class="btn-primary" onclick="openCreateModal()">Create Program/Event</button>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="row-container">
            <?php if (empty($programs)): ?>
                <div class="empty-state">
                    <h3>No Programs/Events Yet</h3>
                    <p>Create your first program or event to keep residents informed.</p>
                </div>
            <?php else: ?>
                <?php foreach ($grouped_programs as $type => $type_programs): ?>
                <div class="category-section">
                    <h2 class="category-header">
                        <?php echo htmlspecialchars($type); ?> 
                        <span class="category-count"><?php echo count($type_programs); ?></span>
                    </h2>
                    <div class="programs-grid">
                        <?php foreach ($type_programs as $prog): ?>
                            <div class="program-card">
                                <?php if (!empty($prog['image']) && file_exists(__DIR__ . '/../' . $prog['image'])): ?>
                                    <img src="../<?php echo htmlspecialchars($prog['image']); ?>" alt="<?php echo htmlspecialchars($prog['title']); ?>" class="program-image">
                                <?php endif; ?>
                                <div class="program-body">
                                    <span class="program-type"><?php echo htmlspecialchars($prog['type'] ?? 'Program'); ?></span>
                                    <h3 class="program-title"><?php echo htmlspecialchars($prog['title']); ?></h3>
                                    <p class="program-description"><?php echo htmlspecialchars($prog['description']); ?></p>
                                    <?php if (!empty($prog['location'])): ?>
                                        <div class="program-info">
                                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                                <path d="M8 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" stroke="currentColor" stroke-width="1.5"/>
                                                <path d="M8 2C5.5 2 3.5 4 3.5 6.5c0 3 4.5 7.5 4.5 7.5s4.5-4.5 4.5-7.5C12.5 4 10.5 2 8 2z" stroke="currentColor" stroke-width="1.5"/>
                                            </svg>
                                            <?php echo htmlspecialchars($prog['location']); ?>
                                        </div>
                                    <?php endif; ?>
                                    <div class="program-info">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                            <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                            <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5"/>
                                        </svg>
                                        <?php 
                                        $start_date = $prog['start_date'] ?? '';
                                        if ($start_date) {
                                            echo date('F d, Y', strtotime($start_date));
                                        }
                                        if (!empty($prog['start_time'])) {
                                            echo ' at ' . date('g:i A', strtotime($prog['start_time']));
                                        }
                                        ?>
                                    </div>
                                    <div class="program-actions">
                                        <button class="btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($prog)); ?>)">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                                                <path d="M11 2l3 3M9 8l3 3M3 12l5-5M2 11l8-8" stroke="currentColor" stroke-width="1.5"/>
                                            </svg>
                                            Edit
                                        </button>
                                        <button class="btn-delete" onclick="deleteProgram('<?php echo htmlspecialchars($prog['id']); ?>')">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                                                <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5"/>
                                            </svg>
                                            Delete
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Create/Edit Modal -->
    <div id="programModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Create Program/Event</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <form id="programForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="programId">
                
                <div class="form-group">
                    <label for="title">Title *</label>
                    <input type="text" id="title" name="title" required>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="type">Type *</label>
                        <select id="type" name="type" required>
                            <?php foreach ($types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($type); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="location">Location</label>
                        <input type="text" id="location" name="location" placeholder="e.g., Barangay Hall">
                    </div>
                </div>

                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" required></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="start_date">Start Date *</label>
                        <input type="date" id="start_date" name="start_date" required>
                    </div>
                    <div class="form-group">
                        <label for="end_date">End Date</label>
                        <input type="date" id="end_date" name="end_date">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="start_time">Start Time</label>
                        <input type="time" id="start_time" name="start_time">
                    </div>
                    <div class="form-group">
                        <label for="end_time">End Time</label>
                        <input type="time" id="end_time" name="end_time">
                    </div>
                </div>

                <div class="form-group">
                    <label for="image">Image (Optional)</label>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="deleteId">
    </form>

    <script>
        function openCreateModal() {
            document.getElementById('modalTitle').textContent = 'Create Program/Event';
            document.getElementById('formAction').value = 'create';
            document.getElementById('programForm').reset();
            document.getElementById('programId').value = '';
            document.getElementById('start_date').value = '<?php echo date('Y-m-d'); ?>';
            document.getElementById('programModal').classList.add('show');
        }

        function openEditModal(program) {
            document.getElementById('modalTitle').textContent = 'Edit Program/Event';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('programId').value = program.id;
            document.getElementById('title').value = program.title || '';
            document.getElementById('type').value = program.type || 'Program';
            document.getElementById('location').value = program.location || '';
            document.getElementById('description').value = program.description || '';
            document.getElementById('start_date').value = program.start_date || '';
            document.getElementById('end_date').value = program.end_date || '';
            document.getElementById('start_time').value = program.start_time || '';
            document.getElementById('end_time').value = program.end_time || '';
            document.getElementById('programModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('programModal').classList.remove('show');
        }

        function deleteProgram(id) {
            if (confirm('Are you sure you want to delete this program/event?')) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }

        window.onclick = function(event) {
            const modal = document.getElementById('programModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>
