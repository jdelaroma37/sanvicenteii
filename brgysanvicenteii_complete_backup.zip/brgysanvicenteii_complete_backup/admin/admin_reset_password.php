<?php
// admin/admin_reset_password.php
session_start();
require '../config.php';

// Redirect if already logged in
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit;
}

// Validate reset token
if (!isset($_SESSION['reset_token'], $_SESSION['reset_email'], $_SESSION['reset_expiry'])) {
    $_SESSION['error'] = 'Invalid or expired reset link. Please start over.';
    header('Location: admin_forgot_password.php');
    exit;
}

if (time() > $_SESSION['reset_expiry']) {
    unset($_SESSION['reset_token'], $_SESSION['reset_email'], $_SESSION['reset_expiry']);
    $_SESSION['error'] = 'Reset link has expired. Please request a new one.';
    header('Location: admin_forgot_password.php');
    exit;
}

$error = '';
$success = '';
$email = $_SESSION['reset_email'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (strlen($new_password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin) {
            $hash = password_hash($new_password, PASSWORD_DEFAULT);
            $update_stmt = $pdo->prepare("UPDATE admins SET password = ? WHERE email = ?");
            $update_stmt->execute([$hash, $email]);

            unset($_SESSION['reset_token'], $_SESSION['reset_email'], $_SESSION['reset_expiry']);

            $success = 'Password reset successfully! You can now login with your new password.';
            header('refresh:2;url=admin_login.php');
        } else {
            $error = 'Admin account not found.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Reset Password - Barangay San Vicente II</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'Segoe UI', sans-serif;
    background: #E8F0E4;
    background-image: 
        linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
    background-size: 40px 40px;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}
.modal-container {
    display: flex;
    width: 100%;
    max-width: 900px;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 20px 60px rgba(0,0,0,0.15);
    overflow: hidden;
    animation: slideUp .4s ease;
}
@keyframes slideUp {
    from { opacity: 0; transform: translateY(20px); }
    to { opacity: 1; transform: translateY(0); }
}
.form-section {
    flex: 1;
    padding: 32px 26px;
    display: flex;
    flex-direction: column;
    justify-content: center;
}
.visual-section {
    flex: 1;
    background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 50%, #1a5f3f 100%);
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 30px 25px;
    overflow: hidden;
}
.visual-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        repeating-linear-gradient(
            45deg,
            rgba(212, 175, 55, 0.1) 0px,
            rgba(212, 175, 55, 0.1) 20px,
            transparent 20px,
            transparent 40px
        );
    opacity: 0.3;
}
.visual-content {
    position: relative;
    z-index: 1;
    text-align: center;
    color: white;
}
.visual-icon {
    width: 80px;
    height: 80px;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 18px;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(212, 175, 55, 0.3);
}
.visual-icon img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #d4af37;
}
.visual-quote {
    font-size: 16px;
    font-weight: 600;
    line-height: 1.4;
    margin-bottom: 18px;
    color: white;
}
.visual-author {
    font-size: 12px;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.9);
}
.logo {
    text-align: center;
    margin-bottom: 18px;
}
.logo img {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #d4af37;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}
h1 { text-align: center; color: #1a5f3f; margin-bottom: 4px; font-size: 21px; font-weight: 700; }
.subtitle { text-align: center; margin-bottom: 24px; color: #666; font-size: 14px; }
.email-display {
    background: #f5f5f5;
    padding: 12px;
    border-radius: 8px;
    text-align: center;
    font-size: 13px;
    margin-bottom: 18px;
}
.form-group { 
    margin-bottom: 18px; 
    position: relative; 
}
.form-group:has(#confirm_password) .password-toggle-btn {
    top: 33px;
}
label { 
    font-size: 11px; 
    font-weight: 600; 
    color: #1a5f3f; 
    margin-bottom: 5px; 
    display: block; 
    line-height: 1.2;
}
input[type="password"], input[type="text"] {
    width: 100%;
    padding: 9px 100px 9px 11px;
    border: 2px solid #e0e0e0;
    background: #fafafa;
    border-radius: 6px;
    font-size: 12px;
    transition: .3s;
    box-sizing: border-box;
}
input:focus {
    outline: none;
    background: #fff;
    border-color: #d4af37;
    box-shadow: 0 0 0 3px rgba(212,175,55,0.15);
}
.password-toggle-btn {
    position: absolute;
    right: 10px;
    top: 33px;
    background: transparent;
    border: none;
    color: #1a5f3f;
    font-size: 10px;
    cursor: pointer;
    padding: 0;
    border-radius: 3px;
    transition: all 0.3s;
    font-weight: 500;
    white-space: nowrap;
    z-index: 10;
    display: flex;
    align-items: center;
    justify-content: center;
    line-height: 1.2;
    height: auto;
}
.btn {
    width: 100%;
    padding: 11px;
    background: linear-gradient(135deg, #1a5f3f, #2d7a52);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    margin-top: 8px;
    transition: .3s;
}
.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(26,95,63,0.35);
}
.links { text-align: center; margin-top: 12px; font-size: 12px; }
.links a { color: #1a5f3f; text-decoration: none; }
.error, .success {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 16px;
    font-size: 13px;
}
.error { background: #fee; color: #b33; border-left: 4px solid #b33; }
.success { background: #efe; color: #393; border-left: 4px solid #393; }

@media (max-width: 768px) {
    .modal-container {
        flex-direction: column;
        max-width: 100%;
        min-height: auto;
    }
    .visual-section {
        display: none;
    }
    .form-section {
        padding: 40px 30px;
    }
}

@media (max-width: 480px) {
    body {
        padding: 10px;
    }
    .form-section {
        padding: 30px 20px;
    }
    h1 {
        font-size: 24px;
    }
    input[type="password"],
    input[type="text"] {
        padding: 12px 100px 12px 12px;
    }
    .password-toggle-btn {
        font-size: 10px;
        padding: 0;
        top: 36px;
        right: 10px;
    }
}
</style>
</head>
<body>
<div class="modal-container">
    <div class="form-section">

        <div class="logo"><img src="../images/logo.jpg" alt="Barangay Logo"></div>
        <h1>Reset Password</h1>
        <p class="subtitle">Enter your new password below.</p>

        <div class="email-display">Resetting password for: <strong><?= htmlspecialchars($email) ?></strong></div>

        <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <form method="POST" id="resetForm" autocomplete="off">
            <div class="form-group">
                <label for="new_password">New Password</label>
                <input type="password" id="new_password" name="new_password" required>
                <button type="button" class="password-toggle-btn" onclick="togglePassword('new_password', this)">Show Password</button>
            </div>

            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
                <button type="button" class="password-toggle-btn" onclick="togglePassword('confirm_password', this)">Show Password</button>
            </div>

            <button type="submit" class="btn">Reset Password</button>
        </form>

        <div class="links">
            <a href="admin_forgot_password.php">← Back</a> |
            <a href="admin_login.php">Login</a>
        </div>
    </div>

    <div class="visual-section">
        <div class="visual-content">
            <div class="visual-icon">
                <img src="../images/logo.jpg" alt="Barangay Logo">
            </div>
            <div class="visual-quote">
                "Securely reset your password and regain access to your administrative account."
            </div>
            <div class="visual-author">
                BARANGAY SAN VICENTE II
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword(fieldId, btn) {
    const input = document.getElementById(fieldId);
    if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = 'Hide Password';
    } else {
        input.type = 'password';
        btn.textContent = 'Show Password';
    }
}
</script>
</body>
</html>
