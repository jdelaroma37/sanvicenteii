<?php
// admin/admin_register.php
session_start();
require '../config.php';

// Security: Regenerate session ID
if (!isset($_SESSION['initiated'])) {
    session_regenerate_id(true);
    $_SESSION['initiated'] = true;
}

// If already logged in as admin, redirect to dashboard
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validation
    $errors = [];
    if (!$full_name) $errors[] = 'Full name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Invalid email address.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm_password) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'Email already registered.';
        } else {
            // Hash password and insert with pending status
            $hash = password_hash($password, PASSWORD_DEFAULT);
            try {
                // Check if columns exist, if not use basic insert
                $columns_exist = false;
                try {
                    $check_stmt = $pdo->query("SHOW COLUMNS FROM admins LIKE 'status'");
                    $columns_exist = $check_stmt->rowCount() > 0;
                } catch (PDOException $e) {
                    $columns_exist = false;
                }
                
                if ($columns_exist) {
                    // Check if there are already 3 admins (limit) - count all admins, not just active
                    $count_stmt = $pdo->query("SELECT COUNT(*) as count FROM admins");
                    $admin_count = $count_stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
                    
                    if ($admin_count >= 3) {
                        $error = 'Maximum number of admins reached (3 admins limit). You are no longer allowed to create an admin account.';
                    } else {
                        // New admins are pending and need approval
                        $stmt = $pdo->prepare("INSERT INTO admins (full_name, email, password, role, status) VALUES (?, ?, ?, 'regular_admin', 'pending')");
                        $stmt->execute([$full_name, $email, $hash]);
                        $new_admin_id = $pdo->lastInsertId();
                        $success = 'Registration successful! Your account is pending approval. Please wait for a Super Admin to approve your account before you can login.';
                        
                        // Create admin notification (super admin only)
                        if (file_exists(__DIR__ . '/admin_notification_helper.php')) {
                            require_once __DIR__ . '/admin_notification_helper.php';
                            createAdminNotification(
                                'admin_added',
                                'New Admin Registration',
                                "A new admin account registration is pending approval: {$full_name} ({$email})",
                                'super_admin',
                                [
                                    'admin_id' => $new_admin_id,
                                    'admin_name' => $full_name,
                                    'admin_email' => $email,
                                    'status' => 'pending'
                                ]
                            );
                        }
                    }
                } else {
                    // Fallback for old database structure
                    $stmt = $pdo->prepare("INSERT INTO admins (full_name, email, password) VALUES (?, ?, ?)");
                    $stmt->execute([$full_name, $email, $hash]);
                    $success = 'Registration successful! Please run the database update script first.';
                }
                // Clear form
                $full_name = $email = '';
            } catch (PDOException $e) {
                $error = 'Registration failed: ' . $e->getMessage();
            }
        }
    } else {
        $error = implode('<br>', $errors);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .modal-container {
            display: flex;
            width: 100%;
            max-width: 900px;
            min-height: 600px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideUp 0.4s ease;
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .form-section {
            flex: 1;
            padding: 30px 25px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: #ffffff;
            overflow-y: auto;
        }
        .visual-section {
            flex: 1;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 50%, #1a5f3f 100%);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 30px 25px;
            overflow: hidden;
        }
        .visual-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                repeating-linear-gradient(
                    45deg,
                    rgba(212, 175, 55, 0.1) 0px,
                    rgba(212, 175, 55, 0.1) 20px,
                    transparent 20px,
                    transparent 40px
                );
            opacity: 0.3;
        }
        .visual-content {
            position: relative;
            z-index: 1;
            text-align: center;
            color: white;
        }
        .visual-icon {
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 18px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(212, 175, 55, 0.3);
        }
        .visual-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #d4af37;
        }
        .visual-quote {
            font-size: 16px;
            font-weight: 600;
            line-height: 1.4;
            margin-bottom: 18px;
            color: white;
        }
        .visual-author {
            font-size: 12px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }
        .logo {
            text-align: center;
            margin-bottom: 18px;
        }
        .logo img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #d4af37;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        h1 {
            color: #1a5f3f;
            text-align: center;
            margin-bottom: 4px;
            font-size: 20px;
            font-weight: 700;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 18px;
            font-size: 11px;
        }
        .form-group {
            margin-bottom: 16px;
            position: relative;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #1a5f3f;
            font-weight: 600;
            font-size: 11px;
        }
        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 9px 11px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 12px;
            transition: all 0.3s;
            background: #fafafa;
        }
        input[type="text"]:focus,
        input[type="email"]:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        input[type="password"] {
            width: 100%;
            padding: 9px 100px 9px 11px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 12px;
            transition: all 0.3s;
            background: #fafafa;
        }
        input[type="password"]:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        #password[type="text"],
        #confirm_password[type="text"] {
            padding: 9px 100px 9px 11px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 12px;
            background: #fafafa;
        }
        #password[type="text"]:focus,
        #confirm_password[type="text"]:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .password-toggle-btn {
            position: absolute;
            right: 10px;
            top: calc(11px + 5px + 9px + 6px);
            background: transparent;
            border: none;
            color: #1a5f3f;
            font-size: 10px;
            cursor: pointer;
            padding: 0;
            border-radius: 3px;
            transition: all 0.3s;
            font-weight: 500;
            white-space: nowrap;
            z-index: 10;
            display: flex;
            align-items: center;
            height: 12px;
            line-height: 12px;
        }
        .password-toggle-btn:hover {
            background: rgba(26, 95, 63, 0.1);
            color: #1a5f3f;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 13px;
            border-left: 4px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 13px;
            border-left: 4px solid #3c3;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 6px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(26, 95, 63, 0.3);
            background: linear-gradient(135deg, #2d7a52 0%, #1a5f3f 100%);
        }
        .btn:active {
            transform: translateY(0);
        }
        .links {
            text-align: center;
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #e0e0e0;
        }
        .links a {
            color: #1a5f3f;
            text-decoration: none;
            font-size: 11px;
            margin: 0 5px;
            transition: color 0.3s;
            font-weight: 500;
        }
        .links a:hover {
            color: #d4af37;
            text-decoration: underline;
        }
        .back-home {
            text-align: center;
            margin-top: 15px;
        }
        .back-home a {
            color: #666;
            text-decoration: none;
            font-size: 12px;
            transition: color 0.3s;
            display: inline-flex;
            align-items: center;
        }
        .back-home a:hover {
            color: #1a5f3f;
            text-decoration: underline;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .modal-container {
                flex-direction: column;
                max-width: 100%;
                min-height: auto;
            }
            .visual-section {
                display: none;
            }
            .form-section {
                padding: 40px 30px;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 10px;
            }
            .form-section {
                padding: 30px 20px;
            }
            h1 {
                font-size: 24px;
            }
            input[type="text"],
            input[type="email"],
            input[type="password"] {
                padding: 12px 100px 12px 12px;
            }
            #password[type="text"],
            #confirm_password[type="text"] {
                padding: 12px 100px 12px 12px;
            }
            .password-toggle-btn {
                font-size: 10px;
                padding: 3px 6px;
            }
        }
    </style>
</head>
<body>
    <div class="modal-container">
        <div class="form-section">
            <div class="logo">
                <img src="../images/logo.jpg" alt="Barangay Logo">
            </div>
            <h1>Admin Registration</h1>
            <p class="subtitle">Create Admin Account</p>

            <?php if ($error): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="POST" action="" autocomplete="off">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" placeholder="Enter your full name" value="<?php echo htmlspecialchars($full_name ?? ''); ?>" autocomplete="off" required>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo htmlspecialchars($email ?? ''); ?>" autocomplete="off" required>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter password (min 6 characters)" autocomplete="new-password" required>
                    <button type="button" class="password-toggle-btn" id="togglePassword">Show Password</button>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm your password" autocomplete="new-password" required>
                    <button type="button" class="password-toggle-btn" id="toggleConfirmPassword">Show Password</button>
                </div>

                <button type="submit" class="btn">Register</button>
            </form>

            <div class="links">
                <a href="admin_login.php">Already have an account? Login</a>
            </div>

            <div class="links">
                <a href="../index.php">Register as Resident</a>
            </div>

            <div class="back-home">
                <a href="../index.php">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                        <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Back to Home
                </a>
            </div>
        </div>

        <div class="visual-section">
            <div class="visual-content">
                <div class="visual-icon">
                    <img src="../images/logo.jpg" alt="Barangay Logo">
                </div>
                <div class="visual-quote">
                    "Join our administrative team and help serve the community of Barangay San Vicente II with dedication and excellence."
                </div>
                <div class="visual-author">
                    BARANGAY SAN VICENTE II
                </div>
            </div>
        </div>
    </div>

    <script>
        // Password toggle functionality
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput = document.getElementById('password');
        const toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
        const confirmPasswordInput = document.getElementById('confirm_password');

        togglePassword.addEventListener('click', function() {
            const isPassword = passwordInput.getAttribute('type') === 'password';
            passwordInput.setAttribute('type', isPassword ? 'text' : 'password');
            togglePassword.textContent = isPassword ? 'Hide Password' : 'Show Password';
        });

        toggleConfirmPassword.addEventListener('click', function() {
            const isPassword = confirmPasswordInput.getAttribute('type') === 'password';
            confirmPasswordInput.setAttribute('type', isPassword ? 'text' : 'password');
            toggleConfirmPassword.textContent = isPassword ? 'Hide Password' : 'Show Password';
        });
    </script>
</body>
</html>
