<?php
// admin/admin_monitoring_request.php
session_start();
require '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

require_once __DIR__ . '/../resident/notification_helper.php';

// Cache admin roles so we only hit the DB once per admin id
$adminRoleCache = [];
function getAdminRoleById($pdo, $adminId, &$cache) {
    if (empty($adminId)) {
        return null;
    }
    if (isset($cache[$adminId])) {
        return $cache[$adminId];
    }
    $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
    $stmt->execute([$adminId]);
    $role = $stmt->fetchColumn();
    $cache[$adminId] = $role ?: null;
    return $cache[$adminId];
}

// Load all requests
$requests_dir = __DIR__ . '/../data/requests';
$archive_dir = __DIR__ . '/../data/request_archive';
if (!is_dir($archive_dir)) {
    @mkdir($archive_dir, 0777, true);
}
$archive_file = $archive_dir . '/archived_requests.json';
$all_requests = [];
if (is_dir($requests_dir)) {
    $files = glob("$requests_dir/*.json");
    foreach ($files as $file) {
        $filename = basename($file);
        // Skip main requests.json
        if ($filename === 'requests.json') {
            continue;
        }
        
        $content = json_decode(file_get_contents($file), true);
        if ($content) {
            // Handle user summary files (array of requests)
            if (preg_match('/^\d+_requests\.json$/', $filename) && is_array($content)) {
                foreach ($content as $req) {
                    if (is_array($req) && !empty($req['id'])) {
                        $all_requests[] = $req;
                    }
                }
            } 
            // Handle individual request files
            else if (is_array($content)) {
                // Ensure request has an ID, use filename if not
                if (empty($content['id'])) {
                    // Extract ID from filename (e.g., req_xxx.json -> req_xxx)
                    $content['id'] = str_replace('.json', '', $filename);
                }
                // Only add if it has a valid ID
                if (!empty($content['id'])) {
                    $all_requests[] = $content;
                }
            }
        }
    }
}

// Regular admins don't see Done items; super admins can still view/reopen them
if ($admin_role !== 'super_admin') {
    $all_requests = array_filter($all_requests, function($req) {
        $status = strtolower(trim($req['status'] ?? ''));
        return $status !== 'done';
    });
}

// Sort by date requested (newest first)
usort($all_requests, function($a, $b) {
    $dateA = $a['dateRequested'] ?? $a['created_at'] ?? '';
    $dateB = $b['dateRequested'] ?? $b['created_at'] ?? '';
    return strcmp($dateB, $dateA);
});

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_status') {
        $request_id = $_POST['request_id'] ?? '';
        $new_status = $_POST['status'] ?? '';
        
        if ($new_status === 'Done' && $admin_role !== 'super_admin') {
            $_SESSION['error'] = 'Only super admins can mark requests as Done.';
            header('Location: admin_monitoring_request.php');
            exit;
        }

        if ($request_id && $new_status) {
            $updated = false;
            $files = glob("$requests_dir/*.json");
            $updatedRequest = null;
            $previous_status = null;
            
            foreach ($files as $file) {
                $filename = basename($file);
                if ($filename === 'requests.json') {
                    continue;
                }
                
                $content = json_decode(file_get_contents($file), true);
                if (!$content) continue;
                
                // Check if it's a user summary file
                if (preg_match('/^\d+_requests\.json$/', $filename) && is_array($content)) {
                    // Search through the array of requests
                    foreach ($content as $index => $req) {
                        if (is_array($req) && isset($req['id']) && $req['id'] === $request_id) {
                            $previous_status = $req['status'] ?? '';
                            $content[$index]['status'] = $new_status;
                            if ($new_status === 'Done') {
                                $content[$index]['doneAt'] = date('Y-m-d H:i:s');
                                $content[$index]['doneBy'] = $admin_id;
                            } else {
                                unset($content[$index]['doneAt'], $content[$index]['doneBy'], $content[$index]['doneByResident']);
                            }
                            $updatedRequest = $content[$index];
                            file_put_contents($file, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                            $updated = true;
                            break 2;
                        }
                    }
                } 
                // Check if it's an individual request file
                else if (is_array($content) && isset($content['id']) && $content['id'] === $request_id) {
                    $previous_status = $content['status'] ?? '';
                    $content['status'] = $new_status;
                    if ($new_status === 'Done') {
                        $content['doneAt'] = date('Y-m-d H:i:s');
                        $content['doneBy'] = $admin_id;
                    } else {
                        unset($content['doneAt'], $content['doneBy'], $content['doneByResident']);
                    }
                    $updatedRequest = $content;
                    file_put_contents($file, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $updated = true;
                    break;
                }
            }
            
            if ($updated) {
                if ($new_status === 'Processing' && $previous_status !== 'Processing' && $updatedRequest) {
                    $residentId = $updatedRequest['user_id'] ?? null;
                    $docType = $updatedRequest['documentType'] ?? 'your request';
                    if ($residentId) {
                        createResidentNotification(
                            'request_reprocess',
                            'Request needs updates',
                            "Your {$docType} was sent back for processing. Please review and resubmit your details.",
                            [
                                'resident_id' => $residentId,
                                'request_id' => $request_id,
                                'link' => 'resident/res_notification.php',
                                'category' => 'warning'
                            ]
                        );
                    }
                }
                $_SESSION['success'] = 'Status updated successfully!';
            } else {
                $_SESSION['error'] = 'Request not found.';
            }
        }
        header('Location: admin_monitoring_request.php');
        exit;
    } elseif ($_POST['action'] === 'delete') {
        $request_id = trim($_POST['request_id'] ?? '');
        
        if (empty($request_id)) {
            $_SESSION['error'] = 'Invalid request ID.';
            header('Location: admin_monitoring_request.php');
            exit;
        }

        $archived = false;
        $files = glob("$requests_dir/*.json");
        $archiveData = [];
        if (file_exists($archive_file)) {
            $archiveData = json_decode(file_get_contents($archive_file), true);
            if (!is_array($archiveData)) {
                $archiveData = [];
            }
        }
        
        foreach ($files as $file) {
            $filename = basename($file);
            if ($filename === 'requests.json') {
                continue;
            }
            
            $content = json_decode(file_get_contents($file), true);
            if (!$content) continue;
            
            // Check if it's a user summary file
            if (preg_match('/^\d+_requests\.json$/', $filename) && is_array($content)) {
                // Search through the array of requests
                foreach ($content as $index => $req) {
                    if (is_array($req) && isset($req['id']) && $req['id'] === $request_id) {
                        // Add archive metadata and store
                        $req['deleted_at'] = date('Y-m-d H:i:s');
                        $req['deleted_by'] = $admin_id;
                        $req['archived_at'] = $req['deleted_at'];
                        $req['archived_from'] = $filename;
                        $req['archived_type'] = 'summary';
                        $req['archive_id'] = uniqid('arch_', true);
                        $archiveData[] = $req;

                        // Remove the request from the active array
                        unset($content[$index]);
                        $content = array_values($content); // Re-index array
                        
                        // Save the updated active file
                        if (empty($content)) {
                            // If array is empty, delete the file
                            @unlink($file);
                        } else {
                            file_put_contents($file, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                        }
                        $archived = true;
                        break 2;
                    }
                }
            } 
            // Check if it's an individual request file
            else if (is_array($content) && isset($content['id']) && $content['id'] === $request_id) {
                // Add archive metadata and store
                $content['deleted_at'] = date('Y-m-d H:i:s');
                $content['deleted_by'] = $admin_id;
                $content['archived_at'] = $content['deleted_at'];
                $content['archived_from'] = $filename;
                $content['archived_type'] = 'individual';
                $content['archive_id'] = uniqid('arch_', true);
                $archiveData[] = $content;

                // Move the request file to archive for safekeeping
                $targetPath = $archive_dir . '/' . $filename;
                if (!@rename($file, $targetPath)) {
                    @copy($file, $targetPath);
                    @unlink($file);
                }
                $archived = true;
                break;
            }
        }
        
        if ($archived) {
            file_put_contents($archive_file, json_encode($archiveData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['success'] = 'Request archived successfully!';
        } else {
            $_SESSION['error'] = 'Request file not found. ID: ' . htmlspecialchars($request_id);
        }
        header('Location: admin_monitoring_request.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Monitoring - Barangay San Vicente II</title>
    <style>
        :root {
            --bg-color: #f5f7f3;
            --primary: #1f7a45;
            --primary-dark: #145b32;
            --border: #e0e0e0;
            --text-main: #2c3e2d;
            --status-pending-bg: #e7f4ec;
            --status-pending-text: #1f7a45;
            --status-done-bg: #c9e7d6;
            --status-done-text: #0f4d2c;
            --sidebar-bg: #9bb67a;
        }
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Poppins', 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: var(--bg-color);
            display: flex;
            min-height: 100vh;
            color: var(--text-main);
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
            position: relative;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a i {
            margin-right: 12px;
            width: 24px;
            font-size: 20px;
            text-align: center;
            display: inline-block;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        /* Submenu */
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--sidebar-bg);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: var(--primary-dark);
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
            backdrop-filter: blur(2px);
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #1f7a45;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1f7a45 0%, #156238 100%);
            color: #fff;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(21, 98, 56, 0.35);
            background: linear-gradient(135deg, #156238 0%, #0f4d2c 100%);
        }
        .row-container {
            background: white;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid var(--border);
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 16px;
            margin-bottom: 20px;
        }
        .summary-card {
            background: white;
            border: 1px solid var(--border);
            border-radius: 10px;
            padding: 16px 18px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.06);
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .summary-card .label {
            font-size: 13px;
            color: #6b7280;
            font-weight: 600;
        }
        .summary-card .value {
            font-size: 28px;
            font-weight: 800;
            color: var(--text-main);
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: var(--primary-dark);
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .row-container > .section-title:first-child {
            margin-top: 0;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Table */
        .content-card {
            background: white;
            padding: 0;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
            overflow: hidden;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th {
            background: var(--primary);
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #fff;
            font-size: 14px;
            border-bottom: 2px solid var(--primary-dark);
        }
        table th:first-child {
            padding-left: 24px;
        }
        table th:last-child {
            padding-right: 24px;
        }
        table th:not(:first-child)::before {
            content: '';
            position: absolute;
            left: 0;
            top: 25%;
            bottom: 25%;
            width: 1px;
            background: rgba(212, 175, 55, 0.4);
        }
        table td {
            padding: 20px;
            border-bottom: 1px solid #f0f0f0;
            font-size: 14px;
            font-weight: 500;
            color: #1f2937;
            background: white;
            vertical-align: middle;
        }
        table td:first-child {
            padding-left: 24px;
            font-weight: 600;
            color: #1f2937;
        }
        table td:last-child {
            padding-right: 24px;
        }
        table tr {
            transition: all 0.2s ease;
        }
        table tr:hover td {
            background: #f9fafb;
            transform: scale(1.001);
        }
        table tr:last-child td {
            border-bottom: none;
        }
        .status-select {
            padding: 10px 14px;
            border: 2px solid var(--primary);
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            background: white;
            transition: all 0.2s ease;
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23145b32' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 38px;
            min-width: 160px;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .status-select:hover {
            transform: translateY(-1px);
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            border-color: var(--primary);
        }
        .status-select:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(111, 141, 79, 0.18);
        }
        .status-select[disabled] {
            opacity: 0.65;
            cursor: not-allowed;
            background: #f8f9fa;
            color: #94a3b8;
            border-color: #d6d6d6;
            box-shadow: none;
        }
        .status-select.pending {
            background: linear-gradient(135deg, var(--status-pending-bg) 0%, #d9ecdf 100%);
            color: var(--status-pending-text);
            border-color: #b6d9c3;
            box-shadow: 0 2px 4px rgba(31, 122, 69, 0.12);
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23145b32' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
        }
        .status-select.pending:hover {
            background: linear-gradient(135deg, #d9ecdf 0%, var(--status-pending-bg) 100%);
            box-shadow: 0 4px 8px rgba(31, 122, 69, 0.2);
        }
        .status-select.done {
            background: linear-gradient(135deg, var(--status-done-bg) 0%, #b4d9c3 100%);
            color: var(--status-done-text);
            border-color: #8bbf9f;
            box-shadow: 0 2px 4px rgba(20, 93, 50, 0.18);
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23145b32' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
        }
        .status-select.done:hover {
            background: linear-gradient(135deg, #b4d9c3 0%, #c9e7d6 100%);
            box-shadow: 0 4px 8px rgba(20, 93, 50, 0.25);
        }
        .status-select.processing {
            background: linear-gradient(135deg, #dcefe4 0%, #c1e2cf 100%);
            color: #0f4d2c;
            border-color: #1f7a45;
            box-shadow: 0 2px 4px rgba(31, 122, 69, 0.2);
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23145b32' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
        }
        .status-select.processing:hover {
            background: linear-gradient(135deg, #c1e2cf 0%, #dcefe4 100%);
            box-shadow: 0 4px 8px rgba(31, 122, 69, 0.28);
        }
        .status-select.ready {
            background: linear-gradient(135deg, #d0ecde 0%, #a8d8ba 100%);
            color: #0f4d2c;
            border-color: #1f7a45;
            box-shadow: 0 2px 4px rgba(31, 122, 69, 0.2);
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%23145b32' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
        }
        .status-select.ready:hover {
            background: linear-gradient(135deg, #a8d8ba 0%, #d0ecde 100%);
            box-shadow: 0 4px 8px rgba(20, 93, 50, 0.22);
        }
        /* Dropdown Options Styling */
        .status-select option {
            padding: 10px;
            background: white;
            color: #333;
            font-weight: 500;
        }
        .status-select option:hover {
            background: #f0f0f0;
        }
        .btn-generate {
            padding: 8px 16px;
            background: linear-gradient(135deg, #1f7a45 0%, #145b32 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 4px rgba(21, 98, 56, 0.3);
        }
        .btn-generate:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(21, 98, 56, 0.35);
            background: linear-gradient(135deg, #145b32 0%, #0f4226 100%);
        }
        .btn-generated {
            padding: 9px 16px;
            background: linear-gradient(135deg, #cfe7da 0%, #b5d8c5 100%);
            color: #0f4226;
            border: 1px solid #8bbf9f;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            cursor: default;
            box-shadow: 0 2px 6px rgba(20, 93, 50, 0.15);
        }
        .btn-generate:active {
            transform: translateY(0);
        }
        .view-pdf-link {
            color: #0f4226;
            text-decoration: none;
            font-weight: 700;
            font-size: 13px;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 9px 14px;
            border-radius: 12px;
            background: #e7f4ec;
            border: 1px solid #b6d9c3;
        }
        .view-pdf-link:hover {
            color: #0d3a21;
            background: #d9ecdf;
            text-decoration: none;
        }
        .btn-view {
            padding: 8px 16px;
            background: linear-gradient(135deg, #cfe7da 0%, #b5d8c5 100%);
            color: #0f4226;
            border: 1px solid #8bbf9f;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(20, 93, 50, 0.12);
        }
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(20, 93, 50, 0.18);
            background: linear-gradient(135deg, #b5d8c5 0%, #cfe7da 100%);
        }
        .btn-view:active {
            transform: translateY(0);
        }
        .btn-delete {
            padding: 8px 16px;
            background: linear-gradient(135deg, #e3f2ea 0%, #c9e7d6 100%);
            color: #0f4d2c;
            border: 1px solid #8bbf9f;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(20, 93, 50, 0.12);
        }
        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(20, 93, 50, 0.18);
            background: linear-gradient(135deg, #c9e7d6 0%, #e3f2ea 100%);
        }
        .btn-delete:active {
            transform: translateY(0);
        }
        .btn-mark-done {
            padding: 8px 16px;
            background: linear-gradient(135deg, #cfe7da 0%, #b5d8c5 100%);
            color: #0f4226;
            border: 1px solid #8bbf9f;
            border-radius: 12px;
            font-size: 13px;
            font-weight: 200;
            cursor: pointer;
            transition: all 0.2s ease;
            box-shadow: 0 2px 6px rgba(20, 93, 50, 0.12);
        }
        .btn-mark-done:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(20, 93, 50, 0.18);
            background: linear-gradient(135deg, #b5d8c5 0%, #cfe7da 100%);
        }
        .btn-mark-done:active {
            transform: translateY(0);
        }
        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 10px;
            align-items: flex-start;
        }
        .action-buttons-top {
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        .action-buttons-bottom {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .modal.modal-confirm {
            background: rgba(17, 24, 39, 0.45);
        }
        .modal-content {
            background: #e8f5e9;
            border-radius: 12px;
            padding: 30px;
            max-width: 700px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            position: relative;
            border-left: 4px solid #d4af37;
        }
        .modal.modal-confirm .modal-content {
            background: #ffffff;
            border: 1px solid #e5e7eb;
            border-left: none;
            border-radius: 14px;
            max-width: 360px;
            padding: 24px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            text-align: left;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }
        .modal-header h2 {
            font-size: 24px;
            color: #1a5f3f;
            margin: 0;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 32px;
            color: #999;
            cursor: pointer;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }
        .close-modal:hover {
            background: #f0f0f0;
            color: #c33;
        }
        .modal-body {
            color: #333;
        }
        .modal.modal-confirm .modal-body {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .modal.modal-confirm h3 {
            margin: 0;
            font-size: 19px;
            color: #123926;
            font-weight: 700;
        }
        .modal.modal-confirm p {
            margin: 0;
            font-size: 14px;
            color: #4b5563;
            line-height: 1.5;
        }
        .modal.modal-confirm .confirm-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 6px;
        }
        .modal.modal-confirm .confirm-btn {
            border: none;
            border-radius: 12px;
            padding: 10px 14px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.15s ease, box-shadow 0.2s ease, background 0.2s ease;
            min-width: 122px;
            height: 42px;
            font-size: 14px;
        }
        .modal.modal-confirm .confirm-btn.cancel {
            background: #f1f5f3;
            color: #1a5f3f;
            border: 1px solid #d4e8d4;
        }
        .modal.modal-confirm .confirm-btn.cancel:hover {
            background: #e3ede7;
        }
        .modal.modal-confirm .confirm-btn.primary {
            background: #1a5f3f;
            color: #ffffff;
            box-shadow: 0 10px 25px rgba(26,95,63,0.25);
        }
        .modal.modal-confirm .confirm-btn.primary:hover {
            background: #164d34;
            transform: translateY(-1px);
        }
        .modal.modal-confirm .confirm-btn:active {
            transform: translateY(0);
        }
        .detail-group {
            margin-bottom: 20px;
        }
        .detail-group label {
            font-weight: 600;
            color: #1a5f3f;
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
        }
        .detail-group p {
            margin: 0;
            padding: 8px 12px;
            background: #d4e8d4;
            border-radius: 6px;
            color: #333;
            font-size: 14px;
            border-left: 3px solid #d4af37;
        }
        .detail-group .value {
            color: #666;
        }
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-badge.pending {
            background: linear-gradient(180deg, #fff3cd 0%, #ffe69c 100%);
            color: #856404;
        }
        .status-badge.done {
            background: linear-gradient(180deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
        }
        .status-badge.processing {
            background: linear-gradient(180deg, #cfe2ff 0%, #b6d4fe 100%);
            color: #084298;
        }
        .status-badge.ready {
            background: linear-gradient(180deg, #d1e7dd 0%, #badbcc 100%);
            color: #0f5132;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .table-container {
                overflow-x: scroll;
            }
            .modal-content {
                width: 95%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="9" y1="3" x2="9" y2="21"></line>
                    <line x1="3" y1="9" x2="21" y2="9"></line>
                </svg>
            </span>
            Request Monitoring
        </h1>

        <div class="page-actions">
            <a href="admin_issuance_details.php" class="btn btn-primary">
                Issuance Details
            </a>
            <a href="admin_walkin_request.php" class="btn btn-primary">
                Walk-in Request
            </a>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="row-container">
            <div class="content-card">
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Document Type</th>
                            <th>Generated PDF</th>
                            <th>Date Requested</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($all_requests)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; color: #9ca3af; padding: 60px 20px; font-size: 15px;">
                                    <div style="display: flex; flex-direction: column; align-items: center; gap: 12px;">
                                        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="opacity: 0.3;">
                                            <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                            <line x1="9" y1="3" x2="9" y2="21"></line>
                                            <line x1="3" y1="9" x2="21" y2="9"></line>
                                        </svg>
                                        <div style="font-weight: 600; color: #6b7280;">No requests found</div>
                                        <div style="font-size: 13px; color: #9ca3af;">All requests have been processed or no requests exist yet.</div>
                                    </div>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($all_requests as $request): ?>
                                <tr>
                                    <td style="font-weight: 600; color: #1f2937;">
                                        <?php echo htmlspecialchars($request['fullname'] ?? 'N/A'); ?>
                                    </td>
                                    <td>
                                        <span style="display: inline-block; padding: 4px 10px; background: #f3f4f6; border-radius: 6px; font-size: 12px; font-weight: 600; color: #374151;">
                                            <?php echo htmlspecialchars($request['documentType'] ?? 'N/A'); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php 
                                        $status = strtolower(trim($request['status'] ?? 'pending'));
                                        $has_pdf = !empty($request['pdf_name']) && file_exists(__DIR__ . '/../data/generated_pdfs/' . $request['pdf_name']);
                                        
                                        $allow_regen = ($status === 'processing');
                                        
                                        if ($has_pdf && !$allow_regen): ?>
                                            <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                                                <button class="btn-generated" title="Already generated" disabled>Generated</button>
                                                <a href="../data/generated_pdfs/<?php echo htmlspecialchars($request['pdf_name']); ?>" target="_blank" class="view-pdf-link">View PDF</a>
                                            </div>
                                        <?php else: ?>
                                            <button class="btn-generate" onclick="generatePDF('<?php echo htmlspecialchars($request['id'] ?? ''); ?>', this)">Generate PDF</button>
                                        <?php endif; ?>
                                    </td>
                                    <td style="color: #6b7280; font-size: 13px;">
                                        <?php 
                                        $dateRequested = $request['dateRequested'] ?? '';
                                        if ($dateRequested) {
                                            try {
                                                $date = new DateTime($dateRequested);
                                                echo $date->format('M d, Y') . '<br><span style="color: #9ca3af; font-size: 12px;">' . $date->format('h:i A') . '</span>';
                                            } catch (Exception $e) {
                                                echo htmlspecialchars($dateRequested);
                                            }
                                        } else {
                                            echo '—';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <form method="POST" action="" style="display: inline;" onsubmit="return updateStatus(this, '<?php echo htmlspecialchars($request['id'] ?? ''); ?>')">
                                            <input type="hidden" name="action" value="update_status">
                                            <input type="hidden" name="request_id" value="<?php echo htmlspecialchars($request['id'] ?? ''); ?>">
                                            <?php $disable_status = !$has_pdf; ?>
                                            <select name="status" class="status-select <?php echo strtolower($request['status'] ?? 'pending'); ?>" onchange="this.form.submit()" <?php echo $disable_status ? 'disabled title="Generate PDF first to change status"' : ''; ?>>
                                                <option value="Pending" <?php echo ($request['status'] ?? '') === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="Processing" <?php echo ($request['status'] ?? '') === 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                                <option value="Ready to Pick Up" <?php echo ($request['status'] ?? '') === 'Ready to Pick Up' ? 'selected' : ''; ?>>Ready to Pick Up</option>
                                                <option value="Done" <?php echo ($request['status'] ?? '') === 'Done' ? 'selected' : ''; ?>>Done</option>
                                            </select>
                                        </form>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <?php 
                                            $request_id = $request['id'] ?? '';
                                            $request_name = htmlspecialchars($request['fullname'] ?? 'N/A');
                                            $current_status = strtolower(trim($request['status'] ?? 'pending'));
                                            ?>
                                            <div class="action-buttons-top">
                                                <button class="btn-view" onclick="viewRequest('<?php echo htmlspecialchars($request_id); ?>')">View</button>
                                                <?php if (!empty($request_id)): ?>
                                                    <button class="btn-delete" onclick="deleteRequest('<?php echo htmlspecialchars($request_id); ?>', '<?php echo $request_name; ?>')">Delete</button>
                                                <?php else: ?>
                                                    <button class="btn-delete" style="opacity: 0.5; cursor: not-allowed;" title="Cannot delete: Missing request ID" disabled>Delete</button>
                                                <?php endif; ?>
                                            </div>
                                            <?php if ($current_status === 'ready to pick up' || $current_status === 'readytopickup'): ?>
                                                <div class="action-buttons-bottom">
                                                    <button class="btn-mark-done" onclick="markAsDone('<?php echo htmlspecialchars($request_id); ?>', '<?php echo $request_name; ?>')">Mark as Done</button>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            </div>
        </div>

    <!-- PDF Confirm Modal -->
    <div id="pdfConfirmModal" class="modal modal-confirm">
        <div class="modal-content">
            <div class="modal-body">
                <h3>Generate PDF?</h3>
                <p>We will generate a PDF for this request. Continue?</p>
                <div class="confirm-actions">
                    <button class="confirm-btn cancel" onclick="closePdfConfirmModal()">Cancel</button>
                    <button class="confirm-btn primary" onclick="confirmPdfGeneration()">Yes, generate</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirm Modal -->
    <div id="deleteConfirmModal" class="modal modal-confirm">
        <div class="modal-content">
            <div class="modal-body">
                <h3>Archive this request?</h3>
                <p id="deleteConfirmText">This will move the request to the archive.</p>
                <div class="confirm-actions">
                    <button class="confirm-btn cancel" onclick="closeDeleteConfirmModal()">Cancel</button>
                    <button class="confirm-btn primary" onclick="confirmDelete()">Yes, archive</button>
                </div>
            </div>
        </div>
    </div>

    <!-- View Request Modal -->
    <div id="viewRequestModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Request Details</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body" id="requestModalBody">
                <!-- Request details will be loaded here -->
            </div>
        </div>
    </div>

    <!-- Delete Form -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="request_id" id="deleteRequestId">
    </form>

    <script>
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }

            const pdfConfirmModal = document.getElementById('pdfConfirmModal');
            if (pdfConfirmModal) {
                pdfConfirmModal.addEventListener('click', function(e) {
                    if (e.target === pdfConfirmModal) {
                        closePdfConfirmModal();
                    }
                });
            }

            const deleteConfirmModal = document.getElementById('deleteConfirmModal');
            if (deleteConfirmModal) {
                deleteConfirmModal.addEventListener('click', function(e) {
                    if (e.target === deleteConfirmModal) {
                        closeDeleteConfirmModal();
                    }
                });
            }
        });

        function updateStatus(form, requestId) {
            // Status will be updated via form submission
            return true;
        }

        let pendingPdfRequest = null;

        function openPdfConfirmModal(requestId, buttonElement) {
            pendingPdfRequest = { requestId, buttonElement };
            const modal = document.getElementById('pdfConfirmModal');
            if (modal) {
                modal.classList.add('show');
            }
        }

        function closePdfConfirmModal() {
            const modal = document.getElementById('pdfConfirmModal');
            if (modal) {
                modal.classList.remove('show');
            }
            pendingPdfRequest = null;
        }

        function confirmPdfGeneration() {
            if (!pendingPdfRequest) {
                closePdfConfirmModal();
                return;
            }
            const { requestId, buttonElement } = pendingPdfRequest;
            closePdfConfirmModal();
            generatePDF(requestId, buttonElement, true);
        }

        async function generatePDF(requestId, buttonElement, confirmed = false) {
            if (!confirmed) {
                openPdfConfirmModal(requestId, buttonElement);
                return;
            }

            pendingPdfRequest = null;
            
            try {
                const btn = buttonElement || (typeof event !== 'undefined' ? event.target : null);
                const originalText = btn ? btn.textContent : '';
                
                if (btn) {
                    btn.disabled = true;
                    btn.textContent = 'Generating...';
                }
                
                const formData = new FormData();
                formData.append('request_id', requestId);
                
                const response = await fetch('generate_pdf.php', {
                    method: 'POST',
                    body: formData
                });
                
                const result = await response.json();
                
                if (result.status === 'success') {
                    alert('✅ PDF generated successfully!');
                    // Reload the page to show the new PDF
                    window.location.reload();
                } else {
                    alert('❌ Error: ' + (result.message || 'Failed to generate PDF'));
                    if (btn) {
                        btn.disabled = false;
                        btn.textContent = originalText || 'Generate PDF';
                    }
                }
            } catch (error) {
                console.error('PDF generation error:', error);
                alert('⚠️ Something went wrong while generating PDF.');
                const btn = buttonElement || (typeof event !== 'undefined' ? event.target : null);
                if (btn) {
                    btn.disabled = false;
                    btn.textContent = 'Generate PDF';
                }
            }
        }
        

        async function viewRequest(requestId) {
            try {
                // Find the request from the loaded data
                const requests = <?php echo json_encode($all_requests); ?>;
                const request = requests.find(r => r.id === requestId);
                
                if (!request) {
                    alert('Request not found.');
                    return;
                }

                // Build the modal content
                const od = request.otherDetails || {};
                const fields = {
                    age: 'Age',
                    gender: 'Gender',
                    dob: 'Date of Birth',
                    civil_status: 'Civil Status',
                    address: 'Address',
                    purpose: 'Purpose',
                    contactNum: 'Contact Number',
                    nameBusiness: 'Name of Business',
                    businessType: 'Type/Nature of Business',
                    businessAddress: 'Business Address',
                    dateEstablished: 'Date Established',
                    propertyType: 'Type of Property',
                    description: 'Description / Details',
                    category: 'Category',
                    resName: 'Respondent Name',
                    resAddress: 'Respondent Address',
                    dtIncident: 'Date & Time of Incident',
                    placeIncident: 'Place of Incident'
                };

                let statusClass = (request.status || 'pending').toLowerCase().replace(/\s+/g, '');
                if (statusClass === 'readytopickup') statusClass = 'ready';

                let html = `
                    <div class="detail-group">
                        <label>Full Name</label>
                        <p>${request.fullname || 'N/A'}</p>
                    </div>
                    <div class="detail-group">
                        <label>Document Type</label>
                        <p>${request.documentType || 'N/A'}</p>
                    </div>
                    <div class="detail-group">
                        <label>Date Requested</label>
                        <p>${request.dateRequested || 'N/A'}</p>
                    </div>
                    <div class="detail-group">
                        <label>Status</label>
                        <p><span class="status-badge ${statusClass}">${request.status || 'Pending'}</span></p>
                    </div>
                `;

                if (request.pdf_name) {
                    html += `
                        <div class="detail-group">
                            <label>Generated PDF</label>
                            <p><a href="../data/generated_pdfs/${request.pdf_name}" target="_blank" class="view-pdf-link">View PDF</a></p>
                        </div>
                    `;
                }

                if (request.doneAt) {
                    html += `
                        <div class="detail-group">
                            <label>Completed At</label>
                            <p>${request.doneAt}</p>
                        </div>
                    `;
                }

                // Add other details
                let hasDetails = false;
                let detailsHtml = '<div class="detail-group"><label style="margin-top: 20px; margin-bottom: 10px; font-size: 16px; color: #1a5f3f;">Additional Information</label>';
                
                for (const key in fields) {
                    if (od[key]) {
                        detailsHtml += `
                            <div style="margin-bottom: 12px;">
                                <label style="font-size: 13px; color: #666;">${fields[key]}:</label>
                                <p>${od[key]}</p>
                            </div>
                        `;
                        hasDetails = true;
                    }
                }
                
                if (!hasDetails) {
                    detailsHtml += '<p style="color: #999; font-style: italic;">No additional details provided.</p>';
                }
                detailsHtml += '</div>';

                html += detailsHtml;

                document.getElementById('requestModalBody').innerHTML = html;
                document.getElementById('viewRequestModal').classList.add('show');
            } catch (error) {
                console.error('Error loading request details:', error);
                alert('Could not load request details.');
            }
        }

        function closeModal() {
            document.getElementById('viewRequestModal').classList.remove('show');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('viewRequestModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        let pendingDelete = null;
        function deleteRequest(requestId, fullname) {
            if (!requestId || requestId.trim() === '') {
                alert('Error: Request ID is missing. Cannot delete this request.');
                return;
            }
            pendingDelete = { requestId, fullname };
            const text = document.getElementById('deleteConfirmText');
            if (text) {
                text.textContent = `Are you sure you want to archive the request for "${fullname}"? You can restore it from the archive.`;
            }
            const modal = document.getElementById('deleteConfirmModal');
            if (modal) {
                modal.classList.add('show');
            }
        }

        function closeDeleteConfirmModal() {
            const modal = document.getElementById('deleteConfirmModal');
            if (modal) {
                modal.classList.remove('show');
            }
            pendingDelete = null;
        }

        function confirmDelete() {
            if (!pendingDelete) {
                closeDeleteConfirmModal();
                return;
            }
            const { requestId } = pendingDelete;
            closeDeleteConfirmModal();
            document.getElementById('deleteRequestId').value = requestId;
            document.getElementById('deleteForm').submit();
        }
        
        function markAsDone(requestId, fullname) {
            if (!requestId || requestId.trim() === '') {
                alert('Error: Request ID is missing.');
                return;
            }
            
            if (confirm(`Mark request for "${fullname}" as Done?`)) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = '';
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = 'update_status';
                form.appendChild(actionInput);
                
                const requestIdInput = document.createElement('input');
                requestIdInput.type = 'hidden';
                requestIdInput.name = 'request_id';
                requestIdInput.value = requestId;
                form.appendChild(requestIdInput);
                
                const statusInput = document.createElement('input');
                statusInput.type = 'hidden';
                statusInput.name = 'status';
                statusInput.value = 'Done';
                form.appendChild(statusInput);
                
                document.body.appendChild(form);
                form.submit();
            }
        }
        
    </script>
</body>
</html>

