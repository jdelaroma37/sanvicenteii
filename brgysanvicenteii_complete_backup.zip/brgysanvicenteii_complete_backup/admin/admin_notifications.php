<?php
// admin/admin_notifications.php
session_start();
require '../config.php';
require 'role_helper.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Load admin notifications
$notifDir = __DIR__ . '/../data/notifications';
if (!is_dir($notifDir)) mkdir($notifDir, 0777, true);
$adminNotifFile = $notifDir . '/admin_notifications.json';

$admin_notifications = [];
if (file_exists($adminNotifFile)) {
    $admin_notifications = json_decode(file_get_contents($adminNotifFile), true) ?? [];
}

// Filter notifications based on role
$filtered_notifications = [];
foreach ($admin_notifications as $notif) {
    $notif_role = $notif['target_role'] ?? 'all';
    
    // Super admin sees all notifications
    if ($admin_role === 'super_admin') {
        $filtered_notifications[] = $notif;
    } 
    // Regular admin only sees non-security notifications
    else {
        if ($notif_role === 'all' || $notif_role === 'regular_admin') {
            // Exclude security/system notifications
            $excluded_types = ['admin_added', 'password_changed', 'failed_login', 'system_update', 'system_error'];
            if (!in_array($notif['type'] ?? '', $excluded_types)) {
                $filtered_notifications[] = $notif;
            }
        }
    }
}

// Sort by date (newest first)
usort($filtered_notifications, function($a, $b) {
    $dateA = strtotime($a['created_at'] ?? '1970-01-01');
    $dateB = strtotime($b['created_at'] ?? '1970-01-01');
    return $dateB - $dateA;
});

// Filter to show only unread notifications in Recent Notifications
$unread_notifications = [];
foreach ($filtered_notifications as $index => $notif) {
    $is_unread = !isset($notif['read']) || $notif['read'] == false;
    if ($is_unread) {
        // Find original index in admin_notifications array
        $original_index = array_search($notif, $admin_notifications);
        if ($original_index !== false) {
            $unread_notifications[] = [
                'notif' => $notif,
                'index' => $original_index
            ];
        }
    }
}

// Sort unread notifications by date (newest first)
usort($unread_notifications, function($a, $b) {
    $dateA = strtotime($a['notif']['created_at'] ?? '1970-01-01');
    $dateB = strtotime($b['notif']['created_at'] ?? '1970-01-01');
    return $dateB - $dateA;
});

// Filter to show read notifications
$read_notifications = [];
foreach ($filtered_notifications as $index => $notif) {
    $is_read = isset($notif['read']) && $notif['read'] == true;
    if ($is_read) {
        // Find original index in admin_notifications array
        $original_index = array_search($notif, $admin_notifications);
        if ($original_index !== false) {
            $read_notifications[] = [
                'notif' => $notif,
                'index' => $original_index
            ];
        }
    }
}

// Sort read notifications by date (newest first)
usort($read_notifications, function($a, $b) {
    $dateA = strtotime($a['notif']['created_at'] ?? '1970-01-01');
    $dateB = strtotime($b['notif']['created_at'] ?? '1970-01-01');
    return $dateB - $dateA;
});

// Load notification preferences
$prefsFile = $notifDir . '/admin_notification_prefs.json';
$preferences = [];
if (file_exists($prefsFile)) {
    $preferences = json_decode(file_get_contents($prefsFile), true) ?? [];
}

$user_prefs = $preferences[$admin_id] ?? [
    'email_enabled' => true,
    'in_app_enabled' => true
];

// Handle preference updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_preferences'])) {
    $user_prefs['email_enabled'] = isset($_POST['email_enabled']);
    $user_prefs['in_app_enabled'] = isset($_POST['in_app_enabled']);
    $user_prefs['push_enabled'] = isset($_POST['push_enabled']);
    
    $preferences[$admin_id] = $user_prefs;
    file_put_contents($prefsFile, json_encode($preferences, JSON_PRETTY_PRINT));
    
    $_SESSION['success'] = 'Notification preferences updated successfully!';
    header('Location: admin_notifications.php');
    exit;
}

// Mark notification as read
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    $notif_index = intval($_GET['mark_read']);
    if (isset($admin_notifications[$notif_index])) {
        $admin_notifications[$notif_index]['read'] = true;
        file_put_contents($adminNotifFile, json_encode($admin_notifications, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        header('Location: admin_notifications.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notifications - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(245, 245, 220, 0.8);
            box-shadow: 0 0 8px rgba(245, 245, 220, 0.4);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
                width: 100%;
            height: 100%;
            display: block;
            }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
                padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .row-container > .section-title:first-child {
            margin-top: 0;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .content-card {
            background: white;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            border: 1px solid #e5e7eb;
        }
        .content-card h2 {
            font-size: 22px;
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .content-card h2 svg {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.7;
        }
        .notification-item {
            background: white;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            animation: slideIn 0.4s ease-out;
            opacity: 1;
            transform: translateX(0);
        }
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        .notification-item.fade-out {
            animation: fadeOut 0.4s ease-out forwards;
        }
        @keyframes fadeOut {
            from {
                opacity: 1;
                transform: translateX(0);
                max-height: 200px;
                margin-bottom: 15px;
            }
            to {
                opacity: 0;
                transform: translateX(-20px);
                max-height: 0;
                margin-bottom: 0;
                padding-top: 0;
                padding-bottom: 0;
            }
        }
        .notification-item:last-child {
            margin-bottom: 0;
        }
        .notification-item:hover {
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }
        .notification-item.unread {
            background: #f0f7ff;
            border-left: 4px solid #0077b6;
            padding-left: 16px;
        }
        .notification-item.read {
            background: #f9faf9;
            border-left: 4px solid #e5e7eb;
            padding-left: 16px;
            opacity: 0.8;
        }
        .notification-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 10px;
            flex-wrap: wrap;
            gap: 10px;
        }
        .notification-title {
            font-size: 18px;
            font-weight: 700;
            color: #1f2937;
            margin: 0;
        }
        .notification-date {
            font-size: 14px;
            color: #6b7280;
            white-space: nowrap;
        }
        .notification-message {
            color: #4b5563;
            line-height: 1.6;
            margin-bottom: 10px;
        }
        .notification-actions {
            margin-top: 10px;
        }
        .notification-actions a {
            color: #0077b6;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.2s;
            display: inline-block;
        }
        .notification-actions a:hover {
            text-decoration: underline;
            transform: scale(1.05);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #9ca3af;
        }
        .empty-state svg {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            opacity: 0.3;
            color: #9ca3af;
        }
        .empty-state p {
            font-size: 16px;
            margin: 0;
            color: #6b7280;
        }
        .info-box {
            background: #f0f7ff;
            border: 1px solid #d4e6ff;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
        }
        .info-box p {
            margin: 0;
            color: #2c3e2d;
            line-height: 1.6;
            font-weight: 500;
        }
        .preferences-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        .preferences-section button[type="submit"] {
            padding: 10px 20px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 15px;
        }
        .preferences-section button[type="submit"]:hover {
            background: #1a5f3f;
            transform: translateY(-1px);
        }
        .pref-checkbox {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding: 12px;
            background: white;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.2s;
        }
        .pref-checkbox:hover {
            background: #f0f0f0;
        }
        .pref-checkbox input[type="checkbox"] {
            width: 18px;
            height: 18px;
            margin-right: 12px;
            cursor: pointer;
        }
        .pref-checkbox label {
            cursor: pointer;
            font-size: 15px;
            font-weight: 500;
            color: #333;
            margin: 0;
            flex: 1;
        }
        .warning-box {
            padding: 20px;
            background: #fff3cd;
            border-radius: 8px;
            border-left: 4px solid #ffc107;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }
        .warning-box p {
            margin: 0;
            color: #856404;
            line-height: 1.6;
            font-size: 15px;
        }
        .warning-box strong {
            color: #856404;
            font-weight: 700;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            transition: all 0.2s;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .stat-card:hover {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }
        .stat-label {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 600;
        }
        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: #2c3e2d;
        }
        .stat-value.unread {
            color: #dc3545;
        }
        .stat-value.read {
            color: #28a745;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .page-title {
                font-size: 24px;
            }
            .notification-header {
                flex-direction: column;
            }
            .row-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
            </svg>
            </span>
            Notifications
        </h1>
        
        <?php if ($admin_role === 'super_admin'): ?>
        <!-- Super Admin Notifications -->
        
        <!-- Actual Notifications -->
        <div class="row-container">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <path d="M22 6l-10 7L2 6"/>
                </svg>
                </span>
                Recent Notifications
            </h2>
            
            <?php if (count($unread_notifications) > 0): ?>
                <div id="notifications-container">
                    <?php foreach ($unread_notifications as $item): 
                        $notif = $item['notif'];
                        $index = $item['index'];
                    ?>
                        <div class="notification-item unread" data-index="<?php echo $index; ?>" id="notif-<?php echo $index; ?>">
                            <div class="notification-header">
                                <h3 class="notification-title"><?php echo htmlspecialchars($notif['title'] ?? 'Notification'); ?></h3>
                                <span class="notification-date"><?php echo date('M d, Y h:i A', strtotime($notif['created_at'] ?? 'now')); ?></span>
                            </div>
                            <div class="notification-message">
                                <?php echo htmlspecialchars($notif['message'] ?? ''); ?>
                            </div>
                            <div class="notification-actions">
                                <a href="#" class="mark-read-btn" data-index="<?php echo $index; ?>">Mark as Read</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                        <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                    </svg>
                    <p>No unread notifications at this time.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Read Notifications -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 11l3 3L22 4"/>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                    </svg>
                </span>
                Read Notifications
            </h2>
            
            <?php if (count($read_notifications) > 0): ?>
                <div id="read-notifications-container">
                    <?php foreach ($read_notifications as $item): 
                        $notif = $item['notif'];
                        $index = $item['index'];
                    ?>
                        <div class="notification-item read" data-index="<?php echo $index; ?>" id="read-notif-<?php echo $index; ?>">
                            <div class="notification-header">
                                <h3 class="notification-title"><?php echo htmlspecialchars($notif['title'] ?? 'Notification'); ?></h3>
                                <span class="notification-date"><?php echo date('M d, Y h:i A', strtotime($notif['created_at'] ?? 'now')); ?></span>
                            </div>
                            <div class="notification-message">
                                <?php echo htmlspecialchars($notif['message'] ?? ''); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M9 11l3 3L22 4"/>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                    </svg>
                    <p>No read notifications yet.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Notification Statistics -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="20" x2="12" y2="10"></line>
                        <line x1="18" y1="20" x2="18" y2="4"></line>
                        <line x1="6" y1="20" x2="6" y2="16"></line>
                    </svg>
                </span>
                Notification Statistics
            </h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <div class="stat-card">
                    <div class="stat-label">Total Notifications</div>
                    <div class="stat-value"><?php echo count($filtered_notifications); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Unread</div>
                    <div class="stat-value unread">
                        <?php 
                        $unread_count = 0;
                        foreach ($filtered_notifications as $notif) {
                            if (!isset($notif['read']) || $notif['read'] == false) {
                                $unread_count++;
                            }
                        }
                        echo $unread_count;
                        ?>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Read</div>
                    <div class="stat-value read">
                        <?php 
                        $read_count = count($filtered_notifications) - $unread_count;
                        echo $read_count;
                        ?>
                    </div>
                </div>
                </div>
        </div>
        
        <!-- Notification Preferences -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                </svg>
                </span>
                Notification Preferences
            </h2>
            <div class="info-box">
                <p>Choose whether to receive email notifications or disable them to avoid spam.</p>
            </div>
            
            <form method="POST" class="preferences-section">
                <input type="hidden" name="update_preferences" value="1">
                <div class="pref-checkbox">
                    <input type="checkbox" name="email_enabled" id="email_enabled" <?php echo $user_prefs['email_enabled'] ? 'checked' : ''; ?>>
                    <label for="email_enabled">Enable Email Notifications</label>
                </div>
                <div class="pref-checkbox">
                    <input type="checkbox" name="in_app_enabled" id="in_app_enabled" <?php echo $user_prefs['in_app_enabled'] ? 'checked' : ''; ?>>
                    <label for="in_app_enabled">Enable In-App Notifications</label>
                </div>
                <div class="pref-checkbox">
                    <input type="checkbox" name="push_enabled" id="push_enabled" <?php echo ($user_prefs['push_enabled'] ?? false) ? 'checked' : ''; ?>>
                    <label for="push_enabled">Enable Push Notifications</label>
                </div>
                <button type="submit">Save Preferences</button>
            </form>
            <div id="push-status" style="margin-top: 15px; padding: 10px; border-radius: 6px; display: none;"></div>
            <button id="enablePushBtn" style="display: none; margin-top: 10px; padding: 10px 20px; background: #2c3e2d; color: white; border: none; border-radius: 6px; cursor: pointer;">Enable Push Notifications</button>
        </div>
        
        <?php else: ?>
        <!-- Regular Admin Notifications -->
        
        <!-- Actual Notifications -->
        <div class="row-container">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <path d="M22 6l-10 7L2 6"/>
                </svg>
                </span>
                Recent Notifications
            </h2>
            
            <?php if (count($unread_notifications) > 0): ?>
                <div id="notifications-container">
                    <?php foreach ($unread_notifications as $item): 
                        $notif = $item['notif'];
                        $index = $item['index'];
                    ?>
                        <div class="notification-item unread" data-index="<?php echo $index; ?>" id="notif-<?php echo $index; ?>">
                            <div class="notification-header">
                                <h3 class="notification-title"><?php echo htmlspecialchars($notif['title'] ?? 'Notification'); ?></h3>
                                <span class="notification-date"><?php echo date('M d, Y h:i A', strtotime($notif['created_at'] ?? 'now')); ?></span>
                            </div>
                            <div class="notification-message">
                                <?php echo htmlspecialchars($notif['message'] ?? ''); ?>
                            </div>
                            <div class="notification-actions">
                                <a href="#" class="mark-read-btn" data-index="<?php echo $index; ?>">Mark as Read</a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                        <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
                    </svg>
                    <p>No unread notifications at this time.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Read Notifications -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 11l3 3L22 4"/>
                    <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                    </svg>
                </span>
                Read Notifications
            </h2>
            
            <?php if (count($read_notifications) > 0): ?>
                <div id="read-notifications-container">
                    <?php foreach ($read_notifications as $item): 
                        $notif = $item['notif'];
                        $index = $item['index'];
                    ?>
                        <div class="notification-item read" data-index="<?php echo $index; ?>" id="read-notif-<?php echo $index; ?>">
                            <div class="notification-header">
                                <h3 class="notification-title"><?php echo htmlspecialchars($notif['title'] ?? 'Notification'); ?></h3>
                                <span class="notification-date"><?php echo date('M d, Y h:i A', strtotime($notif['created_at'] ?? 'now')); ?></span>
                            </div>
                            <div class="notification-message">
                                <?php echo htmlspecialchars($notif['message'] ?? ''); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M9 11l3 3L22 4"/>
                        <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
                    </svg>
                    <p>No read notifications yet.</p>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Notification Statistics -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="20" x2="12" y2="10"></line>
                        <line x1="18" y1="20" x2="18" y2="4"></line>
                        <line x1="6" y1="20" x2="6" y2="16"></line>
                    </svg>
                </span>
                Notification Statistics
            </h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                <div class="stat-card">
                    <div class="stat-label">Total Notifications</div>
                    <div class="stat-value"><?php echo count($filtered_notifications); ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Unread</div>
                    <div class="stat-value unread">
                        <?php 
                        $unread_count = 0;
                        foreach ($filtered_notifications as $notif) {
                            if (!isset($notif['read']) || $notif['read'] == false) {
                                $unread_count++;
                            }
                        }
                        echo $unread_count;
                        ?>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-label">Read</div>
                    <div class="stat-value read">
                        <?php 
                        $read_count = count($filtered_notifications) - $unread_count;
                        echo $read_count;
                        ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Warning Note -->
        <div class="row-container" style="margin-top: 20px;">
            <div class="warning-box">
                <p><strong>Note:</strong> Walang access sa security or system-wide alerts. Di sila makakatanggap ng system security alerts, user management changes, o backend updates. Ito ay para maprotektahan ang sensitibong impormasyon at control ng Super Admin.</p>
            </div>
        </div>
        
        <!-- Notification Preferences -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                </svg>
                </span>
                Notification Preferences
            </h2>
            <div class="info-box">
                <p>Choose whether to receive notifications via email or in-app to avoid being overwhelmed.</p>
            </div>
            
            <form method="POST" class="preferences-section">
                <input type="hidden" name="update_preferences" value="1">
                <div class="pref-checkbox">
                    <input type="checkbox" name="email_enabled" id="email_enabled" <?php echo $user_prefs['email_enabled'] ? 'checked' : ''; ?>>
                    <label for="email_enabled">Enable Email Notifications</label>
                </div>
                <div class="pref-checkbox">
                    <input type="checkbox" name="in_app_enabled" id="in_app_enabled" <?php echo $user_prefs['in_app_enabled'] ? 'checked' : ''; ?>>
                    <label for="in_app_enabled">Enable In-App Notifications</label>
                </div>
                <div class="pref-checkbox">
                    <input type="checkbox" name="push_enabled" id="push_enabled" <?php echo ($user_prefs['push_enabled'] ?? false) ? 'checked' : ''; ?>>
                    <label for="push_enabled">Enable Push Notifications</label>
                </div>
                <button type="submit">Save Preferences</button>
            </form>
            <div id="push-status" style="margin-top: 15px; padding: 10px; border-radius: 6px; display: none;"></div>
            <button id="enablePushBtn" style="display: none; margin-top: 10px; padding: 10px 20px; background: #2c3e2d; color: white; border: none; border-radius: 6px; cursor: pointer;">Enable Push Notifications</button>
        </div>
        
        <?php endif; ?>
    </div>
    
    <?php if (isset($_SESSION['success'])): ?>
    <script>
        alert('<?php echo addslashes($_SESSION['success']); ?>');
    </script>
    <?php unset($_SESSION['success']); endif; ?>
    
    <script>
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                // Show/hide floating toggle button
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        // Initialize sidebar state
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
            
            // Handle mark as read with AJAX
            document.querySelectorAll('.mark-read-btn').forEach(function(btn) {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const index = this.getAttribute('data-index');
                    const notificationItem = document.getElementById('notif-' + index);
                    
                    if (!notificationItem) return;
                    
                    // Send AJAX request to mark as read
                    fetch('mark_notification_read.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ index: parseInt(index) })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // Add fade-out animation
                            notificationItem.classList.add('fade-out');
                            
                            // Remove from DOM after animation and add to read notifications
                            setTimeout(function() {
                                const readContainer = document.getElementById('read-notifications-container');
                                const notifTitle = notificationItem.querySelector('.notification-title').textContent;
                                const notifMessage = notificationItem.querySelector('.notification-message').textContent;
                                const notifDate = notificationItem.querySelector('.notification-date').textContent;
                                
                                // Create new read notification item
                                const readNotif = document.createElement('div');
                                readNotif.className = 'notification-item read';
                                readNotif.setAttribute('data-index', index);
                                readNotif.setAttribute('id', 'read-notif-' + index);
                                readNotif.style.animation = 'slideIn 0.4s ease-out';
                                readNotif.innerHTML = `
                                    <div class="notification-header">
                                        <h3 class="notification-title">${notifTitle}</h3>
                                        <span class="notification-date">${notifDate}</span>
                                    </div>
                                    <div class="notification-message">${notifMessage}</div>
                                `;
                                
                                // Remove from unread container
                                notificationItem.remove();
                                
                                // Add to read container
                                if (readContainer) {
                                    readContainer.insertBefore(readNotif, readContainer.firstChild);
                                } else {
                                    // If read container doesn't exist, create it
                                    const readSection = document.querySelector('.row-container:has(#read-notifications-container)');
                                    if (readSection) {
                                        const newContainer = document.createElement('div');
                                        newContainer.id = 'read-notifications-container';
                                        newContainer.appendChild(readNotif);
                                        const emptyState = readSection.querySelector('.empty-state');
                                        if (emptyState) {
                                            emptyState.replaceWith(newContainer);
                                        }
                                    }
                                }
                                
                                // Check if no more unread notifications
                                const container = document.getElementById('notifications-container');
                                if (container && container.children.length === 0) {
                                    container.innerHTML = '<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg><p>No unread notifications at this time.</p></div>';
                                }
                            }, 400);
                        } else {
                            alert('Error: ' + (data.message || 'Could not mark notification as read'));
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('An error occurred while marking the notification as read.');
                    });
                });
            });
        });

        // Push Notification Support with Service Worker
        const VAPID_PUBLIC_KEY = 'YOUR_VAPID_PUBLIC_KEY_HERE'; // Replace with your VAPID public key
        let pushSubscription = null;
        let serviceWorkerRegistration = null;

        // Register Service Worker
        async function registerServiceWorker() {
          if ('serviceWorker' in navigator) {
            try {
              const registration = await navigator.serviceWorker.register('../sw.js');
              console.log('Service Worker registered:', registration);
              serviceWorkerRegistration = registration;
              return registration;
            } catch (error) {
              console.error('Service Worker registration failed:', error);
              return null;
            }
          }
          return null;
        }

        // Subscribe to Push Notifications
        async function subscribeToPush() {
          if (!serviceWorkerRegistration) {
            console.error('Service Worker not registered');
            return false;
          }

          try {
            const permission = await Notification.requestPermission();
            if (permission !== 'granted') {
              console.log('Notification permission denied');
              updatePushStatus('Permission denied. Please enable notifications in your browser settings.', 'error');
              return false;
            }

            const subscription = await serviceWorkerRegistration.pushManager.subscribe({
              userVisibleOnly: true,
              applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
            });

            pushSubscription = subscription;

            const response = await fetch('../push_subscribe.php', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                subscription: {
                  endpoint: subscription.endpoint,
                  keys: {
                    p256dh: arrayBufferToBase64(subscription.getKey('p256dh')),
                    auth: arrayBufferToBase64(subscription.getKey('auth'))
                  }
                }
              })
            });

            const data = await response.json();
            if (data.success) {
              updatePushStatus('Push notifications enabled successfully!', 'success');
              const checkbox = document.getElementById('push_enabled') || document.getElementById('push_enabled_regular');
              if (checkbox) checkbox.checked = true;
              return true;
            } else {
              updatePushStatus('Failed to enable push notifications: ' + (data.message || 'Unknown error'), 'error');
              return false;
            }
          } catch (error) {
            console.error('Push subscription error:', error);
            updatePushStatus('Error: ' + error.message, 'error');
            return false;
          }
        }

        // Unsubscribe from Push Notifications
        async function unsubscribeFromPush() {
          if (!pushSubscription) {
            if (serviceWorkerRegistration) {
              pushSubscription = await serviceWorkerRegistration.pushManager.getSubscription();
            }
          }

          if (pushSubscription) {
            try {
              await pushSubscription.unsubscribe();
              await fetch('../push_subscribe.php', {
                method: 'DELETE'
              });

              pushSubscription = null;
              updatePushStatus('Push notifications disabled.', 'info');
              const checkbox = document.getElementById('push_enabled') || document.getElementById('push_enabled_regular');
              if (checkbox) checkbox.checked = false;
              return true;
            } catch (error) {
              console.error('Unsubscribe error:', error);
              return false;
            }
          }
          return false;
        }

        // Check existing subscription
        async function checkPushSubscription() {
          if (!serviceWorkerRegistration) return false;

          try {
            const subscription = await serviceWorkerRegistration.pushManager.getSubscription();
            if (subscription) {
              pushSubscription = subscription;
              const checkbox = document.getElementById('push_enabled') || document.getElementById('push_enabled_regular');
              if (checkbox) checkbox.checked = true;
              updatePushStatus('Push notifications are active.', 'success');
              return true;
            } else {
              const checkbox = document.getElementById('push_enabled') || document.getElementById('push_enabled_regular');
              if (checkbox) checkbox.checked = false;
              updatePushStatus('Push notifications are not enabled.', 'info');
              return false;
            }
          } catch (error) {
            console.error('Check subscription error:', error);
            return false;
          }
        }

        // Helper functions
        function urlBase64ToUint8Array(base64String) {
          const padding = '='.repeat((4 - base64String.length % 4) % 4);
          const base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');

          const rawData = window.atob(base64);
          const outputArray = new Uint8Array(rawData.length);

          for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
          }
          return outputArray;
        }

        function arrayBufferToBase64(buffer) {
          const bytes = new Uint8Array(buffer);
          let binary = '';
          for (let i = 0; i < bytes.byteLength; i++) {
            binary += String.fromCharCode(bytes[i]);
          }
          return window.btoa(binary);
        }

        function updatePushStatus(message, type = 'info') {
          const statusDiv = document.getElementById('push-status') || document.getElementById('push-status-regular');
          if (!statusDiv) return;

          statusDiv.style.display = 'block';
          statusDiv.textContent = message;
          statusDiv.style.background = type === 'success' ? '#d4edda' : type === 'error' ? '#f8d7da' : '#d1ecf1';
          statusDiv.style.color = type === 'success' ? '#155724' : type === 'error' ? '#721c24' : '#0c5460';
          statusDiv.style.border = `1px solid ${type === 'success' ? '#c3e6cb' : type === 'error' ? '#f5c6cb' : '#bee5eb'}`;

          if (type === 'success' || type === 'info') {
            setTimeout(() => {
              statusDiv.style.display = 'none';
            }, 5000);
          }
        }

        // Initialize push notifications
        (async function() {
          await registerServiceWorker();

          if (serviceWorkerRegistration) {
            await checkPushSubscription();
          }

          const enablePushBtn = document.getElementById('enablePushBtn') || document.getElementById('enablePushBtnRegular');
          if (enablePushBtn) {
            enablePushBtn.addEventListener('click', async () => {
              await subscribeToPush();
            });
          }

          const pushEnabledCheckbox = document.getElementById('push_enabled') || document.getElementById('push_enabled_regular');
          if (pushEnabledCheckbox) {
            pushEnabledCheckbox.addEventListener('change', async (e) => {
              if (e.target.checked) {
                await subscribeToPush();
              } else {
                await unsubscribeFromPush();
              }
            });
          }

          if (!pushSubscription && 'serviceWorker' in navigator && 'PushManager' in window) {
            if (enablePushBtn) {
              enablePushBtn.style.display = 'block';
            }
          }
        })();
    </script>
</body>
</html>
