<?php
// admin/admin_manage_admins.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Only super admin can access this page
if ($admin_role !== 'super_admin') {
    $_SESSION['error'] = 'Access denied. Only Super Admins can access this page.';
    header('Location: admin_dashboard.php');
    exit;
}

// Ensure admins table has required columns
try {
    $admin_columns = $pdo->query("SHOW COLUMNS FROM admins")->fetchAll(PDO::FETCH_COLUMN);

    $requiredColumns = [
        'phone' => "ALTER TABLE admins ADD COLUMN phone VARCHAR(50) DEFAULT NULL AFTER email",
        'messenger' => "ALTER TABLE admins ADD COLUMN messenger VARCHAR(255) DEFAULT NULL AFTER phone",
        'status' => "ALTER TABLE admins ADD COLUMN status ENUM('active','disabled') DEFAULT 'active' AFTER messenger",
        'notes' => "ALTER TABLE admins ADD COLUMN notes TEXT DEFAULT NULL AFTER status",
        'last_login' => "ALTER TABLE admins ADD COLUMN last_login TIMESTAMP NULL DEFAULT NULL AFTER notes",
        'force_password_reset' => "ALTER TABLE admins ADD COLUMN force_password_reset TINYINT(1) DEFAULT 0 AFTER last_login",
        'two_factor_enabled' => "ALTER TABLE admins ADD COLUMN two_factor_enabled TINYINT(1) DEFAULT 0 AFTER force_password_reset"
    ];

    foreach ($requiredColumns as $column => $statement) {
        if (!in_array($column, $admin_columns, true)) {
            try {
                $pdo->exec($statement);
            } catch (PDOException $e) {
                // column might already exist or statement unsupported; ignore
            }
        }
    }
} catch (Exception $e) {
    // ignore
}

// Auto-create tables if they don't exist
try {
    // Check and create barangay_workers table
    $stmt = $pdo->query("SHOW TABLES LIKE 'barangay_workers'");
    if ($stmt->rowCount() === 0) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS barangay_workers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            position VARCHAR(100) NOT NULL,
            mobile VARCHAR(50) DEFAULT NULL,
            email VARCHAR(255) DEFAULT NULL UNIQUE,
            password VARCHAR(255) DEFAULT NULL,
            messenger VARCHAR(255) DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_by INT DEFAULT NULL,
            FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL,
            INDEX idx_position (position),
            INDEX idx_email (email),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } else {
        // Add password column if it doesn't exist
        try {
            $pdo->exec("ALTER TABLE barangay_workers ADD COLUMN password VARCHAR(255) DEFAULT NULL AFTER email");
        } catch (PDOException $e) {
            // Column might already exist, that's okay
        }
        // Add unique constraint to email if not exists
        try {
            $pdo->exec("ALTER TABLE barangay_workers ADD UNIQUE KEY idx_email_unique (email)");
        } catch (PDOException $e) {
            // Constraint might already exist, that's okay
        }
    }
    
    // Check and create worker_responsibilities table
    $stmt = $pdo->query("SHOW TABLES LIKE 'worker_responsibilities'");
    if ($stmt->rowCount() === 0) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS worker_responsibilities (
            id INT AUTO_INCREMENT PRIMARY KEY,
            worker_id INT NOT NULL,
            responsibility_type ENUM('Document Processing', 'Resident Verification', 'Complaints Handling', 'Financial Tasks', 'Patrol Duties', 'Health Services', 'Other') NOT NULL,
            description TEXT DEFAULT NULL,
            status ENUM('Active', 'Inactive') DEFAULT 'Active',
            assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            assigned_by INT DEFAULT NULL,
            FOREIGN KEY (worker_id) REFERENCES barangay_workers(id) ON DELETE CASCADE,
            FOREIGN KEY (assigned_by) REFERENCES admins(id) ON DELETE SET NULL,
            INDEX idx_worker_id (worker_id),
            INDEX idx_responsibility_type (responsibility_type),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    
    // Check and create duty_schedules table
    $stmt = $pdo->query("SHOW TABLES LIKE 'duty_schedules'");
    if ($stmt->rowCount() === 0) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS duty_schedules (
            id INT AUTO_INCREMENT PRIMARY KEY,
            worker_id INT NOT NULL,
            schedule_type ENUM('Weekly', 'Monthly', 'One-time') DEFAULT 'Weekly',
            day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') DEFAULT NULL,
            date_specific DATE DEFAULT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            duty_type ENUM('Office Duty', 'Patrol', 'Health Services', 'Event Assignment', 'Other') NOT NULL,
            notes TEXT DEFAULT NULL,
            status ENUM('Active', 'Completed', 'Cancelled') DEFAULT 'Active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_by INT DEFAULT NULL,
            FOREIGN KEY (worker_id) REFERENCES barangay_workers(id) ON DELETE CASCADE,
            FOREIGN KEY (created_by) REFERENCES admins(id) ON DELETE SET NULL,
            INDEX idx_worker_id (worker_id),
            INDEX idx_schedule_type (schedule_type),
            INDEX idx_date_specific (date_specific),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
    
    // Check and create staff_tasks table
    $stmt = $pdo->query("SHOW TABLES LIKE 'staff_tasks'");
    if ($stmt->rowCount() === 0) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS staff_tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            worker_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT DEFAULT NULL,
            status ENUM('Pending', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Pending',
            priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
            deadline DATE DEFAULT NULL,
            completed_at TIMESTAMP NULL DEFAULT NULL,
            assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            assigned_by INT DEFAULT NULL,
            FOREIGN KEY (worker_id) REFERENCES barangay_workers(id) ON DELETE CASCADE,
            FOREIGN KEY (assigned_by) REFERENCES admins(id) ON DELETE SET NULL,
            INDEX idx_worker_id (worker_id),
            INDEX idx_status (status),
            INDEX idx_priority (priority),
            INDEX idx_deadline (deadline)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
} catch (PDOException $e) {
    // If foreign key constraint fails (admins table might not have the structure), create without FK first
    if (strpos($e->getMessage(), 'foreign key constraint') !== false) {
        try {
            // Create tables without foreign keys first
            $pdo->exec("CREATE TABLE IF NOT EXISTS barangay_workers (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                position VARCHAR(100) NOT NULL,
                mobile VARCHAR(50) DEFAULT NULL,
                email VARCHAR(255) DEFAULT NULL UNIQUE,
                password VARCHAR(255) DEFAULT NULL,
                messenger VARCHAR(255) DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_by INT DEFAULT NULL,
                INDEX idx_position (position),
                INDEX idx_email (email),
                INDEX idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            
            $pdo->exec("CREATE TABLE IF NOT EXISTS worker_responsibilities (
                id INT AUTO_INCREMENT PRIMARY KEY,
                worker_id INT NOT NULL,
                responsibility_type ENUM('Document Processing', 'Resident Verification', 'Complaints Handling', 'Financial Tasks', 'Patrol Duties', 'Health Services', 'Other') NOT NULL,
                description TEXT DEFAULT NULL,
                status ENUM('Active', 'Inactive') DEFAULT 'Active',
                assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                assigned_by INT DEFAULT NULL,
                INDEX idx_worker_id (worker_id),
                INDEX idx_responsibility_type (responsibility_type),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            
            $pdo->exec("CREATE TABLE IF NOT EXISTS duty_schedules (
                id INT AUTO_INCREMENT PRIMARY KEY,
                worker_id INT NOT NULL,
                schedule_type ENUM('Weekly', 'Monthly', 'One-time') DEFAULT 'Weekly',
                day_of_week ENUM('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday') DEFAULT NULL,
                date_specific DATE DEFAULT NULL,
                start_time TIME NOT NULL,
                end_time TIME NOT NULL,
                duty_type ENUM('Office Duty', 'Patrol', 'Health Services', 'Event Assignment', 'Other') NOT NULL,
                notes TEXT DEFAULT NULL,
                status ENUM('Active', 'Completed', 'Cancelled') DEFAULT 'Active',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                created_by INT DEFAULT NULL,
                INDEX idx_worker_id (worker_id),
                INDEX idx_schedule_type (schedule_type),
                INDEX idx_date_specific (date_specific),
                INDEX idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            
            $pdo->exec("CREATE TABLE IF NOT EXISTS staff_tasks (
                id INT AUTO_INCREMENT PRIMARY KEY,
                worker_id INT NOT NULL,
                title VARCHAR(255) NOT NULL,
                description TEXT DEFAULT NULL,
                status ENUM('Pending', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Pending',
                priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
                deadline DATE DEFAULT NULL,
                completed_at TIMESTAMP NULL DEFAULT NULL,
                assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                assigned_by INT DEFAULT NULL,
                INDEX idx_worker_id (worker_id),
                INDEX idx_status (status),
                INDEX idx_priority (priority),
                INDEX idx_deadline (deadline)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (PDOException $e2) {
            // Silently fail - tables might already exist or there's another issue
        }
    }
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    // ========== WORKER MANAGEMENT ==========
    if ($action === 'create_worker' || $action === 'edit_worker') {
        $name = trim($_POST['name'] ?? '');
        $position = trim($_POST['position'] ?? '');
        $mobile = trim($_POST['mobile'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $messenger = trim($_POST['messenger'] ?? '');
        
        if (!$name || !$position) {
            $_SESSION['error'] = 'Name and position are required.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        
        try {
            if ($action === 'create_worker') {
                $hashed_password = $password ? password_hash($password, PASSWORD_DEFAULT) : null;
                $stmt = $pdo->prepare("INSERT INTO barangay_workers (name, position, mobile, email, password, messenger, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $position, $mobile ?: null, $email ?: null, $hashed_password, $messenger ?: null, $admin_id]);
                $_SESSION['success'] = 'Barangay worker added successfully!';
            } else {
                $id = intval($_POST['id'] ?? 0);
                // Only update password if provided
                if ($password) {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE barangay_workers SET name = ?, position = ?, mobile = ?, email = ?, password = ?, messenger = ? WHERE id = ?");
                    $stmt->execute([$name, $position, $mobile ?: null, $email ?: null, $hashed_password, $messenger ?: null, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE barangay_workers SET name = ?, position = ?, mobile = ?, email = ?, messenger = ? WHERE id = ?");
                    $stmt->execute([$name, $position, $mobile ?: null, $email ?: null, $messenger ?: null, $id]);
                }
                $_SESSION['success'] = 'Worker updated successfully!';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    } elseif ($action === 'delete_worker') {
        $id = intval($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM barangay_workers WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = 'Worker deleted successfully!';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    }
    
    // ========== RESPONSIBILITIES MANAGEMENT ==========
    elseif ($action === 'create_responsibility' || $action === 'edit_responsibility') {
        $worker_id = intval($_POST['worker_id'] ?? 0);
        $responsibility_type = trim($_POST['responsibility_type'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $status = trim($_POST['status'] ?? 'Active');
        
        if (!$worker_id || !$responsibility_type) {
            $_SESSION['error'] = 'Worker and responsibility type are required.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        
        try {
            if ($action === 'create_responsibility') {
                $stmt = $pdo->prepare("INSERT INTO worker_responsibilities (worker_id, responsibility_type, description, status, assigned_by) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$worker_id, $responsibility_type, $description ?: null, $status, $admin_id]);
                $_SESSION['success'] = 'Responsibility assigned successfully!';
        } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("UPDATE worker_responsibilities SET worker_id = ?, responsibility_type = ?, description = ?, status = ? WHERE id = ?");
                $stmt->execute([$worker_id, $responsibility_type, $description ?: null, $status, $id]);
                $_SESSION['success'] = 'Responsibility updated successfully!';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
                header('Location: admin_manage_admins.php');
                exit;
    } elseif ($action === 'delete_responsibility') {
        $id = intval($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM worker_responsibilities WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = 'Responsibility deleted successfully!';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    }
    
    // ========== SCHEDULE MANAGEMENT ==========
    elseif ($action === 'create_schedule' || $action === 'edit_schedule') {
        $worker_id = intval($_POST['worker_id'] ?? 0);
        $schedule_type = trim($_POST['schedule_type'] ?? 'Weekly');
        $day_of_week = trim($_POST['day_of_week'] ?? '');
        $date_specific = trim($_POST['date_specific'] ?? '');
        $start_time = trim($_POST['start_time'] ?? '');
        $end_time = trim($_POST['end_time'] ?? '');
        $duty_type = trim($_POST['duty_type'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        $status = trim($_POST['status'] ?? 'Active');
        
        if (!$worker_id || !$start_time || !$end_time || !$duty_type) {
            $_SESSION['error'] = 'Worker, time, and duty type are required.';
        header('Location: admin_manage_admins.php');
        exit;
        }
        
        try {
            if ($action === 'create_schedule') {
                $stmt = $pdo->prepare("INSERT INTO duty_schedules (worker_id, schedule_type, day_of_week, date_specific, start_time, end_time, duty_type, notes, status, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$worker_id, $schedule_type, $day_of_week ?: null, $date_specific ?: null, $start_time, $end_time, $duty_type, $notes ?: null, $status, $admin_id]);
                $_SESSION['success'] = 'Schedule created successfully!';
            } else {
                $id = intval($_POST['id'] ?? 0);
                $stmt = $pdo->prepare("UPDATE duty_schedules SET worker_id = ?, schedule_type = ?, day_of_week = ?, date_specific = ?, start_time = ?, end_time = ?, duty_type = ?, notes = ?, status = ? WHERE id = ?");
                $stmt->execute([$worker_id, $schedule_type, $day_of_week ?: null, $date_specific ?: null, $start_time, $end_time, $duty_type, $notes ?: null, $status, $id]);
                $_SESSION['success'] = 'Schedule updated successfully!';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    } elseif ($action === 'delete_schedule') {
        $id = intval($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM duty_schedules WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = 'Schedule deleted successfully!';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    }
    
    // ========== TASK MANAGEMENT ==========
    elseif ($action === 'create_task' || $action === 'edit_task') {
        $worker_id = intval($_POST['worker_id'] ?? 0);
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $status = trim($_POST['status'] ?? 'Pending');
        $priority = trim($_POST['priority'] ?? 'Medium');
        $deadline = trim($_POST['deadline'] ?? '');
        
        if (!$worker_id || !$title) {
            $_SESSION['error'] = 'Worker and task title are required.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        
        try {
            if ($action === 'create_task') {
                $stmt = $pdo->prepare("INSERT INTO staff_tasks (worker_id, title, description, status, priority, deadline, assigned_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$worker_id, $title, $description ?: null, $status, $priority, $deadline ?: null, $admin_id]);
                $_SESSION['success'] = 'Task assigned successfully!';
        } else {
                $id = intval($_POST['id'] ?? 0);
                $completed_at = null;
                if ($status === 'Completed' && $_POST['previous_status'] !== 'Completed') {
                    $completed_at = date('Y-m-d H:i:s');
                }
                $stmt = $pdo->prepare("UPDATE staff_tasks SET worker_id = ?, title = ?, description = ?, status = ?, priority = ?, deadline = ?, completed_at = ? WHERE id = ?");
                $stmt->execute([$worker_id, $title, $description ?: null, $status, $priority, $deadline ?: null, $completed_at, $id]);
                $_SESSION['success'] = 'Task updated successfully!';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    } elseif ($action === 'delete_task') {
        $id = intval($_POST['id'] ?? 0);
        try {
            $stmt = $pdo->prepare("DELETE FROM staff_tasks WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = 'Task deleted successfully!';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    }
    // ========== ADMIN ACCOUNT MANAGEMENT ==========
    elseif ($action === 'create_admin' || $action === 'edit_admin') {
        $full_name = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $role = trim($_POST['role'] ?? 'regular_admin');
        $phone = trim($_POST['phone'] ?? '');
        $messenger = trim($_POST['messenger'] ?? '');
        $status = trim($_POST['status'] ?? 'active');
        $notes = trim($_POST['notes'] ?? '');
        $force_reset = isset($_POST['force_password_reset']) ? 1 : 0;
        $two_factor = isset($_POST['two_factor_enabled']) ? 1 : 0;
        $password = $_POST['password'] ?? '';
        $allowed_roles = ['super_admin', 'regular_admin', 'monitoring_admin'];
        $allowed_statuses = ['active', 'disabled'];

        if (!$full_name || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['error'] = 'Valid name and email are required.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        if (!in_array($role, $allowed_roles, true)) {
            $_SESSION['error'] = 'Invalid admin role selected.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        if (!in_array($status, $allowed_statuses, true)) {
            $_SESSION['error'] = 'Invalid account status.';
            header('Location: admin_manage_admins.php');
            exit;
        }

        try {
            if ($action === 'create_admin') {
                if (strlen($password) < 6) {
                    $_SESSION['error'] = 'Password must be at least 6 characters.';
                    header('Location: admin_manage_admins.php');
                    exit;
                }
                $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $_SESSION['error'] = 'Email already registered for another admin.';
                    header('Location: admin_manage_admins.php');
                    exit;
                }
                $hashed = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO admins (full_name, email, password, role, phone, messenger, status, notes, force_password_reset, two_factor_enabled) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$full_name, $email, $hashed, $role, $phone ?: null, $messenger ?: null, $status, $notes ?: null, $force_reset, $two_factor]);
                $_SESSION['success'] = 'Admin account created successfully!';
            } else {
                $id = intval($_POST['id'] ?? 0);
                if (!$id) {
                    $_SESSION['error'] = 'Invalid admin selected.';
                    header('Location: admin_manage_admins.php');
                    exit;
                }
                $stmt = $pdo->prepare("SELECT id FROM admins WHERE email = ? AND id != ?");
                $stmt->execute([$email, $id]);
                if ($stmt->fetch()) {
                    $_SESSION['error'] = 'Email already belongs to another admin.';
                    header('Location: admin_manage_admins.php');
                    exit;
                }
                if ($password) {
                    if (strlen($password) < 6) {
                        $_SESSION['error'] = 'Password must be at least 6 characters.';
                        header('Location: admin_manage_admins.php');
                        exit;
                    }
                    $hashed = password_hash($password, PASSWORD_DEFAULT);
                    $stmt = $pdo->prepare("UPDATE admins SET full_name = ?, email = ?, password = ?, role = ?, phone = ?, messenger = ?, status = ?, notes = ?, force_password_reset = ?, two_factor_enabled = ? WHERE id = ?");
                    $stmt->execute([$full_name, $email, $hashed, $role, $phone ?: null, $messenger ?: null, $status, $notes ?: null, $force_reset, $two_factor, $id]);
                } else {
                    $stmt = $pdo->prepare("UPDATE admins SET full_name = ?, email = ?, role = ?, phone = ?, messenger = ?, status = ?, notes = ?, force_password_reset = ?, two_factor_enabled = ? WHERE id = ?");
                    $stmt->execute([$full_name, $email, $role, $phone ?: null, $messenger ?: null, $status, $notes ?: null, $force_reset, $two_factor, $id]);
                }
                $_SESSION['success'] = 'Admin account updated successfully!';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    } elseif ($action === 'delete_admin') {
        $id = intval($_POST['id'] ?? 0);
        if (!$id) {
            $_SESSION['error'] = 'Invalid admin selected.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        if ($id === $admin_id) {
            $_SESSION['error'] = 'You cannot delete your own account.';
            header('Location: admin_manage_admins.php');
            exit;
        }
        
        // Protect default super admin accounts from deletion
        $protected_emails = ['weh@gmail.com', 'admin@barangaysanvicente.com'];
        try {
            $stmt = $pdo->prepare("SELECT email FROM admins WHERE id = ?");
            $stmt->execute([$id]);
            $admin_to_delete = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($admin_to_delete && in_array($admin_to_delete['email'], $protected_emails, true)) {
                $_SESSION['error'] = 'This is a protected super admin account and cannot be deleted.';
                header('Location: admin_manage_admins.php');
                exit;
            }
            
            $stmt = $pdo->prepare("DELETE FROM admins WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['success'] = 'Admin account deleted.';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
        }
        header('Location: admin_manage_admins.php');
        exit;
    }
}

// Load barangay workers from database
try {
    $stmt = $pdo->query("SELECT * FROM barangay_workers ORDER BY created_at DESC");
    $workers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
$workers = [];
}

// Load responsibilities
try {
    $stmt = $pdo->query("SELECT r.*, w.name as worker_name FROM worker_responsibilities r LEFT JOIN barangay_workers w ON r.worker_id = w.id ORDER BY r.assigned_at DESC");
    $responsibilities = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $responsibilities = [];
}

// Load schedules
try {
    $stmt = $pdo->query("SELECT s.*, w.name as worker_name FROM duty_schedules s LEFT JOIN barangay_workers w ON s.worker_id = w.id ORDER BY s.date_specific DESC, s.day_of_week ASC, s.start_time ASC");
    $schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $schedules = [];
}

// Load tasks
try {
    $stmt = $pdo->query("SELECT t.*, w.name as worker_name FROM staff_tasks t LEFT JOIN barangay_workers w ON t.worker_id = w.id ORDER BY t.assigned_at DESC");
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $tasks = [];
}

// Load admin accounts
try {
    $stmt = $pdo->query("SELECT id, full_name, email, role, phone, messenger, status, notes, last_login, force_password_reset, two_factor_enabled, created_at FROM admins ORDER BY 
        CASE role 
            WHEN 'super_admin' THEN 0 
            WHEN 'monitoring_admin' THEN 1 
            ELSE 2 
        END, full_name");
    $admin_accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $admin_accounts = [];
}

// Role labels
$admin_role_labels = [
    'super_admin' => 'Super Admin',
    'regular_admin' => 'Regular Admin',
    'monitoring_admin' => 'Monitoring Admin'
];

// Worker positions
$positions = [
    'Barangay Secretary',
    'Treasurer',
    'Barangay Health Worker',
    'Barangay Tanod',
    'Administrative Aide',
    'Volunteer / Enumerator'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin & Staff Management - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar CSS - Same as dashboard */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: none;
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        .page-header {
            margin-bottom: 20px;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 10px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Feature Cards */
        .features-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        .feature-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }
        .feature-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .feature-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .feature-icon {
            width: 48px;
            height: 48px;
            background: #2c3e2d;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            flex-shrink: 0;
        }
        .feature-icon svg {
            width: 24px;
            height: 24px;
        }
        .feature-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 5px;
            letter-spacing: -0.3px;
        }
        .feature-subtitle {
            font-size: 18px;
            color: #6b7280;
            line-height: 1.6;
            font-weight: 600;
        }
        .feature-content {
            margin-top: 15px;
        }
        .btn-primary {
            padding: 12px 24px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .btn-secondary {
            padding: 10px 20px;
            background: #d4af37;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-secondary:hover {
            background: #e6c55a;
            transform: translateY(-2px);
        }
        .btn-edit, .btn-delete {
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-edit {
            background: #d4af37;
            color: white;
        }
        .btn-edit:hover {
            background: #e6c55a;
        }
        .btn-delete {
            background: #c33;
            color: white;
        }
        .btn-delete:hover {
            background: #a22;
        }
        /* Workers List */
        .workers-list {
            margin-top: 20px;
        }
        .worker-item {
            background: rgba(255, 255, 255, 0.5);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        .worker-item:hover {
            border-color: #87A96B;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .worker-info {
            flex: 1;
        }
        .worker-name {
            font-size: 18px;
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 5px;
        }
        .worker-position {
            font-size: 16px;
            color: #6b7280;
            font-weight: 500;
            margin-bottom: 8px;
        }
        .worker-contact {
            font-size: 14px;
            color: #6b7280;
            font-weight: 500;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        .worker-contact span {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .worker-actions {
            display: flex;
            gap: 8px;
        }
        /* Admin Accounts */
        .admin-list {
            margin-top: 20px;
        }
        .admin-item {
            background: rgba(255, 255, 255, 0.65);
            padding: 20px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.05);
            margin-bottom: 16px;
            display: grid;
            gap: 12px;
        }
        .admin-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 12px;
            align-items: start;
        }
        .admin-info {
            display: grid;
            gap: 4px;
        }
        .admin-name {
            font-size: 18px;
            font-weight: 700;
            color: #2c3e2d;
        }
        .admin-email {
            font-size: 14px;
            color: #6b7280;
        }
        .admin-contact {
            font-size: 14px;
            color: #555;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        .admin-meta {
            font-size: 12px;
            color: #6b7280;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .admin-role {
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            background: rgba(44, 62, 45, 0.1);
            color: #1b2c1c;
        }
        .admin-status-group {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        .admin-status {
            font-size: 12px;
            font-weight: 600;
            padding: 4px 12px;
            border-radius: 999px;
            text-transform: uppercase;
        }
        .admin-status.active {
            background: rgba(46, 204, 113, 0.2);
            color: #1b8c4a;
        }
        .admin-status.disabled {
            background: rgba(231, 76, 60, 0.15);
            color: #b33939;
        }
        .admin-flags {
            font-size: 11px;
            color: #555;
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
        }
        .admin-notes {
            font-size: 13px;
            color: #4b5563;
            font-style: italic;
            border-left: 4px solid rgba(44,62,45,0.2);
            padding-left: 10px;
        }
        .admin-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .checkbox-group label {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
            color: #2c3e2d;
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 0;
            width: 100%;
            max-width: 600px;
            max-height: 90vh;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .modal-content form {
            display: flex;
            flex-direction: column;
            max-height: calc(90vh - 120px);
            overflow-y: auto;
            padding: 20px 35px;
            scrollbar-width: thin;
            scrollbar-color: rgba(0, 0, 0, 0.2) transparent;
        }
        .modal-content form::-webkit-scrollbar {
            width: 8px;
        }
        .modal-content form::-webkit-scrollbar-track {
            background: transparent;
        }
        .modal-content form::-webkit-scrollbar-thumb {
            background: rgba(0, 0, 0, 0.2);
            border-radius: 4px;
        }
        .modal-content form::-webkit-scrollbar-thumb:hover {
            background: rgba(0, 0, 0, 0.3);
        }
        .modal-content .modal-header {
            flex-shrink: 0;
            padding: 20px 35px;
            margin-bottom: 0;
        }
        .modal-content .modal-actions {
            flex-shrink: 0;
            padding: 20px 35px;
            margin-top: auto;
            background: rgba(255, 255, 255, 0.5);
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .modal-header h2 {
            font-size: 26px;
            color: #2c3e2d;
            font-weight: 800;
            letter-spacing: -0.3px;
        }
        .close-modal {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 24px;
            padding: 4px;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 700;
            font-size: 16px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-cancel:hover {
            background: #d0d0d0;
        }
        .btn-submit {
            flex: 1;
            padding: 12px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #999;
        }
        .empty-state svg {
            width: 48px;
            height: 48px;
            margin-bottom: 15px;
            opacity: 0.5;
        }
        /* Responsive */
        @media (max-width: 1024px) {
            .features-grid {
                grid-template-columns: 1fr;
            }
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .features-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php 
    if (!isset($admin_role)) {
        $admin_id = $_SESSION['user_id'] ?? 0;
        if (isset($_SESSION['admin_role'])) {
            $admin_role = $_SESSION['admin_role'];
        } elseif (isset($pdo) && $admin_id) {
            try {
                $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
                $_SESSION['admin_role'] = $admin_role;
            } catch (Exception $e) {
                $admin_role = 'regular_admin';
            }
        } else {
            $admin_role = 'regular_admin';
        }
    }
    include 'admin_dashboard_sidebar.php'; 
    ?>

    <!-- Main Content -->
    <div class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <span class="page-title-bar"></span>
                <span class="page-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                </span>
                Admin & Staff Management
            </h1>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <!-- Features Grid -->
        <div class="features-grid">
            <!-- Admin Accounts -->
            <div class="feature-card">
                <div class="feature-header">
                    <div class="feature-icon">
                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M13 14v-1a3 3 0 0 0-3-3H3a3 3 0 0 0-3 3v1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            <circle cx="6" cy="6" r="3" stroke="currentColor" stroke-width="1.5"/>
                            <circle cx="12" cy="5" r="2" stroke="currentColor" stroke-width="1.5"/>
                        </svg>
                    </div>
                    <div>
                        <div class="feature-title">Admin & Monitoring Accounts</div>
                        <div class="feature-subtitle">Add or review every admin account registered in the system.</div>
                    </div>
                </div>
                <div class="feature-content">
                    <button class="btn-primary" onclick="openAdminModal()">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        Add Admin Account
                    </button>
                    <?php if (empty($admin_accounts)): ?>
                        <div class="empty-state" style="padding: 30px 10px;">
                            <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="8" cy="5" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                                <path d="M3 13.5c0-2 2-3.5 5-3.5s5 1.5 5 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            </svg>
                            <p>No admin accounts found</p>
                        </div>
                    <?php else: ?>
                        <div class="admin-list">
                            <?php foreach ($admin_accounts as $admin_account): ?>
                                <div class="admin-item">
                                    <div class="admin-row">
                                        <div class="admin-info">
                                            <div class="admin-name"><?php echo htmlspecialchars($admin_account['full_name'] ?? ''); ?></div>
                                            <div class="admin-email"><?php echo htmlspecialchars($admin_account['email'] ?? ''); ?></div>
                                            <div class="admin-contact">
                                                <?php if (!empty($admin_account['phone'])): ?>
                                                    <span>📞 <?php echo htmlspecialchars($admin_account['phone']); ?></span>
                                                <?php endif; ?>
                                                <?php if (!empty($admin_account['messenger'])): ?>
                                                    <span>💬 <?php echo htmlspecialchars($admin_account['messenger']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            <div class="admin-meta">
                                                <span>Added <?php echo !empty($admin_account['created_at']) ? date('M d, Y', strtotime($admin_account['created_at'])) : 'N/A'; ?></span>
                                                <span>Last login: <?php echo !empty($admin_account['last_login']) ? date('M d, Y h:i A', strtotime($admin_account['last_login'])) : 'Never'; ?></span>
                                            </div>
                                        </div>
                                        <div class="admin-status-group">
                                            <span class="admin-status <?php echo htmlspecialchars($admin_account['status'] ?? 'active'); ?>">
                                                <?php echo htmlspecialchars(ucfirst($admin_account['status'] ?? 'active')); ?>
                                            </span>
                                            <span class="admin-role"><?php echo htmlspecialchars($admin_role_labels[$admin_account['role']] ?? ucfirst(str_replace('_', ' ', $admin_account['role']))); ?></span>
                                            <div class="admin-flags">
                                                <?php if (!empty($admin_account['two_factor_enabled'])): ?>
                                                    <span>🔒 2FA Enabled</span>
                                                <?php endif; ?>
                                                <?php if (!empty($admin_account['force_password_reset'])): ?>
                                                    <span>⚠️ Reset on next login</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="worker-actions" style="flex-shrink:0;">
                                            <button class="btn-edit" onclick="editAdmin(<?php echo htmlspecialchars(json_encode($admin_account), ENT_QUOTES, 'UTF-8'); ?>)">
                                                Edit
                                            </button>
                                            <button class="btn-delete" onclick="deleteAdmin(<?php echo $admin_account['id']; ?>)" <?php echo $admin_account['id'] == $admin_id ? 'disabled style="opacity:0.5; cursor:not-allowed;"' : ''; ?>>
                                                Delete
                                            </button>
                                        </div>
                                    </div>
                                    <?php if (!empty($admin_account['notes'])): ?>
                                        <div class="admin-notes">Notes: <?php echo nl2br(htmlspecialchars($admin_account['notes'])); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- 1. List of Barangay Workers -->
            <div class="feature-card">
                <div class="feature-header">
                    <div class="feature-icon">
                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="8" cy="5" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M3 13.5c0-2 2-3.5 5-3.5s5 1.5 5 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <div>
                        <div class="feature-title">List of Barangay Workers</div>
                        <div class="feature-subtitle">Store contact information for all personnel: Mobile number, Email, Messenger (optional). Easy access to updated list of all workers with edit and delete options.</div>
                    </div>
                </div>
                <div class="feature-content">
                    <button class="btn-primary" onclick="openWorkerModal()">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        Add Worker
                    </button>
                    <div class="workers-list">
                        <?php if (empty($workers)): ?>
                            <div class="empty-state">
                                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <circle cx="8" cy="5" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                                    <path d="M3 13.5c0-2 2-3.5 5-3.5s5 1.5 5 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <p>No workers added yet</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($workers as $worker): ?>
                                <div class="worker-item">
                                    <div class="worker-info">
                                        <div class="worker-name"><?php echo htmlspecialchars($worker['name'] ?? ''); ?></div>
                                        <div class="worker-position"><?php echo htmlspecialchars($worker['position'] ?? ''); ?></div>
                                        <div class="worker-contact">
                                            <?php if (!empty($worker['mobile'])): ?>
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M3 2h10v12H3z" stroke="currentColor" stroke-width="1.5"/>
                                                        <path d="M6 2v2M10 2v2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                                    </svg>
                                                    <?php echo htmlspecialchars($worker['mobile']); ?>
                                                </span>
                                            <?php endif; ?>
                                            <?php if (!empty($worker['email'])): ?>
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <rect x="2" y="3" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                                        <path d="M2 4l6 4 6-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                                    </svg>
                                                    <?php echo htmlspecialchars($worker['email']); ?>
                                                </span>
                                            <?php endif; ?>
                                            <?php if (!empty($worker['messenger'])): ?>
                                                <span>
                                                    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M8 2a6 6 0 0 1 6 6c0 3.3-2.7 6-6 6a6 6 0 0 1-6-6 6 6 0 0 1 6-6z" stroke="currentColor" stroke-width="1.5"/>
                                                        <path d="M5 8h6M8 5v6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                                    </svg>
                                                    <?php echo htmlspecialchars($worker['messenger']); ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="worker-actions">
                                        <button class="btn-edit" onclick="editWorker(<?php echo htmlspecialchars(json_encode($worker)); ?>)">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M11 2l3 3M9 8l3 3M3 12l5-5M2 11l8-8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            Edit
                                        </button>
                                        <button class="btn-delete" onclick="deleteWorker('<?php echo htmlspecialchars($worker['id']); ?>')">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                            </svg>
                                            Delete
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- 2. Assigned Responsibilities -->
            <div class="feature-card">
                <div class="feature-header">
                    <div class="feature-icon">
                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="3" y="3" width="10" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M6 7h4M6 10h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <div>
                        <div class="feature-title">Assigned Responsibilities</div>
                        <div class="feature-subtitle">Each staff member can have assigned roles or jobs: Document processing, Resident verification, Complaints handling, Financial-related tasks, Patrol duties (for tanod). Clear job assignments and accountability.</div>
                    </div>
                </div>
                <div class="feature-content">
                    <button class="btn-primary" onclick="openResponsibilityModal()">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        Manage Responsibilities
                    </button>
                    <div class="responsibilities-list" style="margin-top: 20px;">
                        <?php if (empty($responsibilities)): ?>
                            <div class="empty-state">
                                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="3" y="3" width="10" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                    <path d="M6 7h4M6 10h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <p>No responsibilities assigned yet</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($responsibilities as $resp): ?>
                                <div class="worker-item">
                                    <div class="worker-info">
                                        <div class="worker-name"><?php echo htmlspecialchars($resp['worker_name'] ?? 'Unknown'); ?></div>
                                        <div class="worker-position"><?php echo htmlspecialchars($resp['responsibility_type'] ?? ''); ?></div>
                                        <?php if (!empty($resp['description'])): ?>
                                            <div style="font-size: 14px; color: #6b7280; margin-top: 5px;"><?php echo htmlspecialchars($resp['description']); ?></div>
                                        <?php endif; ?>
                                        <div style="font-size: 12px; color: #999; margin-top: 5px;">
                                            Status: <span style="color: <?php echo $resp['status'] === 'Active' ? '#3c3' : '#999'; ?>"><?php echo htmlspecialchars($resp['status']); ?></span>
                                        </div>
                                    </div>
                                    <div class="worker-actions">
                                        <button class="btn-edit" onclick="editResponsibility(<?php echo htmlspecialchars(json_encode($resp)); ?>)">Edit</button>
                                        <button class="btn-delete" onclick="deleteResponsibility(<?php echo $resp['id']; ?>)">Delete</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- 3. Scheduling / Duty Roster -->
            <div class="feature-card">
                <div class="feature-header">
                    <div class="feature-icon">
                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <div>
                        <div class="feature-title">Scheduling / Duty Roster</div>
                        <div class="feature-subtitle">Create weekly or monthly schedules for: Tanod patrols, Health worker schedules, Office duty hours, Event assignments. Know who is on duty or rest day.</div>
                    </div>
                </div>
                <div class="feature-content">
                    <button class="btn-primary" onclick="openScheduleModal()">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        Create Schedule
                    </button>
                    <div class="schedules-list" style="margin-top: 20px;">
                        <?php if (empty($schedules)): ?>
                            <div class="empty-state">
                                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                    <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                </svg>
                                <p>No schedules created yet</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($schedules as $schedule): ?>
                                <div class="worker-item">
                                    <div class="worker-info">
                                        <div class="worker-name"><?php echo htmlspecialchars($schedule['worker_name'] ?? 'Unknown'); ?></div>
                                        <div class="worker-position">
                                            <?php 
                                            $schedule_text = '';
                                            if ($schedule['schedule_type'] === 'Weekly' && $schedule['day_of_week']) {
                                                $schedule_text = $schedule['day_of_week'];
                                            } elseif ($schedule['date_specific']) {
                                                $schedule_text = date('M d, Y', strtotime($schedule['date_specific']));
                                            }
                                            echo htmlspecialchars($schedule_text . ' - ' . $schedule['duty_type']);
                                            ?>
                                        </div>
                                        <div style="font-size: 14px; color: #6b7280; margin-top: 5px;">
                                            <?php echo date('g:i A', strtotime($schedule['start_time'])); ?> - <?php echo date('g:i A', strtotime($schedule['end_time'])); ?>
                                        </div>
                                        <?php if (!empty($schedule['notes'])): ?>
                                            <div style="font-size: 13px; color: #999; margin-top: 5px;"><?php echo htmlspecialchars($schedule['notes']); ?></div>
                                        <?php endif; ?>
                                        <div style="font-size: 12px; color: #999; margin-top: 5px;">
                                            Status: <span style="color: <?php echo $schedule['status'] === 'Active' ? '#3c3' : '#999'; ?>"><?php echo htmlspecialchars($schedule['status']); ?></span>
                                        </div>
                                    </div>
                                    <div class="worker-actions">
                                        <button class="btn-edit" onclick="editSchedule(<?php echo htmlspecialchars(json_encode($schedule)); ?>)">Edit</button>
                                        <button class="btn-delete" onclick="deleteSchedule(<?php echo $schedule['id']; ?>)">Delete</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- 4. Task Tracking -->
            <div class="feature-card">
                <div class="feature-header">
                    <div class="feature-icon">
                        <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M3 8l2 2 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                            <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
                        </svg>
                    </div>
                    <div>
                        <div class="feature-title">Task Tracking</div>
                        <div class="feature-subtitle">Track tasks assigned to staff: Status (Pending, In-progress, Completed), Deadlines, Assigned personnel, Completion logs. Transparency in workflow and progress monitoring.</div>
                    </div>
                </div>
                <div class="feature-content">
                    <button class="btn-primary" onclick="openTaskModal()">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        Assign Task
                    </button>
                    <div class="tasks-list" style="margin-top: 20px;">
                        <?php if (empty($tasks)): ?>
                            <div class="empty-state">
                                <svg viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M3 8l2 2 6-6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
                                </svg>
                                <p>No tasks assigned yet</p>
                </div>
                        <?php else: ?>
                            <?php foreach ($tasks as $task): ?>
                                <div class="worker-item">
                                    <div class="worker-info">
                                        <div class="worker-name"><?php echo htmlspecialchars($task['worker_name'] ?? 'Unknown'); ?></div>
                                        <div class="worker-position"><?php echo htmlspecialchars($task['title'] ?? ''); ?></div>
                                        <?php if (!empty($task['description'])): ?>
                                            <div style="font-size: 14px; color: #6b7280; margin-top: 5px;"><?php echo htmlspecialchars($task['description']); ?></div>
                                        <?php endif; ?>
                                        <div style="font-size: 12px; color: #999; margin-top: 5px; display: flex; gap: 15px;">
                                            <span>Status: <span style="color: <?php 
                                                $status_colors = ['Pending' => '#ffa500', 'In Progress' => '#0066cc', 'Completed' => '#3c3', 'Cancelled' => '#999'];
                                                echo $status_colors[$task['status']] ?? '#999';
                                            ?>"><?php echo htmlspecialchars($task['status']); ?></span></span>
                                            <span>Priority: <span style="color: <?php 
                                                $priority_colors = ['Low' => '#999', 'Medium' => '#ffa500', 'High' => '#ff6600', 'Urgent' => '#c33'];
                                                echo $priority_colors[$task['priority']] ?? '#999';
                                            ?>"><?php echo htmlspecialchars($task['priority']); ?></span></span>
                                            <?php if ($task['deadline']): ?>
                                                <span>Deadline: <?php echo date('M d, Y', strtotime($task['deadline'])); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="worker-actions">
                                        <button class="btn-edit" onclick="editTask(<?php echo htmlspecialchars(json_encode($task)); ?>)">Edit</button>
                                        <button class="btn-delete" onclick="deleteTask(<?php echo $task['id']; ?>)">Delete</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Admin Modal -->
    <div id="adminModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="adminModalTitle">Add Admin Account</h2>
                <button class="close-modal" onclick="closeAdminModal()">&times;</button>
            </div>
            <form id="adminForm" method="POST" action="">
                <input type="hidden" name="action" id="adminFormAction" value="create_admin">
                <input type="hidden" name="id" id="adminId">

                <div class="form-group">
                    <label for="admin_full_name">Full Name *</label>
                    <input type="text" id="admin_full_name" name="full_name" required>
                </div>

                <div class="form-group">
                    <label for="admin_email">Email Address *</label>
                    <input type="email" id="admin_email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="admin_role">Role *</label>
                    <select id="admin_role" name="role" required>
                        <option value="super_admin">Super Admin</option>
                        <option value="regular_admin" selected>Regular Admin</option>
                        <option value="monitoring_admin">Monitoring Admin</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="admin_phone">Contact Number</label>
                    <input type="text" id="admin_phone" name="phone" placeholder="e.g. 09XX XXX XXXX">
                </div>

                <div class="form-group">
                    <label for="admin_messenger">Messenger Handle</label>
                    <input type="text" id="admin_messenger" name="messenger" placeholder="Messenger username or link">
                </div>

                <div class="form-group">
                    <label for="admin_status">Account Status *</label>
                    <select id="admin_status" name="status" required>
                        <option value="active" selected>Active</option>
                        <option value="disabled">Disabled</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="admin_password">Password <span id="passwordHint">(minimum 6 characters)</span></label>
                    <input type="password" id="admin_password" name="password" minlength="6">
                </div>

                <div class="form-group">
                    <label for="admin_notes">Notes / Remarks</label>
                    <textarea id="admin_notes" name="notes" rows="3" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;"></textarea>
                </div>

                <div class="form-group" id="adminLastLoginRow" style="display:none;">
                    <label>Last Login</label>
                    <div class="read-only-field" id="adminLastLogin">Never</div>
                </div>

                <div class="form-group checkbox-group">
                    <label>
                        <input type="checkbox" id="admin_two_factor" name="two_factor_enabled" value="1">
                        Require two-factor authentication
                    </label>
                </div>

                <div class="form-group checkbox-group">
                    <label>
                        <input type="checkbox" id="admin_force_reset" name="force_password_reset" value="1">
                        Force password reset on next login
                    </label>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeAdminModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Worker Modal -->
    <div id="workerModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Add Barangay Worker</h2>
                <button class="close-modal" onclick="closeWorkerModal()">&times;</button>
            </div>
            <form id="workerForm" method="POST" action="">
                <input type="hidden" name="action" id="formAction" value="create_worker">
                <input type="hidden" name="id" id="workerId">
                
                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" required>
                </div>

                <div class="form-group">
                    <label for="position">Position *</label>
                    <select id="position" name="position" required>
                        <option value="">Select Position</option>
                        <?php foreach ($positions as $pos): ?>
                            <option value="<?php echo htmlspecialchars($pos); ?>"><?php echo htmlspecialchars($pos); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="mobile">Mobile Number</label>
                    <input type="tel" id="mobile" name="mobile" placeholder="09XX XXX XXXX">
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" placeholder="email@example.com">
                </div>

                <div class="form-group">
                    <label for="password">Password (for worker login)</label>
                    <input type="password" id="password" name="password" placeholder="Leave blank to keep current password">
                    <small style="color: #666; font-size: 12px;">Set a password so the worker can login to view their assignments</small>
                </div>

                <div class="form-group">
                    <label for="messenger">Messenger (Optional)</label>
                    <input type="text" id="messenger" name="messenger" placeholder="Messenger username or link">
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeWorkerModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Responsibility Modal -->
    <div id="responsibilityModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="responsibilityModalTitle">Assign Responsibility</h2>
                <button class="close-modal" onclick="closeResponsibilityModal()">&times;</button>
            </div>
            <form id="responsibilityForm" method="POST" action="">
                <input type="hidden" name="action" id="responsibilityFormAction" value="create_responsibility">
                <input type="hidden" name="id" id="responsibilityId">
                
                <div class="form-group">
                    <label for="responsibility_worker_id">Worker *</label>
                    <select id="responsibility_worker_id" name="worker_id" required>
                        <option value="">Select Worker</option>
                        <?php foreach ($workers as $worker): ?>
                            <option value="<?php echo $worker['id']; ?>"><?php echo htmlspecialchars($worker['name'] . ' - ' . $worker['position']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="responsibility_type">Responsibility Type *</label>
                    <select id="responsibility_type" name="responsibility_type" required>
                        <option value="">Select Type</option>
                        <option value="Document Processing">Document Processing</option>
                        <option value="Resident Verification">Resident Verification</option>
                        <option value="Complaints Handling">Complaints Handling</option>
                        <option value="Financial Tasks">Financial Tasks</option>
                        <option value="Patrol Duties">Patrol Duties</option>
                        <option value="Health Services">Health Services</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="responsibility_description">Description</label>
                    <textarea id="responsibility_description" name="description" rows="3" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; font-family: inherit; resize: vertical;"></textarea>
                </div>

                <div class="form-group">
                    <label for="responsibility_status">Status *</label>
                    <select id="responsibility_status" name="status" required>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                    </select>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeResponsibilityModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Schedule Modal -->
    <div id="scheduleModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="scheduleModalTitle">Create Schedule</h2>
                <button class="close-modal" onclick="closeScheduleModal()">&times;</button>
            </div>
            <form id="scheduleForm" method="POST" action="">
                <input type="hidden" name="action" id="scheduleFormAction" value="create_schedule">
                <input type="hidden" name="id" id="scheduleId">
                
                <div class="form-group">
                    <label for="schedule_worker_id">Worker *</label>
                    <select id="schedule_worker_id" name="worker_id" required>
                        <option value="">Select Worker</option>
                        <?php foreach ($workers as $worker): ?>
                            <option value="<?php echo $worker['id']; ?>"><?php echo htmlspecialchars($worker['name'] . ' - ' . $worker['position']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="schedule_type">Schedule Type *</label>
                    <select id="schedule_type" name="schedule_type" required onchange="toggleScheduleFields()">
                        <option value="Weekly">Weekly</option>
                        <option value="Monthly">Monthly</option>
                        <option value="One-time">One-time</option>
                    </select>
                </div>

                <div class="form-group" id="day_of_week_group">
                    <label for="day_of_week">Day of Week *</label>
                    <select id="day_of_week" name="day_of_week">
                        <option value="">Select Day</option>
                        <option value="Monday">Monday</option>
                        <option value="Tuesday">Tuesday</option>
                        <option value="Wednesday">Wednesday</option>
                        <option value="Thursday">Thursday</option>
                        <option value="Friday">Friday</option>
                        <option value="Saturday">Saturday</option>
                        <option value="Sunday">Sunday</option>
                    </select>
                </div>

                <div class="form-group" id="date_specific_group" style="display: none;">
                    <label for="date_specific">Specific Date *</label>
                    <input type="date" id="date_specific" name="date_specific">
                </div>

                <div class="form-group">
                    <label for="start_time">Start Time *</label>
                    <input type="time" id="start_time" name="start_time" required>
                </div>

                <div class="form-group">
                    <label for="end_time">End Time *</label>
                    <input type="time" id="end_time" name="end_time" required>
                </div>

                <div class="form-group">
                    <label for="duty_type">Duty Type *</label>
                    <select id="duty_type" name="duty_type" required>
                        <option value="">Select Type</option>
                        <option value="Office Duty">Office Duty</option>
                        <option value="Patrol">Patrol</option>
                        <option value="Health Services">Health Services</option>
                        <option value="Event Assignment">Event Assignment</option>
                        <option value="Other">Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="schedule_notes">Notes</label>
                    <textarea id="schedule_notes" name="notes" rows="3" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; font-family: inherit; resize: vertical;"></textarea>
                </div>

                <div class="form-group">
                    <label for="schedule_status">Status *</label>
                    <select id="schedule_status" name="status" required>
                        <option value="Active">Active</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeScheduleModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Task Modal -->
    <div id="taskModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="taskModalTitle">Assign Task</h2>
                <button class="close-modal" onclick="closeTaskModal()">&times;</button>
            </div>
            <form id="taskForm" method="POST" action="">
                <input type="hidden" name="action" id="taskFormAction" value="create_task">
                <input type="hidden" name="id" id="taskId">
                <input type="hidden" name="previous_status" id="previousStatus">
                
                <div class="form-group">
                    <label for="task_worker_id">Worker *</label>
                    <select id="task_worker_id" name="worker_id" required>
                        <option value="">Select Worker</option>
                        <?php foreach ($workers as $worker): ?>
                            <option value="<?php echo $worker['id']; ?>"><?php echo htmlspecialchars($worker['name'] . ' - ' . $worker['position']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="task_title">Task Title *</label>
                    <input type="text" id="task_title" name="title" required>
                </div>

                <div class="form-group">
                    <label for="task_description">Description</label>
                    <textarea id="task_description" name="description" rows="4" style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; font-family: inherit; resize: vertical;"></textarea>
                </div>

                <div class="form-group">
                    <label for="task_status">Status *</label>
                    <select id="task_status" name="status" required>
                        <option value="Pending">Pending</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="task_priority">Priority *</label>
                    <select id="task_priority" name="priority" required>
                        <option value="Low">Low</option>
                        <option value="Medium" selected>Medium</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="task_deadline">Deadline</label>
                    <input type="date" id="task_deadline" name="deadline">
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeTaskModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Forms -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete_worker">
        <input type="hidden" name="id" id="deleteId">
    </form>
    <form id="deleteResponsibilityForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete_responsibility">
        <input type="hidden" name="id" id="deleteResponsibilityId">
    </form>
    <form id="deleteScheduleForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete_schedule">
        <input type="hidden" name="id" id="deleteScheduleId">
    </form>
    <form id="deleteTaskForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete_task">
        <input type="hidden" name="id" id="deleteTaskId">
    </form>
    <form id="deleteAdminForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete_admin">
        <input type="hidden" name="id" id="deleteAdminId">
    </form>

    <script>
        function openWorkerModal() {
            document.getElementById('modalTitle').textContent = 'Add Barangay Worker';
            document.getElementById('formAction').value = 'create_worker';
            document.getElementById('workerForm').reset();
            document.getElementById('workerId').value = '';
            document.getElementById('workerModal').classList.add('show');
        }

        function editWorker(worker) {
            document.getElementById('modalTitle').textContent = 'Edit Barangay Worker';
            document.getElementById('formAction').value = 'edit_worker';
            document.getElementById('workerId').value = worker.id;
            document.getElementById('name').value = worker.name || '';
            document.getElementById('position').value = worker.position || '';
            document.getElementById('mobile').value = worker.mobile || '';
            document.getElementById('email').value = worker.email || '';
            document.getElementById('password').value = ''; // Don't show password
            document.getElementById('messenger').value = worker.messenger || '';
            document.getElementById('workerModal').classList.add('show');
        }

        function closeWorkerModal() {
            document.getElementById('workerModal').classList.remove('show');
        }

        function deleteWorker(id) {
            if (confirm('Are you sure you want to delete this worker?')) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
        const modals = ['adminModal', 'workerModal', 'responsibilityModal', 'scheduleModal', 'taskModal'];
            modals.forEach(modalId => {
                const modal = document.getElementById(modalId);
            if (event.target === modal) {
                    if (modalId === 'adminModal') closeAdminModal();
                    else if (modalId === 'workerModal') closeWorkerModal();
                    else if (modalId === 'responsibilityModal') closeResponsibilityModal();
                    else if (modalId === 'scheduleModal') closeScheduleModal();
                    else if (modalId === 'taskModal') closeTaskModal();
                }
            });
        }

        // ========== ADMIN FUNCTIONS ==========
        function openAdminModal() {
            document.getElementById('adminModalTitle').textContent = 'Add Admin Account';
            document.getElementById('adminFormAction').value = 'create_admin';
            document.getElementById('adminForm').reset();
            document.getElementById('adminId').value = '';
            document.getElementById('passwordHint').textContent = '(minimum 6 characters)';
            document.getElementById('admin_status').value = 'active';
            document.getElementById('adminLastLoginRow').style.display = 'none';
            document.getElementById('admin_two_factor').checked = false;
            document.getElementById('admin_force_reset').checked = false;
            document.getElementById('adminModal').classList.add('show');
        }

        function editAdmin(admin) {
            document.getElementById('adminModalTitle').textContent = 'Edit Admin Account';
            document.getElementById('adminFormAction').value = 'edit_admin';
            document.getElementById('adminId').value = admin.id || '';
            document.getElementById('admin_full_name').value = admin.full_name || '';
            document.getElementById('admin_email').value = admin.email || '';
            document.getElementById('admin_role').value = admin.role || 'regular_admin';
            document.getElementById('admin_phone').value = admin.phone || '';
            document.getElementById('admin_messenger').value = admin.messenger || '';
            document.getElementById('admin_status').value = admin.status || 'active';
            document.getElementById('admin_password').value = '';
            document.getElementById('admin_notes').value = admin.notes || '';
            document.getElementById('passwordHint').textContent = '(leave blank to keep current password)';
            document.getElementById('admin_two_factor').checked = !!parseInt(admin.two_factor_enabled ?? 0, 10);
            document.getElementById('admin_force_reset').checked = !!parseInt(admin.force_password_reset ?? 0, 10);
            if (admin.last_login) {
                document.getElementById('adminLastLogin').textContent = admin.last_login;
                document.getElementById('adminLastLoginRow').style.display = 'block';
            } else {
                document.getElementById('adminLastLoginRow').style.display = 'none';
            }
            document.getElementById('adminModal').classList.add('show');
        }

        function closeAdminModal() {
            document.getElementById('adminModal').classList.remove('show');
        }

        function deleteAdmin(id) {
            if (!id) return;
            if (confirm('Are you sure you want to delete this admin account?')) {
                document.getElementById('deleteAdminId').value = id;
                document.getElementById('deleteAdminForm').submit();
            }
        }

        // ========== RESPONSIBILITY FUNCTIONS ==========
        function openResponsibilityModal() {
            document.getElementById('responsibilityModalTitle').textContent = 'Assign Responsibility';
            document.getElementById('responsibilityFormAction').value = 'create_responsibility';
            document.getElementById('responsibilityForm').reset();
            document.getElementById('responsibilityId').value = '';
            document.getElementById('responsibilityModal').classList.add('show');
        }

        function editResponsibility(resp) {
            document.getElementById('responsibilityModalTitle').textContent = 'Edit Responsibility';
            document.getElementById('responsibilityFormAction').value = 'edit_responsibility';
            document.getElementById('responsibilityId').value = resp.id;
            document.getElementById('responsibility_worker_id').value = resp.worker_id || '';
            document.getElementById('responsibility_type').value = resp.responsibility_type || '';
            document.getElementById('responsibility_description').value = resp.description || '';
            document.getElementById('responsibility_status').value = resp.status || 'Active';
            document.getElementById('responsibilityModal').classList.add('show');
        }

        function closeResponsibilityModal() {
            document.getElementById('responsibilityModal').classList.remove('show');
        }

        function deleteResponsibility(id) {
            if (confirm('Are you sure you want to delete this responsibility?')) {
                document.getElementById('deleteResponsibilityId').value = id;
                document.getElementById('deleteResponsibilityForm').submit();
            }
        }

        // ========== SCHEDULE FUNCTIONS ==========
        function openScheduleModal() {
            document.getElementById('scheduleModalTitle').textContent = 'Create Schedule';
            document.getElementById('scheduleFormAction').value = 'create_schedule';
            document.getElementById('scheduleForm').reset();
            document.getElementById('scheduleId').value = '';
            toggleScheduleFields();
            document.getElementById('scheduleModal').classList.add('show');
        }

        function editSchedule(schedule) {
            document.getElementById('scheduleModalTitle').textContent = 'Edit Schedule';
            document.getElementById('scheduleFormAction').value = 'edit_schedule';
            document.getElementById('scheduleId').value = schedule.id;
            document.getElementById('schedule_worker_id').value = schedule.worker_id || '';
            document.getElementById('schedule_type').value = schedule.schedule_type || 'Weekly';
            document.getElementById('day_of_week').value = schedule.day_of_week || '';
            document.getElementById('date_specific').value = schedule.date_specific || '';
            document.getElementById('start_time').value = schedule.start_time || '';
            document.getElementById('end_time').value = schedule.end_time || '';
            document.getElementById('duty_type').value = schedule.duty_type || '';
            document.getElementById('schedule_notes').value = schedule.notes || '';
            document.getElementById('schedule_status').value = schedule.status || 'Active';
            toggleScheduleFields();
            document.getElementById('scheduleModal').classList.add('show');
        }

        function closeScheduleModal() {
            document.getElementById('scheduleModal').classList.remove('show');
        }

        function deleteSchedule(id) {
            if (confirm('Are you sure you want to delete this schedule?')) {
                document.getElementById('deleteScheduleId').value = id;
                document.getElementById('deleteScheduleForm').submit();
            }
        }

        function toggleScheduleFields() {
            const scheduleType = document.getElementById('schedule_type').value;
            const dayOfWeekGroup = document.getElementById('day_of_week_group');
            const dateSpecificGroup = document.getElementById('date_specific_group');
            
            if (scheduleType === 'One-time') {
                dayOfWeekGroup.style.display = 'none';
                dateSpecificGroup.style.display = 'block';
                document.getElementById('day_of_week').required = false;
                document.getElementById('date_specific').required = true;
            } else {
                dayOfWeekGroup.style.display = 'block';
                dateSpecificGroup.style.display = 'none';
                document.getElementById('day_of_week').required = true;
                document.getElementById('date_specific').required = false;
            }
        }

        // ========== TASK FUNCTIONS ==========
        function openTaskModal() {
            document.getElementById('taskModalTitle').textContent = 'Assign Task';
            document.getElementById('taskFormAction').value = 'create_task';
            document.getElementById('taskForm').reset();
            document.getElementById('taskId').value = '';
            document.getElementById('previousStatus').value = '';
            document.getElementById('taskModal').classList.add('show');
        }

        function editTask(task) {
            document.getElementById('taskModalTitle').textContent = 'Edit Task';
            document.getElementById('taskFormAction').value = 'edit_task';
            document.getElementById('taskId').value = task.id;
            document.getElementById('previousStatus').value = task.status || 'Pending';
            document.getElementById('task_worker_id').value = task.worker_id || '';
            document.getElementById('task_title').value = task.title || '';
            document.getElementById('task_description').value = task.description || '';
            document.getElementById('task_status').value = task.status || 'Pending';
            document.getElementById('task_priority').value = task.priority || 'Medium';
            document.getElementById('task_deadline').value = task.deadline || '';
            document.getElementById('taskModal').classList.add('show');
        }

        function closeTaskModal() {
            document.getElementById('taskModal').classList.remove('show');
        }

        function deleteTask(id) {
            if (confirm('Are you sure you want to delete this task?')) {
                document.getElementById('deleteTaskId').value = id;
                document.getElementById('deleteTaskForm').submit();
            }
        }
    </script>
</body>
</html>
