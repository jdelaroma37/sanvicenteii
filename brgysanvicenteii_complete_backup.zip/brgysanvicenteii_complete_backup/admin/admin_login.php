<?php
// admin/admin_login.php
session_start();
require '../config.php';

// Security: Regenerate session ID on login page
if (!isset($_SESSION['initiated'])) {
    session_regenerate_id(true);
    $_SESSION['initiated'] = true;
}

// If already logged in as admin, redirect to dashboard
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    // Basic validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || !$password) {
        $error = 'Please provide a valid email and password.';
    } else {
        // Check admin table (note: table name is 'admins' plural)
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password'])) {
            $status = $admin['status'] ?? 'active';
            
            if ($status === 'pending') {
                $error = 'Your account is pending approval. Please wait for a Super Admin to approve your account.';
            } elseif ($status === 'inactive') {
                $error = 'Your account has been deactivated. Please contact a Super Admin.';
            } else {

                $_SESSION['user_id'] = $admin['id'];
                $_SESSION['first_name'] = $admin['full_name'];
                $_SESSION['role'] = 'admin';
                $_SESSION['admin_role'] = $admin['role'] ?? 'regular_admin';
                $_SESSION['email'] = $admin['email'];
                $_SESSION['login_time'] = time();

                try {
                    $update_stmt = $pdo->prepare("UPDATE admins SET last_login = NOW() WHERE id = ?");
                    $update_stmt->execute([$admin['id']]);
                } catch (PDOException $e) {}

                session_regenerate_id(true);
                header('Location: admin_dashboard.php');
                exit;
            }
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Barangay San Vicente II</title>

<style>
/* RESET */
* { margin:0; padding:0; box-sizing:border-box; }

body {
    font-family: 'Segoe UI', sans-serif;
    background: #E8F0E4;
    background-image: 
        linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
    background-size: 40px 40px;
    min-height: 100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

/* CONTAINER */
.modal-container {
    display:flex;
    width:100%;
    max-width:900px;
    min-height:550px;
    background:#fff;
    border-radius:12px;
    box-shadow:0 20px 60px rgba(0,0,0,0.15);
    overflow:hidden;
}

/* FORM SECTION */
.form-section {
    flex:1;
    padding:30px 25px;
    display:flex;
    flex-direction:column;
    justify-content:center;
    background:white;
}

/* LOGO */
.logo {
    text-align: center;
    margin-bottom: 18px;
}
.logo img {
    width: 45px;
    height: 45px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #d4af37;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

/* TITLES */
h1 {
    color:#1a5f3f;
    text-align:center;
    margin-bottom:4px;
    font-size:20px;
    font-weight:700;
}

.subtitle {
    text-align:center;
    color:#666;
    margin-bottom:18px;
    font-size:11px;
}

/* FORM GROUP */
.form-group {
    margin-bottom:16px;
    position:relative;
}

label {
    display:block;
    margin-bottom:5px;
    color:#1a5f3f;
    font-weight:600;
    font-size:11px;
}

/* INPUT */
input[type="email"],
input[type="password"],
input[type="text"] {
    width:100%;
    padding:9px 90px 9px 11px;
    border:2px solid #e0e0e0;
    border-radius:6px;
    font-size:12px;
    background:#fafafa;
    transition:0.3s;
    box-sizing: border-box;
}

/* Hide browser's built-in password reveal eye icon */
input[type="password"]::-ms-reveal,
input[type="password"]::-ms-clear {
    display: none !important;
}
input::-ms-reveal,
input::-ms-clear {
    display: none !important;
}

/* PASSWORD TOGGLE - Text Only */
.password-toggle-btn {
    position: absolute;
    right: 10px;
    top: 30px;
    background: transparent;
    border: none;
    color: #1a5f3f;
    font-size: 11px;
    cursor: pointer;
    padding: 0;
    font-weight: 500;
    z-index: 10;
}

.password-toggle-btn:hover {
    color: #d4af37;
}

input:focus {
    outline:none;
    border-color:#d4af37;
    background:white;
    box-shadow:0 0 0 3px rgba(212,175,55,0.1);
}

/* ERRORS */
.error {
    background:#fee;
    color:#c33;
    padding:12px;
    border-radius:8px;
    margin-bottom:15px;
    border-left:4px solid #c33;
    font-size:13px;
}

.success {
    background:#efe;
    color:#3c3;
    padding:12px;
    border-radius:8px;
    margin-bottom:15px;
    border-left:4px solid #3c3;
    font-size:13px;
}

/* BUTTON */
.btn {
    width:100%;
    padding:10px;
    background:linear-gradient(135deg, #1a5f3f, #2d7a52);
    color:white;
    border:none;
    border-radius:6px;
    font-size:13px;
    font-weight:600;
    cursor:pointer;
    transition:0.3s;
    margin-top:6px;
}

.btn:hover {
    transform:translateY(-2px);
    box-shadow:0 6px 12px rgba(26,95,63,0.3);
}

/* LINKS */
.links { text-align:center; margin-top:12px; }

.links a {
    color:#1a5f3f;
    text-decoration:none;
    font-size:11px;
    font-weight:500;
}

.links a:hover {
    text-decoration:underline;
    color:#d4af37;
}

/* VISUAL SECTION */
.visual-section {
    flex: 1;
    background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 50%, #1a5f3f 100%);
    position: relative;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 30px 25px;
    overflow: hidden;
}
.visual-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: 
        repeating-linear-gradient(
            45deg,
            rgba(212, 175, 55, 0.1) 0px,
            rgba(212, 175, 55, 0.1) 20px,
            transparent 20px,
            transparent 40px
        );
    opacity: 0.3;
}
.visual-content {
    position: relative;
    z-index: 1;
    text-align: center;
    color: white;
}
.visual-icon {
    width: 80px;
    height: 80px;
    background: rgba(255, 255, 255, 0.15);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 18px;
    backdrop-filter: blur(10px);
    border: 2px solid rgba(212, 175, 55, 0.3);
}
.visual-icon img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    object-fit: cover;
    border: 3px solid #d4af37;
}
.visual-quote {
    font-size: 16px;
    font-weight: 600;
    line-height: 1.4;
    margin-bottom: 18px;
    color: white;
}
.visual-author {
    font-size: 12px;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.9);
}

/* RESPONSIVE */
@media (max-width: 768px) {
    .modal-container {
        flex-direction: column;
        max-width: 100%;
        min-height: auto;
    }
    .visual-section {
        display: none;
    }
    .form-section {
        padding: 40px 30px;
    }
}

@media (max-width: 480px) {
    body {
        padding: 10px;
    }
    .form-section {
        padding: 30px 20px;
    }
    h1 {
        font-size: 24px;
    }
    input[type="email"],
    input[type="password"],
    input[type="text"] {
        padding: 12px 90px 12px 12px;
    }
    .password-toggle-btn {
        top: 33px;
    }
}
</style>
</head>

<body>
<div class="modal-container">

    <div class="form-section">
        <div class="logo">
            <img src="../images/logo.jpg" alt="Barangay Logo">
        </div>

        <h1>Admin Login</h1>
        <p class="subtitle">Barangay San Vicente II</p>

        <?php if ($error): ?>
            <div class="error"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST">

            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" required placeholder="Enter your email">
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password" id="password" name="password" required placeholder="Enter your password">
                <button type="button" class="password-toggle-btn" id="togglePassword">Show Password</button>
            </div>

            <button type="submit" class="btn">Login</button>
        </form>

        <div class="links">
            <a href="admin_forgot_password.php">Forgot Password?</a>
        </div>
        <div class="links">
            <a href="admin_register.php">Create Account</a> |
            <a href="admin_signin.php">Sign In</a>
        </div>
        <div class="links">
            <a href="../index.php">Login as Resident</a>
        </div>
    </div>

    <div class="visual-section">
        <div class="visual-content">
            <div class="visual-icon">
                <img src="../images/logo.jpg" alt="Barangay Logo">
            </div>
            <div class="visual-quote">
                "Welcome to Barangay San Vicente II Administrative Portal. Manage your community with efficiency and care."
            </div>
            <div class="visual-author">
                BARANGAY SAN VICENTE II
            </div>
        </div>
    </div>

</div>

<script>
document.getElementById('togglePassword').addEventListener('click', function() {
    const input = document.getElementById('password');
    const isPass = input.type === 'password';
    input.type = isPass ? 'text' : 'password';
    this.textContent = isPass ? 'Hide Password' : 'Show Password';
});
</script>

</body>
</html>
