<?php
// admin/admin_walkin_request.php
session_start();
require '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Check if table exists, create if not
// Also check if appointment columns exist, add if not
try {
    $pdo->query("SELECT 1 FROM walk_in_requests LIMIT 1");
    // Check if appointment columns exist
    $columns = $pdo->query("SHOW COLUMNS FROM walk_in_requests LIKE 'appointment_date'")->fetchAll();
    if (empty($columns)) {
        // Add appointment columns to existing table
        $pdo->exec("ALTER TABLE walk_in_requests ADD COLUMN appointment_date DATE AFTER admin_attachment_url");
        $pdo->exec("ALTER TABLE walk_in_requests ADD COLUMN appointment_time TIME AFTER appointment_date");
    }
} catch (PDOException $e) {
    // Table doesn't exist, create it
    $create_table_sql = "CREATE TABLE IF NOT EXISTS walk_in_requests (
        request_id INT AUTO_INCREMENT PRIMARY KEY,
        request_number VARCHAR(50) UNIQUE NOT NULL,
        resident_id INT,
        resident_name VARCHAR(255) NOT NULL,
        resident_email VARCHAR(255),
        resident_contact VARCHAR(50),
        category VARCHAR(100) NOT NULL,
        type VARCHAR(100) NOT NULL,
        description TEXT,
        attachment_url VARCHAR(500),
        status ENUM('Pending', 'Under Review', 'Completed', 'Rejected') DEFAULT 'Pending',
        admin_notes TEXT,
        admin_attachment_url VARCHAR(500),
        appointment_date DATE,
        appointment_time TIME,
        processed_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (resident_id) REFERENCES residents(id) ON DELETE SET NULL,
        FOREIGN KEY (processed_by) REFERENCES admins(id) ON DELETE SET NULL,
        INDEX idx_status (status),
        INDEX idx_request_number (request_number),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    try {
        $pdo->exec($create_table_sql);
    } catch (PDOException $create_error) {
        // If foreign key constraints fail, try without them
        $create_table_sql_no_fk = "CREATE TABLE IF NOT EXISTS walk_in_requests (
            request_id INT AUTO_INCREMENT PRIMARY KEY,
            request_number VARCHAR(50) UNIQUE NOT NULL,
            resident_id INT,
            resident_name VARCHAR(255) NOT NULL,
            resident_email VARCHAR(255),
            resident_contact VARCHAR(50),
            category VARCHAR(100) NOT NULL,
            type VARCHAR(100) NOT NULL,
            description TEXT,
            attachment_url VARCHAR(500),
            status ENUM('Pending', 'Under Review', 'Completed', 'Rejected') DEFAULT 'Pending',
            admin_notes TEXT,
            admin_attachment_url VARCHAR(500),
            appointment_date DATE,
            appointment_time TIME,
            processed_by INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_status (status),
            INDEX idx_request_number (request_number),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        $pdo->exec($create_table_sql_no_fk);
    }
}

// Get filter and search parameters
$status_filter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_status') {
        $request_id = intval($_POST['request_id'] ?? 0);
        $new_status = $_POST['status'] ?? '';
        $admin_notes = trim($_POST['admin_notes'] ?? '');
        
        // Validate status
        $valid_statuses = ['Pending', 'Under Review', 'Completed', 'Rejected'];
        if (!in_array($new_status, $valid_statuses)) {
            $_SESSION['error'] = 'Invalid status.';
            header('Location: admin_walkin_request.php');
            exit;
        }
        
        // Get current request
        $stmt = $pdo->prepare("SELECT * FROM walk_in_requests WHERE request_id = ?");
        $stmt->execute([$request_id]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$request) {
            $_SESSION['error'] = 'Request not found.';
            header('Location: admin_walkin_request.php');
            exit;
        }
        
        // Handle file upload
        $admin_attachment_url = $request['admin_attachment_url'] ?? '';
        if (isset($_FILES['admin_attachment']) && $_FILES['admin_attachment']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/../uploads/walkin_requests/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_ext = strtolower(pathinfo($_FILES['admin_attachment']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
            
            if (in_array($file_ext, $allowed_ext)) {
                $new_filename = 'admin_' . time() . '_' . uniqid() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['admin_attachment']['tmp_name'], $upload_path)) {
                    // Delete old file if exists
                    if (!empty($admin_attachment_url) && file_exists(__DIR__ . '/../' . $admin_attachment_url)) {
                        @unlink(__DIR__ . '/../' . $admin_attachment_url);
                    }
                    $admin_attachment_url = 'uploads/walkin_requests/' . $new_filename;
                }
            }
        }
        
        // Get appointment date and time
        $appointment_date = !empty($_POST['appointment_date']) ? $_POST['appointment_date'] : null;
        $appointment_time = !empty($_POST['appointment_time']) ? $_POST['appointment_time'] : null;
        
        // If appointment is set, combine date and time
        $appointment_datetime = null;
        if ($appointment_date && $appointment_time) {
            $appointment_datetime = $appointment_date . ' ' . $appointment_time . ':00';
        }
        
        // Update request
        $stmt = $pdo->prepare("UPDATE walk_in_requests SET status = ?, admin_notes = ?, admin_attachment_url = ?, appointment_date = ?, appointment_time = ?, processed_by = ?, updated_at = NOW() WHERE request_id = ?");
        $stmt->execute([$new_status, $admin_notes, $admin_attachment_url, $appointment_date, $appointment_time, $admin_id, $request_id]);
        
        // Send notification to resident
        $notifDir = __DIR__ . '/../data/notifications';
        if (!is_dir($notifDir)) mkdir($notifDir, 0777, true);
        $notifFile = $notifDir . '/notifications.json';
        
        $notifications = [];
        if (file_exists($notifFile)) {
            $notifications = json_decode(file_get_contents($notifFile), true) ?? [];
        }
        
        // Create notification message based on status
        $status_messages = [
            'Under Review' => "Your walk-in request #{$request['request_number']} is now being processed by the Barangay.",
            'Completed' => "Your requested document is ready for pickup." . (!empty($admin_notes) ? " Note: {$admin_notes}" : ""),
            'Rejected' => "Your request #{$request['request_number']} was rejected." . (!empty($admin_notes) ? " Reason: {$admin_notes}" : " Reason: Incomplete requirements.")
        ];
        
        $message = $status_messages[$new_status] ?? "Your walk-in request #{$request['request_number']} status has been updated to {$new_status}.";
        
        // Add appointment info to message if set
        if ($appointment_date && $appointment_time) {
            $appointment_formatted = date('F d, Y', strtotime($appointment_date)) . ' at ' . date('h:i A', strtotime($appointment_time . ':00'));
            $message .= " Your appointment is scheduled on {$appointment_formatted}.";
        }
        
        $notifications[] = [
            'type' => 'walkin_status_update',
            'request_id' => $request_id,
            'request_number' => $request['request_number'],
            'resident_id' => $request['resident_id'],
            'title' => "Walk-In Request Status Update",
            'message' => $message,
            'status' => $new_status,
            'appointment_date' => $appointment_date,
            'appointment_time' => $appointment_time,
            'created_at' => date('Y-m-d H:i:s'),
            'read' => false
        ];
        
        file_put_contents($notifFile, json_encode($notifications, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        
        // Create admin notification for status update
        if (file_exists(__DIR__ . '/admin_notification_helper.php')) {
            require_once __DIR__ . '/admin_notification_helper.php';
            $status_display = [
                'Under Review' => 'is now being processed',
                'Completed' => 'has been completed',
                'Rejected' => 'has been rejected',
                'Pending' => 'is pending'
            ];
            $status_text = $status_display[$new_status] ?? "has been updated to {$new_status}";
            
            createAdminNotification(
                'request_status_updated',
                'Request Status Updated',
                "Request #{$request['request_number']} {$status_text}",
                'all',
                [
                    'request_id' => $request_id,
                    'request_number' => $request['request_number'],
                    'status' => $new_status,
                    'resident_name' => $request['resident_name'] ?? 'N/A'
                ]
            );
        }
        
        $_SESSION['success'] = 'Request status updated successfully!';
        header('Location: admin_walkin_request.php');
        exit;
    }
}

// Get statistics
$stats = [];
$stmt = $pdo->query("SELECT status, COUNT(*) as count FROM walk_in_requests GROUP BY status");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $stats[$row['status']] = $row['count'];
}

$pending_count = $stats['Pending'] ?? 0;
$under_review_count = $stats['Under Review'] ?? 0;
$completed_count = $stats['Completed'] ?? 0;
$rejected_count = $stats['Rejected'] ?? 0;
$total_count = $pending_count + $under_review_count + $completed_count + $rejected_count;

// Build query for requests
$query = "SELECT wr.*, r.first_name, r.last_name, r.email as resident_email, r.contact_number as resident_contact 
          FROM walk_in_requests wr 
          LEFT JOIN residents r ON wr.resident_id = r.id 
          WHERE 1=1";

$params = [];

if ($status_filter !== 'all') {
    $query .= " AND wr.status = ?";
    $params[] = $status_filter;
}

if (!empty($search)) {
    $query .= " AND (wr.request_number LIKE ? OR wr.resident_name LIKE ? OR wr.category LIKE ? OR wr.type LIKE ?)";
    $search_param = "%{$search}%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

$query .= " ORDER BY wr.created_at DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Walk-In Request Management - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a i {
            margin-right: 12px;
            width: 24px;
            font-size: 20px;
            text-align: center;
            display: inline-block;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-secondary,
        .page-actions .btn-secondary {
            background: #4b5563 !important;
            color: white !important;
        }
        .btn-secondary:hover,
        .page-actions .btn-secondary:hover {
            background: #374151 !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(75, 85, 99, 0.3);
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .row-container > .section-title:first-child {
            margin-top: 0;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 16px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }
        .stat-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .stat-label {
            font-size: 16px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .stat-value {
            font-size: 42px;
            font-weight: 800;
            color: #000000;
            letter-spacing: -0.5px;
        }
        /* Filters and Search */
        .filters-section {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }
        .filters-section:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .filters-row {
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-tabs {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .filter-tab {
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.8);
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
            color: #6b7280;
            transition: all 0.3s;
        }
        .filter-tab:hover {
            background: white;
            border-color: #87A96B;
        }
        .filter-tab.active {
            background: #2c3e2d;
            color: white;
            border-color: #2c3e2d;
        }
        .search-box {
            flex: 1;
            min-width: 250px;
            position: relative;
        }
        .search-box input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.8);
            color: #2c3e2d;
            transition: all 0.3s;
        }
        .search-box input:focus {
            outline: none;
            border-color: #87A96B;
            background: white;
            box-shadow: 0 0 0 3px rgba(135, 169, 107, 0.1);
        }
        .search-box input::placeholder {
            color: #6b7280;
            font-weight: 500;
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            pointer-events: none;
            width: 18px;
            height: 18px;
            color: #6b7280;
        }
        /* Requests List */
        .requests-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }
        .requests-container:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .request-item {
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 12px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        .request-item:hover {
            border-color: #87A96B;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .request-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 15px;
            flex-wrap: wrap;
            gap: 15px;
        }
        .request-info {
            flex: 1;
        }
        .request-number {
            font-size: 18px;
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 5px;
        }
        .request-resident {
            font-size: 16px;
            color: #6b7280;
            font-weight: 500;
            margin-bottom: 5px;
        }
        .request-meta {
            font-size: 14px;
            color: #6b7280;
            font-weight: 500;
        }
        .request-status {
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            text-align: center;
        }
        .request-status.pending {
            background: rgba(212, 175, 55, 0.2);
            color: #856404;
            border: 1px solid rgba(212, 175, 55, 0.3);
        }
        .request-status.under-review {
            background: rgba(33, 150, 243, 0.2);
            color: #084298;
            border: 1px solid rgba(33, 150, 243, 0.3);
        }
        .request-status.completed {
            background: rgba(135, 169, 107, 0.2);
            color: #2c3e2d;
            border: 1px solid rgba(135, 169, 107, 0.3);
        }
        .request-status.rejected {
            background: rgba(244, 67, 54, 0.2);
            color: #842029;
            border: 1px solid rgba(244, 67, 54, 0.3);
        }
        .request-details {
            margin-top: 15px;
            padding-top: 15px;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }
        .detail-row {
            display: flex;
            margin-bottom: 10px;
            font-size: 16px;
        }
        .detail-label {
            font-weight: 700;
            color: #2c3e2d;
            width: 120px;
        }
        .detail-value {
            color: #6b7280;
            font-weight: 500;
            flex: 1;
        }
        .btn-view {
            padding: 8px 16px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 15px;
        }
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 35px;
            width: 100%;
            max-width: 700px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .modal-header h2 {
            font-size: 26px;
            color: #2c3e2d;
            font-weight: 800;
            letter-spacing: -0.3px;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 28px;
            color: #6b7280;
            cursor: pointer;
            transition: color 0.3s;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 700;
            font-size: 16px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            transition: all 0.3s;
            background: rgba(255, 255, 255, 0.8);
            color: #2c3e2d;
            font-family: inherit;
        }
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #87A96B;
            background: white;
            box-shadow: 0 0 0 3px rgba(135, 169, 107, 0.1);
        }
        .form-group input[readonly] {
            background: rgba(243, 244, 246, 0.8);
            color: #6b7280;
            cursor: not-allowed;
        }
        .attachment-link {
            display: inline-block;
            padding: 8px 16px;
            background: #2c3e2d;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            margin-top: 5px;
            transition: all 0.3s;
        }
        .attachment-link:hover {
            background: #1a2e1b;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: rgba(255, 255, 255, 0.8);
            color: #6b7280;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: white;
            border-color: #9ca3af;
            color: #2c3e2d;
        }
        .btn-submit {
            flex: 1;
            padding: 12px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        .empty-state h3 {
            color: #2c3e2d;
            font-size: 26px;
            font-weight: 800;
            margin-bottom: 10px;
        }
        .empty-state p {
            color: #6b7280;
            font-size: 16px;
            font-weight: 500;
        }
        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
            opacity: 0.3;
            color: #87A96B;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .filters-row {
                flex-direction: column;
            }
            .filter-tabs {
                width: 100%;
            }
            .filter-tab {
                flex: 1;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="8.5" cy="7" r="4"></circle>
                    <path d="M20 8v6M23 11h-6"></path>
                </svg>
            </span>
            Walk-In Request Management
        </h1>

        <div class="page-actions">
            <a href="admin_monitoring_request.php" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Monitoring Request
            </a>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="row-container">
            <!-- Statistics Cards -->
            <div class="stats-grid">
            <div class="stat-card pending">
                <div class="stat-label">Pending Requests</div>
                <div class="stat-value"><?php echo $pending_count; ?></div>
            </div>
            <div class="stat-card under-review">
                <div class="stat-label">Under Review</div>
                <div class="stat-value"><?php echo $under_review_count; ?></div>
            </div>
            <div class="stat-card completed">
                <div class="stat-label">Completed</div>
                <div class="stat-value"><?php echo $completed_count; ?></div>
            </div>
            <div class="stat-card rejected">
                <div class="stat-label">Rejected</div>
                <div class="stat-value"><?php echo $rejected_count; ?></div>
            </div>
        </div>

        <!-- Filters and Search -->
        <div class="filters-section">
            <div class="filters-row">
                <div class="filter-tabs">
                    <button class="filter-tab <?php echo $status_filter === 'all' ? 'active' : ''; ?>" onclick="window.location.href='?status=all&search=<?php echo urlencode($search); ?>'">All Requests</button>
                    <button class="filter-tab <?php echo $status_filter === 'Pending' ? 'active' : ''; ?>" onclick="window.location.href='?status=Pending&search=<?php echo urlencode($search); ?>'">Pending</button>
                    <button class="filter-tab <?php echo $status_filter === 'Under Review' ? 'active' : ''; ?>" onclick="window.location.href='?status=Under Review&search=<?php echo urlencode($search); ?>'">Under Review</button>
                    <button class="filter-tab <?php echo $status_filter === 'Completed' ? 'active' : ''; ?>" onclick="window.location.href='?status=Completed&search=<?php echo urlencode($search); ?>'">Completed</button>
                    <button class="filter-tab <?php echo $status_filter === 'Rejected' ? 'active' : ''; ?>" onclick="window.location.href='?status=Rejected&search=<?php echo urlencode($search); ?>'">Rejected</button>
                </div>
                <div class="search-box">
                    <form method="GET" style="display: flex; gap: 10px;">
                        <input type="text" name="search" placeholder="Search by request number, name, category..." value="<?php echo htmlspecialchars($search); ?>">
                        <input type="hidden" name="status" value="<?php echo htmlspecialchars($status_filter); ?>">
                        <button type="submit" style="display: none;">Search</button>
                    </form>
                    <svg class="search-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M10.5 3.75a6.75 6.75 0 100 13.5 6.75 6.75 0 000-13.5zM2.25 10.5a8.25 8.25 0 1114.59 5.28l4.69 4.69a.75.75 0 11-1.06 1.06l-4.69-4.69A8.25 8.25 0 012.25 10.5z" fill="currentColor"/>
                    </svg>
                </div>
            </div>
        </div>

        <!-- Requests List -->
        <div class="requests-container">
            <?php if (empty($requests)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <rect x="3" y="3" width="18" height="18" rx="2" stroke="currentColor" stroke-width="1.5"/>
                            <path d="M8 9h8M8 13h8M8 17h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                    </div>
                    <h3>No Requests Found</h3>
                    <p><?php echo !empty($search) || $status_filter !== 'all' ? 'Try adjusting your filters or search terms.' : 'No walk-in requests have been submitted yet.'; ?></p>
                </div>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <div class="request-item <?php echo strtolower(str_replace(' ', '-', $request['status'])); ?>">
                        <div class="request-header">
                            <div class="request-info">
                                <div class="request-number">Request #: <?php echo htmlspecialchars($request['request_number']); ?></div>
                                <div class="request-resident">Resident: <?php echo htmlspecialchars($request['resident_name']); ?></div>
                                <div class="request-meta">
                                    Category: <?php echo htmlspecialchars($request['category']); ?> | 
                                    Type: <?php echo htmlspecialchars($request['type']); ?> | 
                                    Date: <?php echo date('M d, Y h:i A', strtotime($request['created_at'])); ?>
                                    <?php if (!empty($request['appointment_date']) && !empty($request['appointment_time'])): ?>
                                        | <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 4px;">
                                            <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                            <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                        </svg>
                                        Appointment: <?php echo date('M d, Y', strtotime($request['appointment_date'])); ?> at <?php echo date('h:i A', strtotime($request['appointment_time'])); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="request-status <?php echo strtolower(str_replace(' ', '-', $request['status'])); ?>">
                                <?php echo htmlspecialchars($request['status']); ?>
                            </div>
                        </div>
                        <button class="btn-view" onclick="openRequestModal(<?php echo htmlspecialchars(json_encode($request)); ?>)">View Details</button>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        </div>

    <!-- Request Details Modal -->
    <div id="requestModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Request Details</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <form id="requestForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_status">
                <input type="hidden" name="request_id" id="request_id">
                
                <div class="form-group">
                    <label>Request Number</label>
                    <input type="text" id="request_number" readonly>
                </div>

                <div class="form-group">
                    <label>Resident Name</label>
                    <input type="text" id="resident_name" readonly>
                </div>

                <div class="form-group">
                    <label>Resident Contact</label>
                    <input type="text" id="resident_contact" readonly>
                </div>

                <div class="form-group">
                    <label>Resident Email</label>
                    <input type="text" id="resident_email" readonly>
                </div>

                <div class="form-group">
                    <label>Category</label>
                    <input type="text" id="category" readonly>
                </div>

                <div class="form-group">
                    <label>Type of Request</label>
                    <input type="text" id="type" readonly>
                </div>

                <div class="form-group">
                    <label>Description</label>
                    <textarea id="description" readonly></textarea>
                </div>

                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="status" required>
                        <option value="Pending">Pending</option>
                        <option value="Under Review">Under Review</option>
                        <option value="Completed">Completed</option>
                        <option value="Rejected">Rejected</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Admin Notes</label>
                    <textarea name="admin_notes" id="admin_notes" placeholder="Add notes or reason for status change..."></textarea>
                </div>

                <div class="form-group">
                    <label>Set Appointment (Optional)</label>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                        <div>
                            <label style="font-size: 14px; color: #6b7280; font-weight: 600; margin-bottom: 5px; display: block;">Date</label>
                            <input type="date" name="appointment_date" id="appointment_date" min="<?php echo date('Y-m-d'); ?>">
                        </div>
                        <div>
                            <label style="font-size: 14px; color: #6b7280; font-weight: 600; margin-bottom: 5px; display: block;">Time</label>
                            <input type="time" name="appointment_time" id="appointment_time">
                        </div>
                    </div>
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Set appointment date and time for resident to come to barangay</small>
                    <div id="appointment_display" style="margin-top: 10px; padding: 12px 16px; background: rgba(255, 255, 255, 0.5); border: 1px solid rgba(0, 0, 0, 0.1); border-radius: 8px; display: none;">
                        <strong style="color: #2c3e2d; font-weight: 700;">Current Appointment:</strong> <span id="appointment_text" style="color: #6b7280; font-weight: 500;"></span>
                    </div>
                </div>

                <div class="form-group">
                    <label>Resident Attachment</label>
                    <div id="attachment_container"></div>
                </div>

                <div class="form-group">
                    <label>Admin Attachment (Upload Document)</label>
                    <input type="file" name="admin_attachment" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                    <small style="color: #6b7280; font-size: 14px; font-weight: 500; margin-top: 5px; display: block;">Upload scanned documents, clearance, or other files</small>
                    <div id="admin_attachment_container"></div>
                </div>

                <div class="form-group">
                    <label>Timestamp</label>
                    <input type="text" id="created_at" readonly>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Update Status</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // toggleSubmenu function is already in admin_dashboard_sidebar.php

        function openRequestModal(request) {
            document.getElementById('request_id').value = request.request_id;
            document.getElementById('request_number').value = request.request_number || '';
            document.getElementById('resident_name').value = request.resident_name || '';
            document.getElementById('resident_contact').value = request.resident_contact || request.resident_contact || 'N/A';
            document.getElementById('resident_email').value = request.resident_email || request.resident_email || 'N/A';
            document.getElementById('category').value = request.category || '';
            document.getElementById('type').value = request.type || '';
            document.getElementById('description').value = request.description || '';
            document.getElementById('status').value = request.status || 'Pending';
            document.getElementById('admin_notes').value = request.admin_notes || '';
            document.getElementById('created_at').value = request.created_at ? new Date(request.created_at).toLocaleString() : '';
            
            // Set appointment fields
            if (request.appointment_date) {
                document.getElementById('appointment_date').value = request.appointment_date;
            } else {
                document.getElementById('appointment_date').value = '';
            }
            if (request.appointment_time) {
                // Format time (remove seconds if present)
                let timeValue = request.appointment_time;
                if (timeValue.length > 5) {
                    timeValue = timeValue.substring(0, 5);
                }
                document.getElementById('appointment_time').value = timeValue;
            } else {
                document.getElementById('appointment_time').value = '';
            }
            
            // Show current appointment if exists
            const appointmentDisplay = document.getElementById('appointment_display');
            const appointmentText = document.getElementById('appointment_text');
            if (request.appointment_date && request.appointment_time) {
                const date = new Date(request.appointment_date);
                const time = request.appointment_time.substring(0, 5);
                const formattedDate = date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
                const formattedTime = new Date('2000-01-01T' + time).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                appointmentText.textContent = formattedDate + ' at ' + formattedTime;
                appointmentDisplay.style.display = 'block';
            } else {
                appointmentDisplay.style.display = 'none';
            }

            // Show resident attachment
            const attachmentContainer = document.getElementById('attachment_container');
            if (request.attachment_url) {
                attachmentContainer.innerHTML = `<a href="../${request.attachment_url}" target="_blank" class="attachment-link">📎 View Attachment</a>`;
            } else {
                attachmentContainer.innerHTML = '<span style="color: #6b7280; font-weight: 500;">No attachment</span>';
            }

            // Show admin attachment
            const adminAttachmentContainer = document.getElementById('admin_attachment_container');
            if (request.admin_attachment_url) {
                adminAttachmentContainer.innerHTML = `<a href="../${request.admin_attachment_url}" target="_blank" class="attachment-link">📎 View Admin Attachment</a>`;
            } else {
                adminAttachmentContainer.innerHTML = '';
            }

            document.getElementById('requestModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('requestModal').classList.remove('show');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('requestModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        // Auto-submit search on Enter
        document.querySelector('.search-box input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                this.form.submit();
            }
        });

        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>

