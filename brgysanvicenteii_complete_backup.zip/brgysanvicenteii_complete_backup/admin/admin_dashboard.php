<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

require __DIR__ . '/../config.php';
require __DIR__ . '/role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../index.php");
    exit;
}

$admin_id = $_SESSION['user_id'];

// Fetch admin profile
$stmt = $pdo->prepare("SELECT full_name, email, photo FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Get admin role
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin_role_data = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin_role_data['role']) ? $admin_role_data['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Check if columns exist
$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'deleted_at'")->fetch();
$deleted_at_exists = !empty($columns_check);

$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'account_status'")->fetch();
$columns_exist = !empty($columns_check);

$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'household_number'")->fetch();
$household_exists = !empty($columns_check);

$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'category'")->fetch();
$category_exists = !empty($columns_check);

// Get resident statistics - matching Population page logic
$indigent_select = $category_exists ? "SUM(CASE WHEN category LIKE '%Indigent%' OR category = 'Indigent' THEN 1 ELSE 0 END)" : "0";
if ($columns_exist && $deleted_at_exists) {
    $household_select = $household_exists ? "COUNT(DISTINCT COALESCE(household_number, id))" : "COUNT(*)";
    $stats_query = "SELECT 
        COUNT(*) as total_registered,
        SUM(CASE WHEN COALESCE(account_status, 'Pending Verification') = 'Active' THEN 1 ELSE 0 END) as total_active,
        SUM(CASE WHEN created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') THEN 1 ELSE 0 END) as newly_added_month,
        $household_select as total_households,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) >= 21900 THEN 1 ELSE 0 END) as total_seniors,
        SUM(CASE WHEN pwd = 'Yes' THEN 1 ELSE 0 END) as total_pwd,
        SUM(CASE WHEN solo_parent = 'Yes' THEN 1 ELSE 0 END) as total_solo_parents,
        $indigent_select as total_indigent
    FROM residents WHERE COALESCE(deleted_at, '') = ''";
} else {
    $household_select = $household_exists ? "COUNT(DISTINCT COALESCE(household_number, id))" : "COUNT(*)";
    $stats_query = "SELECT 
        COUNT(*) as total_registered,
        COUNT(*) as total_active,
        SUM(CASE WHEN created_at >= DATE_FORMAT(CURDATE(), '%Y-%m-01') THEN 1 ELSE 0 END) as newly_added_month,
        $household_select as total_households,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) >= 21900 THEN 1 ELSE 0 END) as total_seniors,
        SUM(CASE WHEN pwd = 'Yes' THEN 1 ELSE 0 END) as total_pwd,
        SUM(CASE WHEN solo_parent = 'Yes' THEN 1 ELSE 0 END) as total_solo_parents,
        $indigent_select as total_indigent
    FROM residents";
}
$stats = $pdo->query($stats_query)->fetch(PDO::FETCH_ASSOC);

// Get age distribution - updated to match requirements: 0-17, 18-35, 36-60, 60+
// Age in days: 0-17 = <6570, 18-35 = 6570-12775, 36-60 = 12776-21900, 60+ = >=21900
if ($deleted_at_exists) {
    $age_query = "SELECT 
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) < 6570 THEN 1 ELSE 0 END) as age_0_17,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) BETWEEN 6570 AND 12775 THEN 1 ELSE 0 END) as age_18_35,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) BETWEEN 12776 AND 21900 THEN 1 ELSE 0 END) as age_36_60,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) >= 21900 THEN 1 ELSE 0 END) as age_60_plus
    FROM residents WHERE COALESCE(deleted_at, '') = ''";
} else {
    $age_query = "SELECT 
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) < 6570 THEN 1 ELSE 0 END) as age_0_17,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) BETWEEN 6570 AND 12775 THEN 1 ELSE 0 END) as age_18_35,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) BETWEEN 12776 AND 21900 THEN 1 ELSE 0 END) as age_36_60,
        SUM(CASE WHEN date_of_birth IS NOT NULL AND DATEDIFF(CURDATE(), date_of_birth) >= 21900 THEN 1 ELSE 0 END) as age_60_plus
    FROM residents";
}
$age_stats = $pdo->query($age_query)->fetch(PDO::FETCH_ASSOC);

// Count document requests from JSON files
$requests_dir = __DIR__ . '/../data/requests';
$all_json_requests = [];
$pending_requests = 0;
$approved_this_month = 0;
$rejected_cancelled = 0;
$document_types = [];

$current_month_start = date('Y-m-01');
$current_month_end = date('Y-m-t');

if (is_dir($requests_dir)) {
    $files = glob("$requests_dir/*.json");
    foreach ($files as $file) {
        $filename = basename($file);
        if ($filename === 'requests.json') continue;
        
        $content = json_decode(file_get_contents($file), true);
        if (!$content) continue;
        
        if (preg_match('/^\d+_requests\.json$/', $filename) && is_array($content)) {
            foreach ($content as $req) {
                if (is_array($req) && !empty($req['id'])) {
                    $all_json_requests[] = $req;
                    $status = strtolower(trim($req['status'] ?? ''));
                    $dateRequested = $req['dateRequested'] ?? $req['doneAt'] ?? '';
                    
                    // Count pending (including Processing)
                    if (in_array($status, ['pending', 'processing', 'ready to pick up'])) {
                        $pending_requests++;
                    }
                    
                    // Count approved this month
                    if (in_array($status, ['done', 'completed'])) {
                        // Parse date to check if it's this month
                        $done_date = $req['doneAt'] ?? $dateRequested ?? '';
                        if ($done_date) {
                            // Try to parse various date formats
                            $parsed_date = false;
                            if (preg_match('/(\d{4}-\d{2}-\d{2})/', $done_date, $matches)) {
                                $parsed_date = $matches[1];
                            } else {
                                $timestamp = strtotime($done_date);
                                if ($timestamp) {
                                    $parsed_date = date('Y-m-d', $timestamp);
                                }
                            }
                            if ($parsed_date && $parsed_date >= $current_month_start && $parsed_date <= $current_month_end) {
                                $approved_this_month++;
                            }
                        }
                    }
                    
                    // Count rejected/cancelled
                    if (in_array($status, ['rejected', 'cancelled', 'canceled'])) {
                        $rejected_cancelled++;
                    }
                    
                    // Count document types
                    $doc_type = $req['documentType'] ?? '';
                    if ($doc_type) {
                        $document_types[$doc_type] = ($document_types[$doc_type] ?? 0) + 1;
                    }
                }
            }
        } else if (is_array($content) && !empty($content['id'])) {
            $all_json_requests[] = $content;
            $status = strtolower(trim($content['status'] ?? ''));
            $dateRequested = $content['dateRequested'] ?? $content['doneAt'] ?? '';
            
            if (in_array($status, ['pending', 'processing', 'ready to pick up'])) {
                $pending_requests++;
            }
            
            if (in_array($status, ['done', 'completed'])) {
                $done_date = $content['doneAt'] ?? $dateRequested ?? '';
                if ($done_date) {
                    $parsed_date = false;
                    if (preg_match('/(\d{4}-\d{2}-\d{2})/', $done_date, $matches)) {
                        $parsed_date = $matches[1];
                    } else {
                        $timestamp = strtotime($done_date);
                        if ($timestamp) {
                            $parsed_date = date('Y-m-d', $timestamp);
                        }
                    }
                    if ($parsed_date && $parsed_date >= $current_month_start && $parsed_date <= $current_month_end) {
                        $approved_this_month++;
                    }
                }
            }
            
            if (in_array($status, ['rejected', 'cancelled', 'canceled'])) {
                $rejected_cancelled++;
            }
            
            $doc_type = $content['documentType'] ?? '';
            if ($doc_type) {
                $document_types[$doc_type] = ($document_types[$doc_type] ?? 0) + 1;
            }
        }
    }
}

// Get walk-in requests from database
try {
    $walkin_query = "SELECT status, type, created_at, updated_at 
                     FROM walk_in_requests 
                     WHERE created_at IS NOT NULL";
    $walkin_requests = $pdo->query($walkin_query)->fetchAll(PDO::FETCH_ASSOC);
    
    foreach ($walkin_requests as $req) {
        $status = strtolower(trim($req['status'] ?? ''));
        $created_at = $req['created_at'] ?? '';
        $updated_at = $req['updated_at'] ?? '';
        
        // Count pending
        if (in_array($status, ['pending', 'under review'])) {
            $pending_requests++;
        }
        
        // Count approved this month
        if ($status === 'completed') {
            $done_date = $updated_at ?: $created_at;
            if ($done_date) {
                $parsed_date = date('Y-m-d', strtotime($done_date));
                if ($parsed_date >= $current_month_start && $parsed_date <= $current_month_end) {
                    $approved_this_month++;
                }
            }
        }
        
        // Count rejected
        if ($status === 'rejected') {
            $rejected_cancelled++;
        }
        
        // Count document types
        $doc_type = $req['type'] ?? '';
        if ($doc_type) {
            $document_types[$doc_type] = ($document_types[$doc_type] ?? 0) + 1;
        }
    }
} catch (PDOException $e) {
    // Table might not exist, continue without it
}

// Get most requested document type
$most_requested_type = 'N/A';
if (!empty($document_types)) {
    arsort($document_types);
    $most_requested_type = array_key_first($document_types);
}

// Get Important Documents Status
$expiring_documents_30days = 0;
$newly_issued_documents = 0;
$total_document_list = 0;
$rejected_documents = 0;
$pending_documents = 0;
$completed_documents = 0;
$processing_documents = 0;

$today_date = date('Y-m-d');
$thirty_days_later_docs = date('Y-m-d', strtotime('+30 days'));
$last_7_days = date('Y-m-d', strtotime('-7 days'));

// Process all documents (requests + permits/clearances)
foreach ($all_json_requests as $req) {
    $status = strtolower(trim($req['status'] ?? ''));
    $dateRequested = $req['dateRequested'] ?? '';
    $doneAt = $req['doneAt'] ?? '';
    $doc_type = $req['documentType'] ?? '';
    
    // Count all documents
    $total_document_list++;
    
    // Count by status
    if (in_array($status, ['rejected', 'cancelled', 'canceled'])) {
        $rejected_documents++;
    } elseif (in_array($status, ['pending'])) {
        $pending_documents++;
    } elseif (in_array($status, ['done', 'completed'])) {
        $completed_documents++;
    } elseif (in_array($status, ['processing', 'ready to pick up'])) {
        $processing_documents++;
    }
    
    // Check for expiring documents (next 30 days)
    if (in_array($status, ['done', 'completed'])) {
        $otherDetails = $req['otherDetails'] ?? [];
        if (is_array($otherDetails)) {
            $expiry_date = null;
            foreach (['expiryDate', 'validityEnd', 'expiresAt', 'validUntil', 'endDate'] as $key) {
                if (isset($otherDetails[$key])) {
                    $expiry_str = $otherDetails[$key];
                    if (preg_match('/(\d{4}-\d{2}-\d{2})/', $expiry_str, $matches)) {
                        $expiry_date = $matches[1];
                    } else {
                        $timestamp = strtotime($expiry_str);
                        if ($timestamp) {
                            $expiry_date = date('Y-m-d', $timestamp);
                        }
                    }
                    break;
                }
            }
            
            if ($expiry_date && $expiry_date >= $today_date && $expiry_date <= $thirty_days_later_docs) {
                $expiring_documents_30days++;
            }
        }
    }
    
    // Check for newly issued documents (last 7 days)
    if (in_array($status, ['done', 'completed'])) {
        $done_date = '';
        if ($doneAt) {
            if (preg_match('/(\d{4}-\d{2}-\d{2})/', $doneAt, $matches)) {
                $done_date = $matches[1];
            } else {
                $timestamp = strtotime($doneAt);
                if ($timestamp) {
                    $done_date = date('Y-m-d', $timestamp);
                }
            }
        }
        
        if ($done_date && $done_date >= $last_7_days && $done_date <= $today_date) {
            $newly_issued_documents++;
        }
    }
}

// Process walk-in requests for document status
if (isset($walkin_requests)) {
    foreach ($walkin_requests as $req) {
        $status = strtolower(trim($req['status'] ?? ''));
        $created_at = $req['created_at'] ?? '';
        $updated_at = $req['updated_at'] ?? '';
        
        // Count all documents
        $total_document_list++;
        
        // Count by status
        if ($status === 'rejected') {
            $rejected_documents++;
        } elseif (in_array($status, ['pending', 'under review'])) {
            $pending_documents++;
        } elseif ($status === 'completed') {
            $completed_documents++;
        }
        
        // Check for newly issued documents (last 7 days)
        if ($status === 'completed') {
            $done_date = date('Y-m-d', strtotime($updated_at ?: $created_at));
            if ($done_date >= $last_7_days && $done_date <= $today_date) {
                $newly_issued_documents++;
            }
        }
    }
}

// Get daily trend data for last 7 days
$daily_trend = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $day_name = date('D', strtotime("-$i days"));
    $daily_trend[$date] = [
        'label' => $day_name,
        'count' => 0
    ];
}

// Get permit/clearance statistics
$permit_types = ['Barangay Clearance', 'Barangay Business Permit', 'Barangay Business Clearance', 'Business Permit', 'Permit'];
$pending_permits = 0;
$approved_permits_today = 0;
$expiring_permits_30days = 0;
$total_permits_this_month = 0;

$today = date('Y-m-d');
$today_start = date('Y-m-d 00:00:00');
$today_end = date('Y-m-d 23:59:59');
$thirty_days_later = date('Y-m-d', strtotime('+30 days'));

// Process JSON requests for permits/clearances
foreach ($all_json_requests as $req) {
    $doc_type = $req['documentType'] ?? '';
    $status = strtolower(trim($req['status'] ?? ''));
    $dateRequested = $req['dateRequested'] ?? '';
    $doneAt = $req['doneAt'] ?? '';
    
    // Check if it's a permit/clearance type
    $is_permit = false;
    foreach ($permit_types as $permit_type) {
        if (stripos($doc_type, $permit_type) !== false) {
            $is_permit = true;
            break;
        }
    }
    
    if (!$is_permit) continue;
    
    // Count pending permits
    if (in_array($status, ['pending', 'processing', 'ready to pick up'])) {
        $pending_permits++;
    }
    
    // Count approved permits today
    if (in_array($status, ['done', 'completed'])) {
        $done_date = '';
        if ($doneAt) {
            if (preg_match('/(\d{4}-\d{2}-\d{2})/', $doneAt, $matches)) {
                $done_date = $matches[1];
            } else {
                $timestamp = strtotime($doneAt);
                if ($timestamp) {
                    $done_date = date('Y-m-d', $timestamp);
                }
            }
        }
        
        if ($done_date === $today) {
            $approved_permits_today++;
        }
        
        // Count total permits this month
        if ($done_date && $done_date >= $current_month_start && $done_date <= $current_month_end) {
            $total_permits_this_month++;
        }
        
        // Check for expiring permits (if validity/expiry date exists in otherDetails)
        $otherDetails = $req['otherDetails'] ?? [];
        if (is_array($otherDetails)) {
            // Look for expiry/validity dates
            $expiry_date = null;
            foreach (['expiryDate', 'validityEnd', 'expiresAt', 'validUntil', 'endDate'] as $key) {
                if (isset($otherDetails[$key])) {
                    $expiry_str = $otherDetails[$key];
                    if (preg_match('/(\d{4}-\d{2}-\d{2})/', $expiry_str, $matches)) {
                        $expiry_date = $matches[1];
                    } else {
                        $timestamp = strtotime($expiry_str);
                        if ($timestamp) {
                            $expiry_date = date('Y-m-d', $timestamp);
                        }
                    }
                    break;
                }
            }
            
            if ($expiry_date && $expiry_date >= $today && $expiry_date <= $thirty_days_later) {
                $expiring_permits_30days++;
            }
        }
    }
}

// Process walk-in requests for permits/clearances
if (isset($walkin_requests)) {
    foreach ($walkin_requests as $req) {
        $type = $req['type'] ?? '';
        $status = strtolower(trim($req['status'] ?? ''));
        $created_at = $req['created_at'] ?? '';
        $updated_at = $req['updated_at'] ?? '';
        
        // Check if it's a permit/clearance type
        $is_permit = false;
        foreach ($permit_types as $permit_type) {
            if (stripos($type, $permit_type) !== false || stripos($type, 'permit') !== false || stripos($type, 'clearance') !== false) {
                $is_permit = true;
                break;
            }
        }
        
        if (!$is_permit) continue;
        
        // Count pending permits
        if (in_array($status, ['pending', 'under review'])) {
            $pending_permits++;
        }
        
        // Count approved permits today
        if ($status === 'completed') {
            $done_date = date('Y-m-d', strtotime($updated_at ?: $created_at));
            if ($done_date === $today) {
                $approved_permits_today++;
            }
            
            // Count total permits this month
            if ($done_date >= $current_month_start && $done_date <= $current_month_end) {
                $total_permits_this_month++;
            }
        }
    }
}

// Count requests per day from JSON files
foreach ($all_json_requests as $req) {
    $dateRequested = $req['dateRequested'] ?? $req['created_at'] ?? '';
    if ($dateRequested) {
        $parsed_date = false;
        if (preg_match('/(\d{4}-\d{2}-\d{2})/', $dateRequested, $matches)) {
            $parsed_date = $matches[1];
        } else {
            $timestamp = strtotime($dateRequested);
            if ($timestamp) {
                $parsed_date = date('Y-m-d', $timestamp);
            }
        }
        if ($parsed_date && isset($daily_trend[$parsed_date])) {
            $daily_trend[$parsed_date]['count']++;
        }
    }
}

// Count walk-in requests per day
if (isset($walkin_requests)) {
    foreach ($walkin_requests as $req) {
        $created_at = $req['created_at'] ?? '';
        if ($created_at) {
            $parsed_date = date('Y-m-d', strtotime($created_at));
            if (isset($daily_trend[$parsed_date])) {
                $daily_trend[$parsed_date]['count']++;
            }
        }
    }
}

// Get Events and Calendar Data
$events_file = __DIR__ . '/../data/programs_events.json';
$all_events = [];
if (file_exists($events_file)) {
    $all_events = json_decode(file_get_contents($events_file), true) ?? [];
}
if (!is_array($all_events)) {
    $all_events = [];
}

// Get upcoming events (next 30 days)
$upcoming_events = [];
$today_timestamp = strtotime('today');
$thirty_days_later_timestamp = strtotime('+30 days');

foreach ($all_events as $event) {
    if (isset($event['start_date'])) {
        $event_timestamp = strtotime($event['start_date']);
        if ($event_timestamp >= $today_timestamp && $event_timestamp <= $thirty_days_later_timestamp) {
            $upcoming_events[] = $event;
        }
    }
}

// Sort upcoming events by date
usort($upcoming_events, function($a, $b) {
    $dateA = strtotime($a['start_date'] ?? '');
    $dateB = strtotime($b['start_date'] ?? '');
    return $dateA - $dateB;
});

// Get events for current month (for calendar highlighting)
$current_month_events = [];
$current_month = date('n');
$current_year = date('Y');
foreach ($all_events as $event) {
    if (isset($event['start_date'])) {
        $event_timestamp = strtotime($event['start_date']);
        if (date('n', $event_timestamp) == $current_month && date('Y', $event_timestamp) == $current_year) {
            $day = date('j', $event_timestamp);
            if (!isset($current_month_events[$day])) {
                $current_month_events[$day] = [];
            }
            $current_month_events[$day][] = $event;
        }
    }
}

// Get event categories
$event_categories = ['Community', 'Health', 'Security', 'Meetings', 'Announcements'];

// Get Projects Data
$projects_file = __DIR__ . '/../data/projects.json';
$all_projects = [];
if (file_exists($projects_file)) {
    $all_projects = json_decode(file_get_contents($projects_file), true) ?? [];
}
if (!is_array($all_projects)) {
    $all_projects = [];
}

// Categorize projects
$ongoing_projects = [];
$upcoming_projects = [];
$completed_projects = [];

foreach ($all_projects as $project) {
    $status = strtolower(trim($project['status'] ?? ''));
    $start_date = $project['start_date'] ?? '';
    $target_date = $project['target_date'] ?? '';
    $completion_date = $project['completion_date'] ?? '';
    
    if (in_array($status, ['ongoing', 'in progress', 'in-progress'])) {
        $ongoing_projects[] = $project;
    } elseif (in_array($status, ['planning', 'upcoming', 'scheduled', 'pending'])) {
        $upcoming_projects[] = $project;
    } elseif (in_array($status, ['completed', 'done', 'finished'])) {
        $completed_projects[] = $project;
    } else {
        // Default: check dates
        if ($start_date && strtotime($start_date) > time()) {
            $upcoming_projects[] = $project;
        } elseif ($completion_date || ($target_date && strtotime($target_date) < time())) {
            $completed_projects[] = $project;
        } else {
            $ongoing_projects[] = $project;
        }
    }
}

// Sort projects
usort($ongoing_projects, function($a, $b) {
    return ($b['progress'] ?? 0) - ($a['progress'] ?? 0);
});
usort($upcoming_projects, function($a, $b) {
    $dateA = strtotime($a['start_date'] ?? '');
    $dateB = strtotime($b['start_date'] ?? '');
    return $dateA - $dateB;
});
usort($completed_projects, function($a, $b) {
    $dateA = strtotime($a['completion_date'] ?? $a['target_date'] ?? '');
    $dateB = strtotime($b['completion_date'] ?? $b['target_date'] ?? '');
    return $dateB - $dateA;
});

// Calendar calculations for current month
$first_day = mktime(0, 0, 0, $current_month, 1, $current_year);
$days_in_month = date('t', $first_day);
$day_of_week = date('w', $first_day);
$day_of_week = $day_of_week == 0 ? 7 : $day_of_week; // Make Sunday = 7

// Calculate Service Performance Indicators (KPIs)
$total_processing_time = 0;
$completed_requests_count = 0;
$same_day_completions = 0;
$total_requests_for_same_day = 0;
$request_hours = [];
$module_activity = [
    'Document Requests' => 0,
    'Resident Management' => 0,
    'Permits & Clearances' => 0,
    'Events & Programs' => 0,
    'Projects' => 0
];

// Process JSON requests for KPIs
foreach ($all_json_requests as $req) {
    $status = strtolower(trim($req['status'] ?? ''));
    $dateRequested = $req['dateRequested'] ?? '';
    $doneAt = $req['doneAt'] ?? '';
    $doc_type = $req['documentType'] ?? '';
    
    // Calculate processing time for completed requests
    if (in_array($status, ['done', 'completed']) && $dateRequested && $doneAt) {
        // Parse dateRequested - can be "November 19, 2025 05:42 PM" or "2025-11-19 17:42:00"
        $request_timestamp = strtotime($dateRequested);
        
        // Parse doneAt - should be "2025-11-23 11:44:23" format
        $done_timestamp = strtotime($doneAt);
        
        // Both timestamps must be valid
        if ($request_timestamp !== false && $done_timestamp !== false && $request_timestamp > 0 && $done_timestamp > 0) {
            $processing_time_hours = ($done_timestamp - $request_timestamp) / 3600; // Convert to hours
            if ($processing_time_hours >= 0) {
                $total_processing_time += $processing_time_hours;
                $completed_requests_count++;
                
                // Check for same-day completion
                $request_date = date('Y-m-d', $request_timestamp);
                $done_date = date('Y-m-d', $done_timestamp);
                if ($request_date === $done_date) {
                    $same_day_completions++;
                }
                $total_requests_for_same_day++;
            }
        }
    }
    
    // Track request hours - handle both date formats
    if ($dateRequested) {
        $request_timestamp = strtotime($dateRequested);
        if ($request_timestamp !== false && $request_timestamp > 0) {
            $hour = date('G', $request_timestamp); // 0-23 format
            $request_hours[$hour] = ($request_hours[$hour] ?? 0) + 1;
        }
    }
    
    // Track module activity
    if (stripos($doc_type, 'permit') !== false || stripos($doc_type, 'clearance') !== false) {
        $module_activity['Permits & Clearances']++;
    } else {
        $module_activity['Document Requests']++;
    }
}

// Process walk-in requests for KPIs
if (isset($walkin_requests)) {
    foreach ($walkin_requests as $req) {
        $status = strtolower(trim($req['status'] ?? ''));
        $created_at = $req['created_at'] ?? '';
        $updated_at = $req['updated_at'] ?? '';
        
        // Calculate processing time
        if ($status === 'completed' && $created_at && $updated_at) {
            $request_timestamp = strtotime($created_at);
            $done_timestamp = strtotime($updated_at);
            
            // Both timestamps must be valid
            if ($request_timestamp !== false && $done_timestamp !== false && $request_timestamp > 0 && $done_timestamp > 0) {
                $processing_time_hours = ($done_timestamp - $request_timestamp) / 3600;
                if ($processing_time_hours >= 0) {
                    $total_processing_time += $processing_time_hours;
                    $completed_requests_count++;
                    
                    // Check for same-day completion
                    $request_date = date('Y-m-d', $request_timestamp);
                    $done_date = date('Y-m-d', $done_timestamp);
                    if ($request_date === $done_date) {
                        $same_day_completions++;
                    }
                    $total_requests_for_same_day++;
                }
            }
        }
        
        // Track request hours
        if ($created_at) {
            $request_timestamp = strtotime($created_at);
            if ($request_timestamp !== false && $request_timestamp > 0) {
                $hour = date('G', $request_timestamp);
                $request_hours[$hour] = ($request_hours[$hour] ?? 0) + 1;
            }
        }
        
        // Track module activity
        $type = $req['type'] ?? '';
        if (stripos($type, 'permit') !== false || stripos($type, 'clearance') !== false) {
            $module_activity['Permits & Clearances']++;
        } else {
            $module_activity['Document Requests']++;
        }
    }
}

// Calculate KPIs
$average_processing_time = 0;
if ($completed_requests_count > 0) {
    $average_processing_time = $total_processing_time / $completed_requests_count;
}

$same_day_completion_percentage = 0;
if ($total_requests_for_same_day > 0) {
    $same_day_completion_percentage = ($same_day_completions / $total_requests_for_same_day) * 100;
}

// Find peak request hour
$peak_request_hour = 'N/A';
$peak_hour_count = 0;
if (!empty($request_hours)) {
    arsort($request_hours);
    $peak_hour = array_key_first($request_hours);
    $peak_hour_count = $request_hours[$peak_hour];
    if ($peak_hour !== null) {
        $peak_request_hour = date('g A', mktime($peak_hour, 0, 0));
    }
}

// Find most active system module
$most_active_module = 'N/A';
if (!empty($module_activity)) {
    arsort($module_activity);
    $most_active_module = array_key_first($module_activity);
}

// Also count resident management activity (based on total residents)
$module_activity['Resident Management'] = $stats['total_registered'] ?? 0;

// Count events
$module_activity['Events & Programs'] = count($all_events);

// Count projects
$module_activity['Projects'] = count($all_projects);

// Recalculate most active module with all data
if (!empty($module_activity)) {
    arsort($module_activity);
    $most_active_module = array_key_first($module_activity);
}

// Get Feedback & Complaints Data
$feedback_file = __DIR__ . '/../data/feedbacks/feedback.json';
$all_feedbacks = [];
if (file_exists($feedback_file)) {
    $all_feedbacks = json_decode(file_get_contents($feedback_file), true) ?? [];
}
if (!is_array($all_feedbacks)) {
    $all_feedbacks = [];
}

// Categorize complaints/feedback
$new_complaints = 0;
$resolved_complaints = 0;
$pending_complaints = 0;
$recent_complaints = [];

foreach ($all_feedbacks as $index => $feedback) {
    $subject = strtolower(trim($feedback['subject'] ?? ''));
    $read = $feedback['read'] ?? false;
    $date = $feedback['date'] ?? '';
    
    // Treat "Concern" as complaints, others as general feedback
    $is_complaint = (stripos($subject, 'concern') !== false || stripos($subject, 'complaint') !== false);
    
    if ($is_complaint) {
        // Generate complaint ID
        $complaint_id = 'COMP-' . str_pad($index + 1, 6, '0', STR_PAD_LEFT);
        
        if (!$read) {
            $new_complaints++;
            $pending_complaints++;
        } else {
            $resolved_complaints++;
        }
        
        // Add to recent complaints list
        $recent_complaints[] = [
            'id' => $complaint_id,
            'subject' => $feedback['subject'] ?? 'Concern',
            'fullname' => $feedback['fullname'] ?? 'Anonymous',
            'date' => $date,
            'read' => $read,
            'status' => $read ? 'Resolved' : 'Pending'
        ];
    }
}

// Sort recent complaints by date (newest first)
usort($recent_complaints, function($a, $b) {
    $dateA = strtotime($a['date'] ?? '');
    $dateB = strtotime($b['date'] ?? '');
    return $dateB - $dateA;
});

// Get only the 5 most recent complaints
$recent_complaints = array_slice($recent_complaints, 0, 5);

// Get Incident & Safety Monitoring Data
$total_incidents = 0;
$resolved_incidents = 0;
$pending_investigations = 0;
$critical_incidents = 0;
$incident_categories = [
    'Domestic' => 0,
    'Theft' => 0,
    'VAWC' => 0,
    'Traffic' => 0,
    'Others' => 0
];
$incident_days = [];
$incident_hours = [];

// Process JSON requests for incidents
foreach ($all_json_requests as $req) {
    $doc_type = strtolower(trim($req['documentType'] ?? ''));
    $status = strtolower(trim($req['status'] ?? ''));
    $dateRequested = $req['dateRequested'] ?? '';
    $otherDetails = $req['otherDetails'] ?? [];
    $description = $req['description'] ?? '';
    
    // Check if it's an incident report
    $is_incident = (stripos($doc_type, 'incident') !== false || 
                    stripos($doc_type, 'blotter') !== false);
    
    if (!$is_incident) continue;
    
    $total_incidents++;
    
    // Count by status
    if (in_array($status, ['done', 'completed', 'resolved'])) {
        $resolved_incidents++;
    } elseif (in_array($status, ['pending', 'processing', 'under review'])) {
        $pending_investigations++;
    }
    
    // Check for critical incidents (based on keywords in description or category)
    $description_lower = strtolower($description);
    $is_critical = (stripos($description_lower, 'critical') !== false ||
                    stripos($description_lower, 'urgent') !== false ||
                    stripos($description_lower, 'emergency') !== false ||
                    stripos($description_lower, 'violence') !== false ||
                    stripos($description_lower, 'assault') !== false ||
                    stripos($description_lower, 'vawc') !== false);
    
    if ($is_critical) {
        $critical_incidents++;
    }
    
    // Categorize incidents
    $category_found = false;
    $description_lower = strtolower($description . ' ' . ($otherDetails['description'] ?? ''));
    
    if (stripos($description_lower, 'domestic') !== false || 
        stripos($description_lower, 'family') !== false ||
        stripos($description_lower, 'spouse') !== false) {
        $incident_categories['Domestic']++;
        $category_found = true;
    }
    
    if (stripos($description_lower, 'theft') !== false || 
        stripos($description_lower, 'stolen') !== false ||
        stripos($description_lower, 'robbery') !== false) {
        $incident_categories['Theft']++;
        $category_found = true;
    }
    
    if (stripos($description_lower, 'vawc') !== false || 
        stripos($description_lower, 'violence against women') !== false ||
        stripos($description_lower, 'abuse') !== false) {
        $incident_categories['VAWC']++;
        $category_found = true;
    }
    
    if (stripos($description_lower, 'traffic') !== false || 
        stripos($description_lower, 'accident') !== false ||
        stripos($description_lower, 'vehicle') !== false ||
        stripos($description_lower, 'collision') !== false) {
        $incident_categories['Traffic']++;
        $category_found = true;
    }
    
    if (!$category_found) {
        $incident_categories['Others']++;
    }
    
    // Track incident days and hours for heatmap
    // Priority: Use actual incident date/time from otherDetails, fallback to dateRequested
    $incident_timestamp = null;
    
    // First, try to get the actual incident date/time from otherDetails
    if (is_array($otherDetails)) {
        // Check for combined date+time or separate fields
        $incident_date = $otherDetails['dtIncident'] ?? $otherDetails['incident_date'] ?? '';
        $incident_time = $otherDetails['incident_time'] ?? '';
        
        // If we have date and time separately, combine them
        if (empty($incident_date) && isset($otherDetails['date']) && isset($otherDetails['time'])) {
            $incident_date = $otherDetails['date'] . ' ' . $otherDetails['time'];
        }
        
        if ($incident_date) {
            $incident_timestamp = strtotime($incident_date);
            if ($incident_timestamp === false || $incident_timestamp <= 0) {
                $incident_timestamp = null;
            }
        }
    }
    
    // Fallback to dateRequested (when the report was submitted)
    if ($incident_timestamp === null && $dateRequested) {
        $incident_timestamp = strtotime($dateRequested);
        if ($incident_timestamp === false || $incident_timestamp <= 0) {
            $incident_timestamp = null;
        }
    }
    
    // Track the day and hour
    if ($incident_timestamp !== null) {
        $day_name = date('D', $incident_timestamp); // Mon, Tue, etc.
        $hour = date('G', $incident_timestamp); // 0-23
        
        $incident_days[$day_name] = ($incident_days[$day_name] ?? 0) + 1;
        $incident_hours[$hour] = ($incident_hours[$hour] ?? 0) + 1;
    }
}

// Process walk-in requests for incidents
if (isset($walkin_requests)) {
    foreach ($walkin_requests as $req) {
        $type = strtolower(trim($req['type'] ?? ''));
        $category = strtolower(trim($req['category'] ?? ''));
        $status = strtolower(trim($req['status'] ?? ''));
        $description = $req['description'] ?? '';
        $created_at = $req['created_at'] ?? '';
        
        // Check if it's an incident
        $is_incident = (stripos($type, 'incident') !== false || 
                        stripos($type, 'blotter') !== false ||
                        stripos($category, 'incident') !== false);
        
        if (!$is_incident) continue;
        
        $total_incidents++;
        
        if ($status === 'completed') {
            $resolved_incidents++;
        } elseif (in_array($status, ['pending', 'under review'])) {
            $pending_investigations++;
        }
        
        // Check for critical
        $description_lower = strtolower($description);
        $is_critical = (stripos($description_lower, 'critical') !== false ||
                        stripos($description_lower, 'urgent') !== false ||
                        stripos($description_lower, 'emergency') !== false ||
                        stripos($description_lower, 'violence') !== false ||
                        stripos($description_lower, 'assault') !== false ||
                        stripos($description_lower, 'vawc') !== false);
        
        if ($is_critical) {
            $critical_incidents++;
        }
        
        // Categorize
        $category_found = false;
        if (stripos($description_lower, 'domestic') !== false || 
            stripos($description_lower, 'family') !== false) {
            $incident_categories['Domestic']++;
            $category_found = true;
        }
        if (stripos($description_lower, 'theft') !== false || 
            stripos($description_lower, 'stolen') !== false) {
            $incident_categories['Theft']++;
            $category_found = true;
        }
        if (stripos($description_lower, 'vawc') !== false || 
            stripos($description_lower, 'violence against women') !== false) {
            $incident_categories['VAWC']++;
            $category_found = true;
        }
        if (stripos($description_lower, 'traffic') !== false || 
            stripos($description_lower, 'accident') !== false) {
            $incident_categories['Traffic']++;
            $category_found = true;
        }
        if (!$category_found) {
            $incident_categories['Others']++;
        }
        
        // Track days and hours
        if ($created_at) {
            $incident_timestamp = strtotime($created_at);
            if ($incident_timestamp !== false && $incident_timestamp > 0) {
                $day_name = date('D', $incident_timestamp);
                $hour = date('G', $incident_timestamp);
                
                $incident_days[$day_name] = ($incident_days[$day_name] ?? 0) + 1;
                $incident_hours[$hour] = ($incident_hours[$hour] ?? 0) + 1;
            }
        }
    }
}

// Find peak day and hour
$peak_day = 'N/A';
$peak_hour = 'N/A';
if (!empty($incident_days)) {
    arsort($incident_days);
    $peak_day = array_key_first($incident_days);
}
if (!empty($incident_hours)) {
    arsort($incident_hours);
    $peak_hour_num = array_key_first($incident_hours);
    if ($peak_hour_num !== null) {
        $peak_hour = date('g A', mktime($peak_hour_num, 0, 0));
    }
}

// Get Emergency & Safety Data
$emergency_file = __DIR__ . '/../data/emergency_data.json';
$emergency_data = [
    'contacts' => [
        'PNP' => '',
        'BFP' => '',
        'Health Center' => ''
    ],
    'live_info' => [
        'weather' => '',
        'alert_status' => 'Normal',
        'active_emergency_cases' => 0,
        'emergency_cases_list' => [],
        'active_evacuation_centers' => 0
    ]
];

// Load existing emergency data
if (file_exists($emergency_file)) {
    $loaded_data = json_decode(file_get_contents($emergency_file), true);
    if (is_array($loaded_data)) {
        $emergency_data = array_merge($emergency_data, $loaded_data);
    }
}

// Handle emergency data update (if POST request)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_emergency') {
    $emergency_dir = __DIR__ . '/../data';
    if (!is_dir($emergency_dir)) {
        mkdir($emergency_dir, 0777, true);
    }
    
    // Update contacts
    if (isset($_POST['contacts']) && is_array($_POST['contacts'])) {
        foreach ($_POST['contacts'] as $key => $value) {
            $emergency_data['contacts'][$key] = trim($value);
        }
    }
    
    // Update live info
    if (isset($_POST['live_info']) && is_array($_POST['live_info'])) {
        foreach ($_POST['live_info'] as $key => $value) {
            if ($key === 'emergency_cases_list') {
                // Handle JSON-encoded array
                if (is_string($value)) {
                    $decoded = json_decode($value, true);
                    if (is_array($decoded)) {
                        $emergency_data['live_info'][$key] = $decoded;
                    } else {
                        // Fallback: treat as comma-separated string
                        $cases = array_filter(array_map('trim', explode(',', $value)));
                        $emergency_data['live_info'][$key] = $cases;
                    }
                } else {
                    $emergency_data['live_info'][$key] = $value;
                }
            } else {
                $emergency_data['live_info'][$key] = trim($value);
            }
        }
    }
    
    // Save to file
    file_put_contents($emergency_file, json_encode($emergency_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    // Reload the data
    $loaded_data = json_decode(file_get_contents($emergency_file), true);
    if (is_array($loaded_data)) {
        $emergency_data = array_merge($emergency_data, $loaded_data);
    }
}

// Extract values for display
$pnp_contact = $emergency_data['contacts']['PNP'] ?? '';
$bfp_contact = $emergency_data['contacts']['BFP'] ?? '';
$health_center_contact = $emergency_data['contacts']['Health Center'] ?? '';
$weather = $emergency_data['live_info']['weather'] ?? '';
$alert_status = $emergency_data['live_info']['alert_status'] ?? 'Normal';
$active_emergency_cases = $emergency_data['live_info']['active_emergency_cases'] ?? 0;
$emergency_cases_list = $emergency_data['live_info']['emergency_cases_list'] ?? [];
$active_evacuation_centers = $emergency_data['live_info']['active_evacuation_centers'] ?? 0;

// Get Staff/User Activity & Login Data (Super Admin Only)
    $active_users_today = 0;
    $active_residents_today = 0;
    $failed_login_attempts = 0;

if ($admin_role === 'super_admin') {
    // Active Users Today (admins who logged in today)
    try {
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT id) as count FROM admins WHERE DATE(last_login) = CURDATE() AND last_login IS NOT NULL");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $active_users_today = $result['count'] ?? 0;
    } catch (Exception $e) {
        $active_users_today = 0;
    }
    
    // Active Residents Today (residents who logged in today)
    try {
        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT id) as count FROM residents WHERE DATE(last_login) = CURDATE() AND last_login IS NOT NULL AND (deleted_at IS NULL OR deleted_at = '')");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $active_residents_today = $result['count'] ?? 0;
    } catch (Exception $e) {
        // Column might not exist, try without last_login
        $active_residents_today = 0;
    }
    
    // Failed Login Attempts (24h) - This would need a login_attempts table, for now use placeholder
    // In a real system, you'd track failed logins in a separate table
    $failed_login_attempts = 0; // Placeholder
}

// Get System Health Data (Super Admin Only)
$database_size = 'N/A';
$api_status = 'Active';
$last_backup = 'N/A';
$user_activity_24h = 0;
$storage_usage = 'N/A';

if ($admin_role === 'super_admin') {
    // Database Size
    try {
        $stmt = $pdo->query("
            SELECT 
                ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS 'size_mb'
            FROM information_schema.tables 
            WHERE table_schema = DATABASE()
        ");
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $db_size_mb = $result['size_mb'] ?? 0;
        if ($db_size_mb > 0) {
            $database_size = number_format($db_size_mb, 2) . ' MB';
        }
    } catch (Exception $e) {
        $database_size = 'N/A';
    }
    
    // API Status (check if system is responsive)
    $api_status = 'Active'; // Can be enhanced to check actual API endpoints
    
    // Last Backup (check backup directory or database)
    $backup_dir = __DIR__ . '/../backups';
    if (is_dir($backup_dir)) {
        $backup_files = glob($backup_dir . '/*.sql');
        if (!empty($backup_files)) {
            $latest_backup = max(array_map('filemtime', $backup_files));
            $last_backup = date('M d, Y H:i', $latest_backup);
        }
    }
    
    // User Activity (24h) - count activity logs in last 24 hours
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM activity_log WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $user_activity_24h = $result['count'] ?? 0;
    } catch (Exception $e) {
        $user_activity_24h = 0;
    }
    
    // Storage Usage (calculate data directory size)
    $data_dir = __DIR__ . '/../data';
    if (is_dir($data_dir)) {
        $size = 0;
        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($data_dir, RecursiveDirectoryIterator::SKIP_DOTS),
                RecursiveIteratorIterator::SELF_FIRST
            );
            foreach ($iterator as $file) {
                if ($file->isFile()) {
                    $size += $file->getSize();
                }
            }
            $storage_usage = number_format($size / 1024 / 1024, 2) . ' MB';
        } catch (Exception $e) {
            // Fallback: simple directory size calculation
            $files = glob($data_dir . '/*');
            $size = 0;
            foreach ($files as $file) {
                if (is_file($file)) {
                    $size += filesize($file);
                }
            }
            $storage_usage = number_format($size / 1024 / 1024, 2) . ' MB';
        }
    }
}

// Get Recent Activity Logs (for all admins and residents)
$recent_activity_logs = [];
try {
    // Check if resident_id column exists in activity_log table
    $stmt = $pdo->query("SHOW COLUMNS FROM activity_log LIKE 'resident_id'");
    $has_resident_id = $stmt->rowCount() > 0;
    
    if ($has_resident_id) {
        // Query with both admin and resident support
        $stmt = $pdo->prepare("
            SELECT 
                al.*, 
                a.full_name as admin_name, 
                a.email as admin_email,
                r.first_name as resident_first_name,
                r.last_name as resident_last_name,
                r.email as resident_email,
                CASE 
                    WHEN al.admin_id IS NOT NULL THEN a.full_name
                    WHEN al.resident_id IS NOT NULL THEN CONCAT(r.first_name, ' ', r.last_name)
                    ELSE 'System'
                END as performer_name,
                CASE 
                    WHEN al.admin_id IS NOT NULL THEN a.email
                    WHEN al.resident_id IS NOT NULL THEN r.email
                    ELSE NULL
                END as performer_email,
                CASE 
                    WHEN al.admin_id IS NOT NULL THEN 'Admin'
                    WHEN al.resident_id IS NOT NULL THEN 'Resident'
                    ELSE 'System'
                END as performer_type
            FROM activity_log al 
            LEFT JOIN admins a ON al.admin_id = a.id 
            LEFT JOIN residents r ON al.resident_id = r.id
            ORDER BY al.created_at DESC 
            LIMIT 30
        ");
    } else {
        // Query with only admin support (backward compatible)
        $stmt = $pdo->prepare("
            SELECT 
                al.*, 
                a.full_name, 
                a.email,
                a.full_name as performer_name,
                a.email as performer_email,
                'Admin' as performer_type
            FROM activity_log al 
            LEFT JOIN admins a ON al.admin_id = a.id 
            ORDER BY al.created_at DESC 
            LIMIT 30
        ");
    }
    $stmt->execute();
    $recent_activity_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Table might not exist
    $recent_activity_logs = [];
}

// Dashboard refresh time
$dashboard_refresh_time = date('M d, Y H:i:s');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Barangay San Vicente II</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(245, 245, 220, 0.8);
            box-shadow: 0 0 8px rgba(245, 245, 220, 0.4);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        /* Main Content when sidebar is hidden */
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 12px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 16px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            transition: all 0.2s ease;
            position: relative;
        }
        .stat-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .stat-card h3 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 8px;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .stat-card .value {
            font-size: 42px;
            font-weight: 800;
            color: #000000;
            letter-spacing: -0.5px;
        }
        .stat-card .icon {
            width: 24px;
            height: 24px;
            margin-bottom: 8px;
            opacity: 0.6;
            color: #6b7280;
            flex-shrink: 0;
        }
        .stat-card .icon svg {
            width: 100%;
            height: 100%;
            display: block;
            shape-rendering: geometricPrecision;
            image-rendering: -webkit-optimize-contrast;
            image-rendering: crisp-edges;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .chart-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 12px;
        }
        .pie-chart-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 280px;
        }
        .bar-chart-wrapper {
            min-height: 280px;
        }
        @media (max-width: 968px) {
            .chart-container {
                grid-template-columns: 1fr;
            }
        }
        .age-chart {
            background: white;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        /* Document Requests Overview */
        .requests-overview-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 12px;
        }
        .requests-stats-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .request-stat-item {
            display: block;
            padding: 16px;
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            cursor: pointer;
        }
        .request-stat-item:hover {
            background: #f3f4f6;
            border-color: #87A96B;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
        }
        .request-stat-item:active {
            transform: translateY(0);
        }
        .request-stat-item .stat-label {
            font-size: 20px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 700;
        }
        .request-stat-item .stat-value {
            font-size: 38px;
            font-weight: 800;
            color: #000000;
        }
        .requests-trend-chart {
            display: flex;
            flex-direction: column;
        }
        .trend-chart-title {
            font-size: 20px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 12px;
        }
        .trend-chart-wrapper {
            flex: 1;
            min-height: 280px;
            position: relative;
        }
        @media (max-width: 968px) {
            .requests-overview-container {
                grid-template-columns: 1fr;
            }
        }
        /* Barangay Clearance & Permit Monitoring */
        .permits-cards-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-top: 12px;
        }
        .permit-card {
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: all 0.3s ease;
        }
        .permit-card:hover {
            background: #f3f4f6;
            border-color: #87A96B;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
        }
        .permit-card-icon {
            width: 48px;
            height: 48px;
            background: rgba(135, 169, 107, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: #87A96B;
        }
        .permit-card-icon svg {
            width: 24px;
            height: 24px;
        }
        .permit-card-content {
            flex: 1;
            min-width: 0;
        }
        .permit-card-label {
            font-size: 19px;
            color: #6b7280;
            margin-bottom: 6px;
            font-weight: 700;
            line-height: 1.4;
        }
        .permit-card-value {
            font-size: 38px;
            font-weight: 800;
            color: #000000;
            line-height: 1.2;
        }
        @media (max-width: 1200px) {
            .permits-cards-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 768px) {
            .permits-cards-grid {
                grid-template-columns: 1fr;
            }
        }
        /* Important Documents Status */
        .documents-status-card {
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            margin-top: 12px;
        }
        .documents-status-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 16px;
        }
        .documents-status-row:last-of-type {
            margin-bottom: 0;
        }
        .documents-status-item {
            padding: 16px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.3s ease;
        }
        .documents-status-item:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .documents-status-label {
            font-size: 18px;
            font-weight: 700;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 500;
        }
        .documents-status-value {
            font-size: 28px;
            font-weight: 700;
            color: #2c3e2d;
        }
        .documents-status-breakdown {
            display: flex;
            gap: 16px;
            padding-top: 16px;
            border-top: 1px solid #e5e7eb;
            flex-wrap: wrap;
        }
        .breakdown-item {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            font-size: 13px;
        }
        .breakdown-label {
            color: #6b7280;
            font-weight: 500;
            font-size: 14px;
        }
        .breakdown-value {
            color: #2c3e2d;
            font-weight: 600;
        }
        @media (max-width: 768px) {
            .documents-status-row {
                grid-template-columns: 1fr;
            }
            .documents-status-breakdown {
                flex-direction: column;
            }
        }
        /* Calendar & Upcoming Events */
        .calendar-events-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 12px;
        }
        .calendar-section, .events-section {
            display: flex;
            flex-direction: column;
        }
        .calendar-section-title, .events-section-title {
            font-size: 20px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 12px;
        }
        .mini-calendar {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 12px;
        }
        .calendar-header {
            text-align: center;
            margin-bottom: 12px;
        }
        .calendar-month-year {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e2d;
        }
        .calendar-weekdays {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 4px;
            margin-bottom: 8px;
        }
        .calendar-weekday {
            text-align: center;
            font-size: 11px;
            font-weight: 600;
            color: #6b7280;
            padding: 4px;
        }
        .calendar-days {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 4px;
        }
        .calendar-day {
            aspect-ratio: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            border-radius: 4px;
            position: relative;
            cursor: pointer;
            transition: all 0.2s;
        }
        .calendar-day.empty {
            visibility: hidden;
        }
        .calendar-day.today {
            background: rgba(135, 169, 107, 0.1);
            border: 1px solid #87A96B;
        }
        .calendar-day.has-event {
            background: rgba(135, 169, 107, 0.05);
        }
        .calendar-day:hover:not(.empty) {
            background: rgba(135, 169, 107, 0.15);
        }
        .day-number {
            font-size: 12px;
            font-weight: 500;
            color: #2c3e2d;
        }
        .event-dot {
            width: 4px;
            height: 4px;
            background: #87A96B;
            border-radius: 50%;
            margin-top: 2px;
        }
        .highlighted-dates-info {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
        }
        .info-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: #6b7280;
        }
        .info-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }
        .info-dot.event {
            background: #87A96B;
        }
        .category-filters {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 16px;
        }
        .filter-btn {
            padding: 6px 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 500;
            color: #6b7280;
            cursor: pointer;
            transition: all 0.2s;
        }
        .filter-btn:hover, .filter-btn.active {
            background: #87A96B;
            border-color: #87A96B;
            color: white;
        }
        .events-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
            max-height: 400px;
            overflow-y: auto;
        }
        .event-item {
            padding: 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .event-item:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .event-item.hidden {
            display: none;
        }
        .event-title {
            font-size: 14px;
            font-weight: 600;
            color: #2c3e2d;
            margin-bottom: 4px;
        }
        .event-datetime {
            font-size: 14px;
            color: #6b7280;
        }
        .no-events {
            text-align: center;
            padding: 40px 20px;
            color: #9ca3af;
            font-size: 14px;
        }
        /* Barangay Projects Monitoring */
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 12px;
        }
        .projects-column {
            display: flex;
            flex-direction: column;
        }
        .projects-column-title {
            font-size: 20px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 12px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e5e7eb;
        }
        .projects-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .project-item {
            padding: 14px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .project-item:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .project-name {
            font-size: 14px;
            font-weight: 600;
            color: #2c3e2d;
            margin-bottom: 8px;
        }
        .project-progress {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .progress-bar {
            flex: 1;
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: #87A96B;
            border-radius: 4px;
            transition: width 0.3s;
        }
        .progress-text {
            font-size: 12px;
            font-weight: 600;
            color: #87A96B;
            min-width: 40px;
        }
        .project-date {
            font-size: 14px;
            color: #6b7280;
        }
        .no-projects {
            text-align: center;
            padding: 40px 20px;
            color: #9ca3af;
            font-size: 14px;
        }
        @media (max-width: 1200px) {
            .calendar-events-container {
                grid-template-columns: 1fr;
            }
            .projects-grid {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 768px) {
            .calendar-days {
                gap: 2px;
            }
            .calendar-day {
                font-size: 11px;
            }
        }
        /* Service Performance Indicators (KPIs) */
        .kpi-cards-row {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-top: 12px;
        }
        .kpi-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: all 0.3s ease;
        }
        .kpi-card:hover {
            border-color: #87A96B;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
        }
        .kpi-icon {
            width: 48px;
            height: 48px;
            background: rgba(135, 169, 107, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: #87A96B;
        }
        .kpi-icon svg {
            width: 24px;
            height: 24px;
        }
        .kpi-content {
            flex: 1;
            min-width: 0;
        }
        .kpi-label {
            font-size: 15px;
            color: #6b7280;
            margin-bottom: 6px;
            font-weight: 500;
            line-height: 1.4;
        }
        .kpi-value {
            font-size: 22px;
            font-weight: 700;
            color: #2c3e2d;
            line-height: 1.2;
            word-break: break-word;
        }
        @media (max-width: 1200px) {
            .kpi-cards-row {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        @media (max-width: 768px) {
            .kpi-cards-row {
                grid-template-columns: 1fr;
            }
        }
        /* Feedback & Complaints Overview */
        .complaints-overview-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 12px;
        }
        .complaints-summary {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .complaint-stat-card {
            padding: 16px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .complaint-stat-card:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .complaint-stat-label {
            font-size: 19px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 700;
        }
        .complaint-stat-value {
            font-size: 42px;
            font-weight: 800;
            color: #000000;
        }
        .recent-complaints-section {
            display: flex;
            flex-direction: column;
        }
        .recent-complaints-title {
            font-size: 16px;
            font-weight: 600;
            color: #2c3e2d;
            margin-bottom: 12px;
        }
        .complaints-list {
            display: flex;
            flex-direction: column;
            gap: 8px;
            max-height: 300px;
            overflow-y: auto;
        }
        .complaint-item {
            padding: 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: all 0.2s;
        }
        .complaint-item:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .complaint-id {
            font-size: 13px;
            font-weight: 600;
            color: #2c3e2d;
        }
        .complaint-status {
            font-size: 12px;
            font-weight: 600;
            padding: 4px 10px;
            border-radius: 12px;
            text-transform: uppercase;
        }
        .complaint-status.pending {
            background: rgba(245, 158, 11, 0.1);
            color: #d97706;
        }
        .complaint-status.resolved {
            background: rgba(34, 197, 94, 0.1);
            color: #16a34a;
        }
        .no-complaints {
            text-align: center;
            padding: 40px 20px;
            color: #9ca3af;
            font-size: 14px;
        }
        @media (max-width: 968px) {
            .complaints-overview-container {
                grid-template-columns: 1fr;
            }
        }
        /* Incident & Safety Monitoring */
        .incident-monitoring-container {
            display: flex;
            flex-direction: column;
            gap: 24px;
            margin-top: 12px;
        }
        .incident-stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
        }
        .incident-stat-card {
            padding: 16px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .incident-stat-card:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .incident-stat-label {
            font-size: 19px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 700;
        }
        .incident-stat-value {
            font-size: 42px;
            font-weight: 800;
            color: #000000;
        }
        .incident-categories-section {
            padding: 20px;
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
        }
        .incident-section-title {
            font-size: 20px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 16px;
        }
        .incident-categories-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 12px;
        }
        .incident-category-item {
            padding: 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            text-align: center;
        }
        .category-label {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 6px;
            font-weight: 500;
        }
        .category-value {
            font-size: 20px;
            font-weight: 700;
            color: #2c3e2d;
        }
        .incident-heatmap-section {
            padding: 20px;
            background: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
        }
        .heatmap-info {
            margin-bottom: 20px;
        }
        .heatmap-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
        }
        .heatmap-label {
            font-size: 13px;
            color: #6b7280;
            font-weight: 500;
        }
        .heatmap-value {
            font-size: 14px;
            font-weight: 600;
            color: #2c3e2d;
        }
        .heatmap-visual {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 24px;
        }
        .heatmap-days {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .heatmap-day-label {
            font-size: 13px;
            font-weight: 600;
            color: #2c3e2d;
        }
        .heatmap-bars {
            display: flex;
            align-items: flex-end;
            gap: 8px;
            height: 150px;
            padding: 8px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
        }
        .heatmap-bar-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 4px;
            height: 100%;
        }
        .heatmap-bar {
            width: 100%;
            min-height: 4px;
            border-radius: 4px 4px 0 0;
            transition: all 0.3s;
        }
        .heatmap-bar-label {
            font-size: 10px;
            color: #6b7280;
            font-weight: 500;
        }
        .heatmap-bar-value {
            font-size: 10px;
            color: #2c3e2d;
            font-weight: 600;
        }
        .heatmap-hours {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .heatmap-hour-label {
            font-size: 13px;
            font-weight: 600;
            color: #2c3e2d;
        }
        .heatmap-hours-grid {
            display: grid;
            grid-template-columns: repeat(12, 1fr);
            gap: 4px;
            padding: 8px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
        }
        .heatmap-hour-cell {
            aspect-ratio: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 3px;
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }
        .heatmap-hour-cell:hover {
            transform: scale(1.1);
            z-index: 10;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }
        .hour-number {
            font-size: 9px;
            font-weight: 600;
            color: #2c3e2d;
            opacity: 0.7;
        }
        @media (max-width: 1200px) {
            .incident-stats-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .incident-categories-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            .heatmap-visual {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 768px) {
            .incident-stats-grid {
                grid-template-columns: 1fr;
            }
            .incident-categories-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .heatmap-hours-grid {
                grid-template-columns: repeat(8, 1fr);
            }
        }
        /* Emergency & Safety Panel */
        .emergency-panel-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 24px;
            margin-top: 12px;
        }
        .emergency-contacts-section, .live-emergency-section {
            display: flex;
            flex-direction: column;
        }
        .emergency-section-title {
            font-size: 20px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 16px;
            padding-bottom: 8px;
            border-bottom: 2px solid #e5e7eb;
        }
        .emergency-contacts-list, .live-emergency-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .emergency-contact-item, .emergency-info-item {
            padding: 14px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            transition: all 0.2s;
        }
        .emergency-contact-item:hover, .emergency-info-item:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .contact-label, .info-label {
            font-size: 15px;
            color: #6b7280;
            margin-bottom: 6px;
            font-weight: 500;
        }
        .contact-value, .info-value {
            font-size: 15px;
            font-weight: 600;
            color: #2c3e2d;
            min-height: 24px;
            padding: 4px 0;
        }
        .editable {
            cursor: text;
            border-bottom: 1px dashed transparent;
            transition: all 0.2s;
        }
        .editable:hover {
            border-bottom-color: #87A96B;
            background: rgba(135, 169, 107, 0.05);
            padding: 4px 8px;
            border-radius: 4px;
        }
        .editable:focus {
            outline: none;
            border-bottom-color: #87A96B;
            background: rgba(135, 169, 107, 0.1);
            padding: 4px 8px;
            border-radius: 4px;
        }
        .editable[contenteditable="true"]:empty:before {
            content: "Click to edit...";
            color: #9ca3af;
            font-weight: 400;
        }
        .editable.locked {
            cursor: not-allowed;
            opacity: 0.7;
            user-select: none;
        }
        .editable.locked:hover {
            border-bottom-color: transparent;
            background: transparent;
            padding: 4px 0;
        }
        .emergency-lock-btn {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 6px;
            padding: 8px 12px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
            color: #6b7280;
        }
        .emergency-lock-btn:hover {
            background: #f9fafb;
            border-color: #87A96B;
            color: #87A96B;
        }
        .emergency-lock-btn.locked {
            background: #fef3c7;
            border-color: #fbbf24;
            color: #d97706;
        }
        .emergency-lock-btn.locked:hover {
            background: #fde68a;
        }
        .emergency-lock-btn svg {
            width: 18px;
            height: 18px;
        }
        @media (max-width: 968px) {
            .emergency-panel-container {
                grid-template-columns: 1fr;
            }
        }
        /* Staff / User Activity & Login */
        .staff-activity-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 12px;
        }
        .staff-activity-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 16px;
        }
        .staff-stat-card {
            padding: 16px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        .staff-stat-card:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .staff-stat-label {
            font-size: 19px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 700;
        }
        .staff-stat-value {
            font-size: 42px;
            font-weight: 800;
            color: #000000;
        }
        .recent-admin-activities {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 20px;
        }
        .activity-section-title {
            font-size: 20px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 16px;
        }
        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .activity-item {
            padding: 12px;
            background: #f9fafb;
            border-radius: 6px;
            border-left: 3px solid #87A96B;
        }
        .activity-action {
            font-size: 14px;
            font-weight: 600;
            color: #2c3e2d;
            margin-bottom: 4px;
        }
        .activity-description {
            font-size: 15px;
            color: #6b7280;
            margin-bottom: 8px;
        }
        .activity-meta {
            display: flex;
            justify-content: space-between;
            font-size: 14px;
            color: #9ca3af;
        }
        .activity-user {
            font-weight: 500;
        }
        .activity-time {
            color: #9ca3af;
        }
        .no-activities {
            text-align: center;
            padding: 40px;
            color: #9ca3af;
            font-size: 14px;
        }
        /* System Health */
        .system-health-container {
            margin-top: 12px;
        }
        .system-health-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
        }
        .health-card {
            padding: 20px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: all 0.3s ease;
        }
        .health-card:hover {
            border-color: #87A96B;
            box-shadow: 0 2px 8px rgba(135, 169, 107, 0.1);
        }
        .health-icon {
            width: 40px;
            height: 40px;
            color: #87A96B;
            flex-shrink: 0;
        }
        .health-icon svg {
            width: 100%;
            height: 100%;
        }
        .health-content {
            flex: 1;
        }
        .health-label {
            font-size: 14px;
            color: #6b7280;
            margin-bottom: 4px;
            font-weight: 500;
        }
        .health-value {
            font-size: 18px;
            font-weight: 700;
            color: #2c3e2d;
        }
        .health-value.status-active {
            color: #16a34a;
        }
        /* Activity Logs Table */
        .activity-logs-container {
            margin-top: 24px;
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
            padding-bottom: 20px;
        }
        .activity-logs-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: auto;
        }
        .activity-logs-table th:nth-child(1),
        .activity-logs-table td:nth-child(1) {
            width: 40%;
        }
        .activity-logs-table th:nth-child(2),
        .activity-logs-table td:nth-child(2) {
            width: 20%;
        }
        .activity-logs-table th:nth-child(3),
        .activity-logs-table td:nth-child(3) {
            width: 25%;
        }
        .activity-logs-table th:nth-child(4),
        .activity-logs-table td:nth-child(4) {
            width: 15%;
        }
        .activity-logs-table thead {
            background: #2c3e2d;
        }
        .activity-logs-table th {
            padding: 16px;
            text-align: left;
            font-size: 16px;
            font-weight: 700;
            color: white;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
        }
        .activity-logs-table th:not(:first-child)::before {
            content: '';
            position: absolute;
            left: 0;
            top: 20%;
            bottom: 20%;
            width: 1px;
            background: rgba(212, 175, 55, 0.6);
        }
        .activity-logs-table td {
            padding: 16px;
            font-size: 16px;
            font-weight: 500;
            color: #6b7280;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            background: white;
        }
        .activity-logs-table tbody tr:hover td {
            background: rgba(135, 169, 107, 0.05);
        }
        .activity-logs-table tbody tr:last-child td {
            border-bottom: none;
        }
        .action-badge {
            display: inline-block;
            padding: 4px 10px;
            background: rgba(135, 169, 107, 0.1);
            color: #2c3e2d;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
        }
        .no-logs {
            text-align: center;
            padding: 40px;
            color: #9ca3af;
            font-size: 14px;
        }
        /* Dashboard Footer */
        .dashboard-footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
        .footer-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 20px;
        }
        .footer-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 15px;
        }
        .footer-label {
            color: #6b7280;
            font-weight: 500;
        }
        .footer-value {
            color: #2c3e2d;
            font-weight: 600;
        }
        @media (max-width: 768px) {
            .staff-activity-stats {
                grid-template-columns: 1fr;
            }
            .system-health-grid {
                grid-template-columns: 1fr;
            }
            .footer-content {
                flex-direction: column;
                align-items: flex-start;
            }
            .activity-logs-table {
            font-size: 12px;
            }
            .activity-logs-table th,
            .activity-logs-table td {
                padding: 8px 12px;
            }
        }
        .document-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .document-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 4px solid #d4af37;
            transition: all 0.3s;
        }
        .document-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.15);
        }
        .document-card h3 {
            font-size: 20px;
            font-weight: 800;
            margin-bottom: 10px;
            color: #1a5f3f;
        }
        .document-card .value {
            font-size: 46px;
            font-weight: 800;
            color: #000000;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .stats-grid {
                grid-template-columns: 1fr;
            }
            .chart-container {
                grid-template-columns: 1fr;
            }
            .row-container {
                padding: 20px;
            }
            .pie-chart-wrapper {
                min-height: 250px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="7" height="7"></rect>
                    <rect x="14" y="3" width="7" height="7"></rect>
                    <rect x="14" y="14" width="7" height="7"></rect>
                    <rect x="3" y="14" width="7" height="7"></rect>
                </svg>
            </span>
            Dashboard
        </h1>

        <!-- ROW A: Resident Information Summary -->
        <div class="row-container">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </span>
                Resident Information Summary
            </h2>
            <p class="section-description">Quick view of key barangay demographics.</p>
            
            <div class="chart-container">
                <!-- Pie Chart -->
                <div class="pie-chart-wrapper">
                    <canvas id="demographicsPieChart" style="max-width: 400px; max-height: 400px;"></canvas>
                </div>
                
                <!-- Stats Cards -->
                <div class="stats-grid" style="grid-template-columns: repeat(2, 1fr);">
            <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                        </div>
                        <h3>Total Registered Residents</h3>
                <div class="value"><?php echo number_format($stats['total_registered'] ?? 0); ?></div>
            </div>
            <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <h3>Active Residents</h3>
                        <div class="value"><?php echo number_format($stats['total_active'] ?? 0); ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                        </div>
                        <h3>Newly Added This Month</h3>
                        <div class="value"><?php echo number_format($stats['newly_added_month'] ?? 0); ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                <polyline points="9 22 9 12 15 12 15 22"></polyline>
                            </svg>
                        </div>
                        <h3>Households Count</h3>
                        <div class="value"><?php echo number_format($stats['total_households'] ?? 0); ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                        </div>
                <h3>Senior Citizens</h3>
                <div class="value"><?php echo number_format($stats['total_seniors'] ?? 0); ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <path d="M12 6v6l4 2"></path>
                            </svg>
                        </div>
                        <h3>PWD</h3>
                        <div class="value"><?php echo number_format($stats['total_pwd'] ?? 0); ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                        </div>
                        <h3>Solo Parents</h3>
                        <div class="value"><?php echo number_format($stats['total_solo_parents'] ?? 0); ?></div>
                    </div>
                    <div class="stat-card">
                        <div class="icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                <line x1="12" y1="2" x2="12" y2="22"></line>
                            </svg>
                        </div>
                        <h3>Indigent Families</h3>
                        <div class="value"><?php echo number_format($stats['total_indigent'] ?? 0); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Residents Age Distribution Section -->
        <div class="age-chart">
            <h2 class="section-title" style="margin-top: 0;">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="20" x2="12" y2="10"></line>
                        <line x1="18" y1="20" x2="18" y2="4"></line>
                        <line x1="6" y1="20" x2="6" y2="16"></line>
                    </svg>
                </span>
                Residents Age Distribution
            </h2>
            <div class="bar-chart-wrapper">
                <canvas id="ageBarChart"></canvas>
            </div>
        </div>

        <!-- ROW B: Document Requests Overview -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                </span>
                Document Requests Overview
            </h2>
            <p class="section-description">Overview of document request statistics and trends.</p>
            
            <div class="requests-overview-container">
                <!-- Left: Stats List -->
                <div class="requests-stats-list">
                    <a href="admin_monitoring_request.php" class="request-stat-item">
                        <div class="stat-label">Pending Document Requests:</div>
                        <div class="stat-value"><?php echo number_format($pending_requests); ?></div>
                    </a>
                    <a href="admin_monitoring_request.php" class="request-stat-item">
                        <div class="stat-label">Approved Requests (This Month):</div>
                        <div class="stat-value"><?php echo number_format($approved_this_month); ?></div>
                    </a>
                    <a href="admin_monitoring_request.php" class="request-stat-item">
                        <div class="stat-label">Rejected / Cancelled Requests:</div>
                        <div class="stat-value"><?php echo number_format($rejected_cancelled); ?></div>
                    </a>
                    <a href="admin_monitoring_request.php" class="request-stat-item">
                        <div class="stat-label">Most Requested Document Type:</div>
                        <div class="stat-value"><?php echo htmlspecialchars($most_requested_type); ?></div>
                    </a>
                </div>
                
                <!-- Right: Trend Chart -->
                <div class="requests-trend-chart">
                    <h3 class="trend-chart-title">Daily/Weekly Requests Trend</h3>
                    <div class="trend-chart-wrapper">
                        <canvas id="requestsTrendChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- ROW C: Barangay Clearance & Permit Monitoring -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                        <polyline points="10 9 9 9 8 9"></polyline>
                    </svg>
                </span>
                Barangay Clearance & Permit Monitoring
            </h2>
            <p class="section-description">Monitor pending, approved, and expiring permits and clearances.</p>
            
            <div class="permits-cards-grid">
                <div class="permit-card">
                    <div class="permit-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <div class="permit-card-content">
                        <div class="permit-card-label">Pending Permits:</div>
                        <div class="permit-card-value"><?php echo number_format($pending_permits); ?></div>
                    </div>
                </div>
                
                <div class="permit-card">
                    <div class="permit-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </div>
                    <div class="permit-card-content">
                        <div class="permit-card-label">Approved Permits Today:</div>
                        <div class="permit-card-value"><?php echo number_format($approved_permits_today); ?></div>
                    </div>
                </div>
                
                <div class="permit-card">
                    <div class="permit-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <div class="permit-card-content">
                        <div class="permit-card-label">Expiring Permits (Next 30 Days):</div>
                        <div class="permit-card-value"><?php echo number_format($expiring_permits_30days); ?></div>
                    </div>
                </div>
                
                <div class="permit-card">
                    <div class="permit-card-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <line x1="12" y1="20" x2="12" y2="10"></line>
                            <line x1="18" y1="20" x2="18" y2="4"></line>
                            <line x1="6" y1="20" x2="6" y2="16"></line>
                        </svg>
                    </div>
                    <div class="permit-card-content">
                        <div class="permit-card-label">Total Permits Issued This Month:</div>
                        <div class="permit-card-value"><?php echo number_format($total_permits_this_month); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Important Documents Status -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                        <line x1="16" y1="13" x2="8" y2="13"></line>
                        <line x1="16" y1="17" x2="8" y2="17"></line>
                    </svg>
                </span>
                Important Documents Status
            </h2>
            <p class="section-description">Overview of document status and expiring documents.</p>
            
            <div class="documents-status-card">
                <div class="documents-status-row">
                    <div class="documents-status-item">
                        <div class="documents-status-label">Expiring Documents (Next 30 Days):</div>
                        <div class="documents-status-value"><?php echo number_format($expiring_documents_30days); ?></div>
                    </div>
                    <div class="documents-status-item">
                        <div class="documents-status-label">Newly Issued Documents:</div>
                        <div class="documents-status-value"><?php echo number_format($newly_issued_documents); ?></div>
                    </div>
                </div>
                <div class="documents-status-row">
                    <div class="documents-status-item">
                        <div class="documents-status-label">Document List:</div>
                        <div class="documents-status-value"><?php echo number_format($total_document_list); ?></div>
                    </div>
                    <div class="documents-status-item">
                        <div class="documents-status-label">Rejected:</div>
                        <div class="documents-status-value"><?php echo number_format($rejected_documents); ?></div>
                    </div>
                </div>
                <div class="documents-status-breakdown">
                    <div class="breakdown-item">
                        <span class="breakdown-label">Pending:</span>
                        <span class="breakdown-value"><?php echo number_format($pending_documents); ?></span>
                    </div>
                    <div class="breakdown-item">
                        <span class="breakdown-label">Processing:</span>
                        <span class="breakdown-value"><?php echo number_format($processing_documents); ?></span>
                    </div>
                    <div class="breakdown-item">
                        <span class="breakdown-label">Completed:</span>
                        <span class="breakdown-value"><?php echo number_format($completed_documents); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Calendar & Upcoming Events -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                </span>
                Calendar & Upcoming Events
            </h2>
            <p class="section-description">View upcoming events and calendar highlights.</p>
            
            <div class="calendar-events-container">
                <!-- Left: Mini Calendar -->
                <div class="calendar-section">
                    <h3 class="calendar-section-title">Mini Calendar</h3>
                    <div class="mini-calendar">
                        <div class="calendar-header">
                            <span class="calendar-month-year"><?php echo date('F Y', $first_day); ?></span>
                        </div>
                        <div class="calendar-weekdays">
                            <div class="calendar-weekday">Mon</div>
                            <div class="calendar-weekday">Tue</div>
                            <div class="calendar-weekday">Wed</div>
                            <div class="calendar-weekday">Thu</div>
                            <div class="calendar-weekday">Fri</div>
                            <div class="calendar-weekday">Sat</div>
                            <div class="calendar-weekday">Sun</div>
                        </div>
                        <div class="calendar-days">
            <?php
                            // Empty cells for days before month starts
                            for ($i = 1; $i < $day_of_week; $i++) {
                                echo '<div class="calendar-day empty"></div>';
                            }
                            
                            // Days of the month
                            for ($day = 1; $day <= $days_in_month; $day++) {
                                $has_event = isset($current_month_events[$day]);
                                $is_today = ($day == date('j') && $current_month == date('n') && $current_year == date('Y'));
                                $classes = 'calendar-day';
                                if ($is_today) $classes .= ' today';
                                if ($has_event) $classes .= ' has-event';
                                
                                echo '<div class="' . $classes . '">';
                                echo '<span class="day-number">' . $day . '</span>';
                                if ($has_event) {
                                    echo '<span class="event-dot"></span>';
                                }
                                echo '</div>';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="highlighted-dates-info">
                        <div class="info-item">
                            <span class="info-dot event"></span>
                            <span>Highlighted Event Dates</span>
                        </div>
                    </div>
                </div>
                
                <!-- Right: Upcoming Events List -->
                <div class="events-section">
                    <h3 class="events-section-title">Upcoming Events List</h3>
                    <div class="category-filters">
                        <button class="filter-btn active" data-category="all">All</button>
                        <?php foreach ($event_categories as $category): ?>
                            <button class="filter-btn" data-category="<?php echo strtolower($category); ?>">
                                <?php echo $category; ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                    <div class="events-list">
                        <?php if (empty($upcoming_events)): ?>
                            <div class="no-events">No upcoming events</div>
                        <?php else: ?>
                            <?php foreach (array_slice($upcoming_events, 0, 10) as $event): ?>
                                <div class="event-item" data-category="<?php echo strtolower($event['type'] ?? 'community'); ?>">
                                    <div class="event-title"><?php echo htmlspecialchars($event['title'] ?? 'Untitled Event'); ?></div>
                                    <div class="event-datetime">
                                        <?php
                                        $start_date = $event['start_date'] ?? '';
                                        $start_time = $event['start_time'] ?? '';
                                        if ($start_date) {
                                            echo date('M d, Y', strtotime($start_date));
                                            if ($start_time) {
                                                echo ' — ' . date('h:i A', strtotime($start_time));
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Barangay Projects Monitoring -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                </span>
                Barangay Projects Monitoring
            </h2>
            <p class="section-description">Track ongoing, upcoming, and completed projects.</p>
            
            <div class="projects-grid">
                <!-- Ongoing Projects -->
                <div class="projects-column">
                    <h3 class="projects-column-title">Ongoing Projects</h3>
                    <div class="projects-list">
                        <?php if (empty($ongoing_projects)): ?>
                            <div class="no-projects">No ongoing projects</div>
                        <?php else: ?>
                            <?php foreach (array_slice($ongoing_projects, 0, 5) as $project): ?>
                                <div class="project-item">
                                    <div class="project-name"><?php echo htmlspecialchars($project['title'] ?? 'Untitled Project'); ?></div>
                                    <div class="project-progress">
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?php echo min(100, max(0, $project['progress'] ?? 0)); ?>%"></div>
                                        </div>
                                        <span class="progress-text"><?php echo number_format($project['progress'] ?? 0); ?>%</span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Upcoming Projects -->
                <div class="projects-column">
                    <h3 class="projects-column-title">Upcoming Projects</h3>
                    <div class="projects-list">
                        <?php if (empty($upcoming_projects)): ?>
                            <div class="no-projects">No upcoming projects</div>
                        <?php else: ?>
                            <?php foreach (array_slice($upcoming_projects, 0, 5) as $project): ?>
                                <div class="project-item">
                                    <div class="project-name"><?php echo htmlspecialchars($project['title'] ?? 'Untitled Project'); ?></div>
                                    <div class="project-date">
                                        Start Date: <?php 
                                        $start_date = $project['start_date'] ?? '';
                                        echo $start_date ? date('M d, Y', strtotime($start_date)) : 'TBD';
                                        ?>
            </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Completed Projects -->
                <div class="projects-column">
                    <h3 class="projects-column-title">Completed Projects</h3>
                    <div class="projects-list">
                        <?php if (empty($completed_projects)): ?>
                            <div class="no-projects">No completed projects</div>
                        <?php else: ?>
                            <?php foreach (array_slice($completed_projects, 0, 5) as $project): ?>
                                <div class="project-item">
                                    <div class="project-name"><?php echo htmlspecialchars($project['title'] ?? 'Untitled Project'); ?></div>
                                    <div class="project-date">
                                        Completion Date: <?php 
                                        $completion_date = $project['completion_date'] ?? $project['target_date'] ?? '';
                                        echo $completion_date ? date('M d, Y', strtotime($completion_date)) : 'N/A';
                                        ?>
            </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Service Performance Indicators (KPIs) -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="20" x2="12" y2="10"></line>
                        <line x1="18" y1="20" x2="18" y2="4"></line>
                        <line x1="6" y1="20" x2="6" y2="16"></line>
                    </svg>
                </span>
                Service Performance Indicators (KPIs)
            </h2>
            <p class="section-description">Key performance metrics for barangay services.</p>
            
            <div class="kpi-cards-row">
                <div class="kpi-card">
                    <div class="kpi-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <div class="kpi-content">
                        <div class="kpi-label">Average Processing Time</div>
                        <div class="kpi-value">
                            <?php 
                            if ($average_processing_time > 0) {
                                if ($average_processing_time < 1) {
                                    echo number_format($average_processing_time * 60, 1) . ' min';
                                } elseif ($average_processing_time < 24) {
                                    echo number_format($average_processing_time, 1) . ' hrs';
                                } else {
                                    echo number_format($average_processing_time / 24, 1) . ' days';
                                }
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <div class="kpi-card">
                    <div class="kpi-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                    </div>
                    <div class="kpi-content">
                        <div class="kpi-label">% Same-Day Completion</div>
                        <div class="kpi-value"><?php echo number_format($same_day_completion_percentage, 1); ?>%</div>
                    </div>
                </div>
                
                <div class="kpi-card">
                    <div class="kpi-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                    </div>
                    <div class="kpi-content">
                        <div class="kpi-label">Peak Request Hour</div>
                        <div class="kpi-value"><?php echo htmlspecialchars($peak_request_hour); ?></div>
                    </div>
                </div>
                
                <div class="kpi-card">
                    <div class="kpi-icon">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="3" width="7" height="7"></rect>
                            <rect x="14" y="3" width="7" height="7"></rect>
                            <rect x="14" y="14" width="7" height="7"></rect>
                            <rect x="3" y="14" width="7" height="7"></rect>
                        </svg>
                    </div>
                    <div class="kpi-content">
                        <div class="kpi-label">Most Active System Module</div>
                        <div class="kpi-value"><?php echo htmlspecialchars($most_active_module); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Feedback & Complaints Overview -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                        <path d="M13 8H7"></path>
                        <path d="M17 12H7"></path>
                    </svg>
                </span>
                Feedback & Complaints Overview
            </h2>
            <p class="section-description">Monitor and track resident feedback and complaints.</p>
            
            <div class="complaints-overview-container">
                <!-- Summary Stats -->
                <div class="complaints-summary">
                    <div class="complaint-stat-card">
                        <div class="complaint-stat-label">New Complaints:</div>
                        <div class="complaint-stat-value"><?php echo number_format($new_complaints); ?></div>
                    </div>
                    <div class="complaint-stat-card">
                        <div class="complaint-stat-label">Resolved Complaints:</div>
                        <div class="complaint-stat-value"><?php echo number_format($resolved_complaints); ?></div>
                    </div>
                    <div class="complaint-stat-card">
                        <div class="complaint-stat-label">Pending Complaints:</div>
                        <div class="complaint-stat-value"><?php echo number_format($pending_complaints); ?></div>
                    </div>
                </div>
                
                <!-- Recent Complaints List -->
                <div class="recent-complaints-section">
                    <h3 class="recent-complaints-title">Recent Complaints:</h3>
                    <div class="complaints-list">
                        <?php if (empty($recent_complaints)): ?>
                            <div class="no-complaints">No complaints found</div>
                        <?php else: ?>
                            <?php foreach ($recent_complaints as $complaint): ?>
                                <div class="complaint-item">
                                    <div class="complaint-id"><?php echo htmlspecialchars($complaint['id']); ?></div>
                                    <div class="complaint-status <?php echo strtolower($complaint['status']); ?>">
                                        <?php echo htmlspecialchars($complaint['status']); ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Incident & Safety Monitoring -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                        <path d="M9 12l2 2 4-4"></path>
                    </svg>
                </span>
                Incident & Safety Monitoring
            </h2>
            <p class="section-description">Track and monitor barangay incidents and safety reports.</p>
            
            <div class="incident-monitoring-container">
                <!-- Stats Section -->
                <div class="incident-stats-grid">
                    <div class="incident-stat-card">
                        <div class="incident-stat-label">Total Incidents:</div>
                        <div class="incident-stat-value"><?php echo number_format($total_incidents); ?></div>
            </div>
                    <div class="incident-stat-card">
                        <div class="incident-stat-label">Resolved:</div>
                        <div class="incident-stat-value"><?php echo number_format($resolved_incidents); ?></div>
            </div>
                    <div class="incident-stat-card">
                        <div class="incident-stat-label">Pending Investigations:</div>
                        <div class="incident-stat-value"><?php echo number_format($pending_investigations); ?></div>
            </div>
                    <div class="incident-stat-card">
                        <div class="incident-stat-label">Critical Incidents:</div>
                        <div class="incident-stat-value"><?php echo number_format($critical_incidents); ?></div>
        </div>
    </div>
                
                <!-- Categories Section -->
                <div class="incident-categories-section">
                    <h3 class="incident-section-title">Incident Categories:</h3>
                    <div class="incident-categories-grid">
                        <div class="incident-category-item">
                            <div class="category-label">Domestic:</div>
                            <div class="category-value"><?php echo number_format($incident_categories['Domestic']); ?></div>
                        </div>
                        <div class="incident-category-item">
                            <div class="category-label">Theft:</div>
                            <div class="category-value"><?php echo number_format($incident_categories['Theft']); ?></div>
                        </div>
                        <div class="incident-category-item">
                            <div class="category-label">VAWC:</div>
                            <div class="category-value"><?php echo number_format($incident_categories['VAWC']); ?></div>
                        </div>
                        <div class="incident-category-item">
                            <div class="category-label">Traffic:</div>
                            <div class="category-value"><?php echo number_format($incident_categories['Traffic']); ?></div>
                        </div>
                        <div class="incident-category-item">
                            <div class="category-label">Others:</div>
                            <div class="category-value"><?php echo number_format($incident_categories['Others']); ?></div>
                        </div>
                    </div>
                </div>
                
                <!-- Heatmap Section -->
                <div class="incident-heatmap-section">
                    <h3 class="incident-section-title">Incident Heatmap:</h3>
                    <div class="heatmap-info">
                        <div class="heatmap-item">
                            <span class="heatmap-label">Peak Days/Hours:</span>
                            <span class="heatmap-value">
                                <?php 
                                if ($peak_day !== 'N/A' && $peak_hour !== 'N/A') {
                                    echo htmlspecialchars($peak_day) . ' — ' . htmlspecialchars($peak_hour);
                                } elseif ($peak_day !== 'N/A') {
                                    echo htmlspecialchars($peak_day);
                                } elseif ($peak_hour !== 'N/A') {
                                    echo htmlspecialchars($peak_hour);
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                    <div class="heatmap-visual">
                        <div class="heatmap-days">
                            <div class="heatmap-day-label">Days:</div>
                            <div class="heatmap-bars">
                                <?php
                                $days_order = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                                foreach ($days_order as $day) {
                                    $count = $incident_days[$day] ?? 0;
                                    $max_count = !empty($incident_days) ? max($incident_days) : 1;
                                    $height = $max_count > 0 ? ($count / $max_count) * 100 : 0;
                                    $opacity = $count > 0 ? max(0.3, $count / max($max_count, 1)) : 0.1;
                                    ?>
                                    <div class="heatmap-bar-item">
                                        <div class="heatmap-bar" style="height: <?php echo $height; ?>%; background: rgba(135, 169, 107, <?php echo $opacity; ?>);"></div>
                                        <div class="heatmap-bar-label"><?php echo $day; ?></div>
                                        <div class="heatmap-bar-value"><?php echo $count; ?></div>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                        <div class="heatmap-hours">
                            <div class="heatmap-hour-label">Hours:</div>
                            <div class="heatmap-hours-grid">
                                <?php
                                for ($h = 0; $h < 24; $h++) {
                                    $count = $incident_hours[$h] ?? 0;
                                    $max_count = !empty($incident_hours) ? max($incident_hours) : 1;
                                    $intensity = $max_count > 0 ? ($count / $max_count) : 0;
                                    $bg_color = $intensity > 0 ? "rgba(135, 169, 107, " . max(0.2, $intensity) . ")" : "rgba(229, 231, 235, 0.3)";
                                    ?>
                                    <div class="heatmap-hour-cell" style="background: <?php echo $bg_color; ?>;" title="<?php echo date('g A', mktime($h, 0, 0)); ?>: <?php echo $count; ?> incidents">
                                        <span class="hour-number"><?php echo $h; ?></span>
                                    </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Emergency & Safety Panel -->
        <div class="row-container" style="margin-top: 20px;">
            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px;">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <h2 class="section-title" style="margin: 0;">
                        <span class="section-title-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                                <path d="M9 12l2 2 4-4"></path>
                            </svg>
                        </span>
                        Emergency & Safety Panel
                    </h2>
                </div>
                <button class="emergency-lock-btn" id="emergencyLockBtn" onclick="toggleEmergencyLock()" title="Lock/Unlock Editing">
                    <svg id="lockIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                </button>
            </div>
            <p class="section-description">Emergency contacts and live safety information.</p>
            
            <div class="emergency-panel-container" id="emergencyPanelContainer">
                <!-- Left: Emergency Contacts -->
                <div class="emergency-contacts-section">
                    <h3 class="emergency-section-title">Emergency Contacts</h3>
                    <div class="emergency-contacts-list">
                        <div class="emergency-contact-item">
                            <div class="contact-label">PNP:</div>
                            <div class="contact-value editable" contenteditable="true" data-field="PNP" data-type="contact">
                                <?php echo htmlspecialchars($pnp_contact ?: 'Not set'); ?>
                            </div>
                        </div>
                        <div class="emergency-contact-item">
                            <div class="contact-label">BFP:</div>
                            <div class="contact-value editable" contenteditable="true" data-field="BFP" data-type="contact">
                                <?php echo htmlspecialchars($bfp_contact ?: 'Not set'); ?>
                            </div>
                        </div>
                        <div class="emergency-contact-item">
                            <div class="contact-label">Health Center:</div>
                            <div class="contact-value editable" contenteditable="true" data-field="Health Center" data-type="contact">
                                <?php echo htmlspecialchars($health_center_contact ?: 'Not set'); ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Right: Live Emergency Info -->
                <div class="live-emergency-section">
                    <h3 class="emergency-section-title">Live Emergency Info</h3>
                    <div class="live-emergency-list">
                        <div class="emergency-info-item">
                            <div class="info-label">Weather (optional):</div>
                            <div class="info-value editable" contenteditable="true" data-field="weather" data-type="live_info">
                                <?php echo htmlspecialchars($weather ?: 'Not set'); ?>
                            </div>
                        </div>
                        <div class="emergency-info-item">
                            <div class="info-label">Alert Status:</div>
                            <div class="info-value editable" contenteditable="true" data-field="alert_status" data-type="live_info">
                                <?php echo htmlspecialchars($alert_status); ?>
                            </div>
                        </div>
                        <div class="emergency-info-item">
                            <div class="info-label">Active Emergency Cases:</div>
                            <div class="info-value editable" contenteditable="true" data-field="active_emergency_cases" data-type="live_info">
                                <?php echo number_format($active_emergency_cases); ?>
                            </div>
                        </div>
                        <div class="emergency-info-item">
                            <div class="info-label">List of Cases:</div>
                            <div class="info-value editable" contenteditable="true" data-field="emergency_cases_list" data-type="live_info">
                                <?php 
                                if (!empty($emergency_cases_list) && is_array($emergency_cases_list)) {
                                    echo htmlspecialchars(implode(', ', $emergency_cases_list));
                                } else {
                                    echo 'No active cases';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="emergency-info-item">
                            <div class="info-label">Active Evacuation Centers:</div>
                            <div class="info-value editable" contenteditable="true" data-field="active_evacuation_centers" data-type="live_info">
                                <?php echo number_format($active_evacuation_centers); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php if ($admin_role === 'super_admin'): ?>
        <!-- Staff / User Activity & Login (Super Admin) -->
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </span>
                Staff / User Activity & Login
            </h2>
            <p class="section-description">Monitor staff activity, login statistics, and recent system activities.</p>
            
            <div class="staff-activity-container">
                <div class="staff-activity-stats">
                    <div class="staff-stat-card">
                        <div class="staff-stat-label">Active Users Today:</div>
                        <div class="staff-stat-value"><?php echo number_format($active_users_today); ?></div>
                    </div>
                    <div class="staff-stat-card">
                        <div class="staff-stat-label">Active Residents Today:</div>
                        <div class="staff-stat-value"><?php echo number_format($active_residents_today); ?></div>
                    </div>
                    <div class="staff-stat-card">
                        <div class="staff-stat-label">Failed Login Attempts (24h):</div>
                        <div class="staff-stat-value"><?php echo number_format($failed_login_attempts); ?></div>
                    </div>
                </div>
                
                <!-- Recent Activity Logs -->
                <div class="activity-logs-container">
                    <h3 style="font-size: 18px; font-weight: 700; color: #1f2937; margin-bottom: 16px; padding: 20px 20px 0 20px; display: flex; align-items: center; gap: 8px;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 20px; height: 20px; color: #4b5563;">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                        Recent Activity Logs
                    </h3>
                    <table class="activity-logs-table">
                        <thead>
                            <tr>
                                <th>Log Entry</th>
                                <th>Date/Time</th>
                                <th>Performed By</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_activity_logs)): ?>
                                <tr>
                                    <td colspan="4" class="no-logs">No activity logs available</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach (array_slice($recent_activity_logs, 0, 20) as $log): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($log['description'] ?? 'N/A'); ?></td>
                                        <td><?php echo $log['created_at'] ? date('M d, Y H:i', strtotime($log['created_at'])) : 'N/A'; ?></td>
                                        <td>
                                            <?php 
                                            $performer_name = $log['performer_name'] ?? $log['full_name'] ?? $log['admin_name'] ?? 'System';
                                            $performer_type = $log['performer_type'] ?? 'Admin';
                                            echo htmlspecialchars($performer_name);
                                            if ($performer_type === 'Resident') {
                                                echo ' <span style="color: #6b7280; font-size: 0.9em;">(Resident)</span>';
                                            } elseif ($performer_type === 'Admin') {
                                                echo ' <span style="color: #6b7280; font-size: 0.9em;">(Admin)</span>';
                                            }
                                            ?>
                                        </td>
                                        <td><span class="action-badge"><?php echo htmlspecialchars($log['action_type'] ?? 'N/A'); ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- System Health (Super Admin Only) -->
        <?php if ($admin_role === 'super_admin'): ?>
        <div class="row-container" style="margin-top: 20px;">
            <h2 class="section-title">
                <span class="section-title-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                </span>
                System Health
            </h2>
            <p class="section-description">Monitor system integrity and performance metrics.</p>
            
            <div class="system-health-container">
                <div class="system-health-grid">
                    <div class="health-card">
                        <div class="health-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
                                <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
                                <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
                            </svg>
                        </div>
                        <div class="health-content">
                            <div class="health-label">Database Size:</div>
                            <div class="health-value"><?php echo htmlspecialchars($database_size); ?></div>
                        </div>
                    </div>
                    <div class="health-card">
                        <div class="health-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                        </div>
                        <div class="health-content">
                            <div class="health-label">API Status:</div>
                            <div class="health-value status-active"><?php echo htmlspecialchars($api_status); ?></div>
                        </div>
                    </div>
                    <div class="health-card">
                        <div class="health-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                                <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                                <line x1="12" y1="22.08" x2="12" y2="12"></line>
                            </svg>
                        </div>
                        <div class="health-content">
                            <div class="health-label">Last Backup:</div>
                            <div class="health-value"><?php echo htmlspecialchars($last_backup); ?></div>
                        </div>
                    </div>
                    <div class="health-card">
                        <div class="health-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                <circle cx="9" cy="7" r="4"></circle>
                                <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                            </svg>
                        </div>
                        <div class="health-content">
                            <div class="health-label">User Activity (24h):</div>
                            <div class="health-value"><?php echo number_format($user_activity_24h); ?></div>
                        </div>
                    </div>
                    <div class="health-card">
                        <div class="health-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                                <polyline points="7.5 4.21 12 6.81 16.5 4.21"></polyline>
                                <polyline points="7.5 19.79 7.5 14.6 3 12"></polyline>
                                <polyline points="21 12 16.5 14.6 16.5 19.79"></polyline>
                                <polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline>
                                <line x1="12" y1="22.08" x2="12" y2="12"></line>
                            </svg>
                        </div>
                        <div class="health-content">
                            <div class="health-label">Storage Usage:</div>
                            <div class="health-value"><?php echo htmlspecialchars($storage_usage); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Footer / Dashboard Footnote -->
        <div class="dashboard-footer" style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e5e7eb;">
            <div class="footer-content">
                <div class="footer-item">
                    <span class="footer-label">Contact Support:</span>
                    <span class="footer-value">barangay.sanvicenteii@silang.gov.ph</span>
                </div>
                <div class="footer-item">
                    <span class="footer-label">Last Dashboard Refresh:</span>
                    <span class="footer-value" id="dashboardRefreshTime"><?php echo htmlspecialchars($dashboard_refresh_time); ?></span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Pie Chart for Demographics - Fix blurriness
        const pieCanvas = document.getElementById('demographicsPieChart');
        const dpr = window.devicePixelRatio || 1;
        
        const pieData = {
            labels: [
                'Active Residents',
                'Senior Citizens',
                'PWD',
                'Solo Parents',
                'Indigent Families'
            ],
            datasets: [{
                data: [
                    <?php echo $stats['total_active'] ?? 0; ?>,
                    <?php echo $stats['total_seniors'] ?? 0; ?>,
                    <?php echo $stats['total_pwd'] ?? 0; ?>,
                    <?php echo $stats['total_solo_parents'] ?? 0; ?>,
                    <?php echo $stats['total_indigent'] ?? 0; ?>
                ],
                backgroundColor: [
                    'rgba(135, 169, 107, 0.7)',  // Sage green
                    'rgba(156, 163, 175, 0.7)',  // Neutral gray
                    'rgba(245, 245, 220, 0.9)',  // Pale yellow/beige
                    'rgba(107, 114, 128, 0.7)',  // Cool gray
                    'rgba(147, 197, 253, 0.6)'  // Light blue-gray
                ],
                borderColor: [
                    'rgba(135, 169, 107, 0.9)',  // Sage green border
                    'rgba(156, 163, 175, 0.9)',
                    'rgba(245, 245, 220, 1)',
                    'rgba(107, 114, 128, 0.9)',
                    'rgba(147, 197, 253, 0.8)'
                ],
                borderWidth: 1
            }]
        };

        new Chart(pieCanvas, {
            type: 'pie',
            data: pieData,
            options: {
                responsive: true,
                maintainAspectRatio: true,
                devicePixelRatio: dpr,
                animation: {
                    animateRotate: true,
                    animateScale: false
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 12,
                            font: {
                                size: 11,
                                family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif"
                            },
                            color: '#4b5563',
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(31, 41, 55, 0.95)',
                        padding: 10,
                        titleFont: {
                            size: 12,
                            weight: '500'
                        },
                        bodyFont: {
                            size: 12
                        },
                        borderColor: '#e5e7eb',
                        borderWidth: 1
                    }
                }
            }
        });

        // Bar Chart for Age Distribution - Fix blurriness
        const barCanvas = document.getElementById('ageBarChart');
        
        const barData = {
            labels: ['0-17', '18-35', '36-60', '60+'],
            datasets: [{
                label: 'Number of Residents',
                data: [
                    <?php echo $age_stats['age_0_17'] ?? 0; ?>,
                    <?php echo $age_stats['age_18_35'] ?? 0; ?>,
                    <?php echo $age_stats['age_36_60'] ?? 0; ?>,
                    <?php echo $age_stats['age_60_plus'] ?? 0; ?>
                ],
                backgroundColor: [
                    'rgba(245, 245, 220, 0.8)',  // Pale yellow/beige
                    'rgba(135, 169, 107, 0.7)',  // Sage green
                    'rgba(156, 163, 175, 0.7)',  // Neutral gray
                    'rgba(107, 114, 128, 0.7)'  // Cool gray
                ],
                borderColor: [
                    'rgba(245, 245, 220, 1)',
                    'rgba(135, 169, 107, 0.9)',
                    'rgba(156, 163, 175, 0.9)',
                    'rgba(107, 114, 128, 0.9)'
                ],
                borderWidth: 1,
                borderRadius: 4,
                barThickness: 40  // Make bars thinner
            }]
        };

        new Chart(barCanvas, {
            type: 'bar',
            data: barData,
            options: {
                responsive: true,
                maintainAspectRatio: true,
                devicePixelRatio: dpr,
                animation: {
                    animateRotate: false,
                    animateScale: false
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(31, 41, 55, 0.95)',
                        padding: 10,
                        titleFont: {
                            size: 12,
                            weight: '500'
                        },
                        bodyFont: {
                            size: 12
                        },
                        borderColor: '#e5e7eb',
                        borderWidth: 1
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            font: {
                                size: 11,
                                family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif"
                            },
                            color: '#6b7280'
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.04)',
                            drawBorder: false
                        },
                        border: {
                            display: false
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 11,
                                family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif"
                            },
                            color: '#6b7280'
                        },
                        grid: {
                            display: false
                        },
                        border: {
                            display: false
                        }
                    }
                }
            }
        });

        // Trend Chart for Document Requests
        const trendCanvas = document.getElementById('requestsTrendChart');
        if (trendCanvas) {
            const trendData = {
                labels: [<?php 
                    $labels = [];
                    $values = [];
                    foreach ($daily_trend as $date => $data) {
                        $labels[] = "'" . $data['label'] . "'";
                        $values[] = $data['count'];
                    }
                    echo implode(', ', $labels);
                ?>],
                datasets: [{
                    label: 'Requests',
                    data: [<?php echo implode(', ', $values); ?>],
                    backgroundColor: 'rgba(135, 169, 107, 0.2)',
                    borderColor: 'rgba(135, 169, 107, 0.8)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: 'rgba(135, 169, 107, 1)',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            };

            new Chart(trendCanvas, {
                type: 'line',
                data: trendData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            backgroundColor: 'rgba(31, 41, 55, 0.95)',
                            padding: 10,
                            titleFont: {
                                size: 12,
                                weight: '500'
                            },
                            bodyFont: {
                                size: 12
                            },
                            borderColor: '#e5e7eb',
                            borderWidth: 1,
                            callbacks: {
                                label: function(context) {
                                    return 'Requests: ' + context.parsed.y;
                                }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1,
                                font: {
                                    size: 11,
                                    family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif"
                                },
                                color: '#6b7280'
                            },
                            grid: {
                                color: 'rgba(0, 0, 0, 0.04)',
                                drawBorder: false
                            },
                            border: {
                                display: false
                            }
                        },
                        x: {
                            ticks: {
                                font: {
                                    size: 11,
                                    family: "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif"
                                },
                                color: '#6b7280'
                            },
                            grid: {
                                display: false
                            },
                            border: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        // Category Filter Functionality
        document.addEventListener('DOMContentLoaded', function() {
            const filterButtons = document.querySelectorAll('.filter-btn');
            const eventItems = document.querySelectorAll('.event-item');
            
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const category = this.getAttribute('data-category');
                    
                    // Toggle active state
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Filter events
                    if (category === 'all') {
                        eventItems.forEach(item => item.classList.remove('hidden'));
                    } else {
                        eventItems.forEach(item => {
                            const itemCategory = item.getAttribute('data-category');
                            if (itemCategory === category) {
                                item.classList.remove('hidden');
                            } else {
                                item.classList.add('hidden');
                            }
                        });
                    }
                });
            });

            // Emergency Panel Editable Fields
            const editableFields = document.querySelectorAll('.editable');
            
            editableFields.forEach(field => {
                let originalValue = field.textContent.trim();
                
                field.addEventListener('blur', function() {
                    // Don't save if locked
                    if (this.classList.contains('locked')) {
                        return;
                    }
                    
                    const newValue = this.textContent.trim();
                    const fieldName = this.getAttribute('data-field');
                    const dataType = this.getAttribute('data-type');
                    
                    // Only save if value changed
                    if (newValue !== originalValue) {
                        // Prepare data
                        const formData = new FormData();
                        formData.append('action', 'update_emergency');
                        
                        if (dataType === 'contact') {
                            formData.append('contacts[' + fieldName + ']', newValue);
                        } else if (dataType === 'live_info') {
                            // Handle special cases
                            if (fieldName === 'active_emergency_cases' || fieldName === 'active_evacuation_centers') {
                                const numValue = parseInt(newValue.replace(/[^0-9]/g, '')) || 0;
                                formData.append('live_info[' + fieldName + ']', numValue);
                            } else if (fieldName === 'emergency_cases_list') {
                                // Split by comma and trim, then send as JSON string
                                const cases = newValue.split(',').map(c => c.trim()).filter(c => c);
                                formData.append('live_info[' + fieldName + ']', JSON.stringify(cases));
                            } else {
                                formData.append('live_info[' + fieldName + ']', newValue);
                            }
                        }
                        
                        // Save via AJAX
                        fetch(window.location.href, {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.text())
                        .then(data => {
                            // Update original value
                            originalValue = newValue;
                            
                            // Show success indicator
                            field.style.borderBottomColor = '#16a34a';
                            setTimeout(() => {
                                field.style.borderBottomColor = 'transparent';
                            }, 2000);
                        })
                        .catch(error => {
                            console.error('Error saving:', error);
                            // Revert on error
                            field.textContent = originalValue;
                            field.style.borderBottomColor = '#dc2626';
                            setTimeout(() => {
                                field.style.borderBottomColor = 'transparent';
                            }, 2000);
                        });
                    }
                });
                
                field.addEventListener('keydown', function(e) {
                    // Don't allow editing if locked
                    if (this.classList.contains('locked')) {
                        e.preventDefault();
                        return;
                    }
                    
                    // Save on Enter (but don't create new line)
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        this.blur();
                    }
                    // Cancel on Escape
                    if (e.key === 'Escape') {
                        this.textContent = originalValue;
                        this.blur();
                    }
                });
                
                // Prevent editing on click if locked
                field.addEventListener('click', function(e) {
                    if (this.classList.contains('locked')) {
                        e.preventDefault();
                        return false;
                    }
                });
            });
        });

        // Update Dashboard Refresh Time
        function updateRefreshTime() {
            const now = new Date();
            const options = { 
                month: 'short', 
                day: 'numeric', 
                year: 'numeric', 
                hour: '2-digit', 
                minute: '2-digit',
                second: '2-digit'
            };
            const timeString = now.toLocaleDateString('en-US', options);
            const refreshElement = document.getElementById('dashboardRefreshTime');
            if (refreshElement) {
                refreshElement.textContent = timeString;
            }
        }
        
        // Update refresh time every minute
        setInterval(updateRefreshTime, 60000);

        // Emergency Panel Lock Toggle Function
        function toggleEmergencyLock() {
            const isLocked = localStorage.getItem('emergencyPanelLocked') === 'true';
            const newLockState = !isLocked;
            localStorage.setItem('emergencyPanelLocked', newLockState.toString());
            updateEmergencyLockState(newLockState);
        }

        function updateEmergencyLockState(isLocked) {
            const lockBtn = document.getElementById('emergencyLockBtn');
            const lockIcon = document.getElementById('lockIcon');
            const editableFields = document.querySelectorAll('.editable');
            
            if (isLocked) {
                // Lock all fields
                lockBtn.classList.add('locked');
                lockBtn.title = 'Unlock to enable editing';
                lockIcon.innerHTML = '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path>';
                
                editableFields.forEach(field => {
                    field.setAttribute('contenteditable', 'false');
                    field.classList.add('locked');
                });
            } else {
                // Unlock all fields
                lockBtn.classList.remove('locked');
                lockBtn.title = 'Lock to prevent accidental editing';
                lockIcon.innerHTML = '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 5-5 4 4 0 0 1 4 4v4"></path><line x1="12" y1="16" x2="12.01" y2="16"></line>';
                
                editableFields.forEach(field => {
                    field.setAttribute('contenteditable', 'true');
                    field.classList.remove('locked');
                });
            }
        }
    </script>
</body>
</html>
