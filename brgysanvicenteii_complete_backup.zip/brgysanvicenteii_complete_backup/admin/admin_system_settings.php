<?php
// admin/admin_system_settings.php - Super Admin Only
session_start();
require '../config.php';
require 'role_helper.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';

if ($admin_role !== 'super_admin') {
    $_SESSION['error'] = 'Access denied. Only Super Admins can access system settings.';
    header('Location: admin_dashboard.php');
    exit;
}

$success = $_SESSION['success'] ?? '';
$error = $_SESSION['error'] ?? '';
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Settings - Barangay San Vicente II</title>
    <link rel="stylesheet" href="css/admin_dashboard.css">
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">⚙️ System Settings</h1>
        
        <?php if ($error): ?>
            <div style="background: #fee; color: #c33; padding: 15px; border-radius: 8px; margin: 20px 0;"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div style="background: #efe; color: #3c3; padding: 15px; border-radius: 8px; margin: 20px 0;"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <div class="content-card" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-top: 30px;">
            <h2 style="color: #1a5f3f; margin-bottom: 20px;">🔧 Configuration</h2>
            
            <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; margin-bottom: 15px;">
                <h3 style="color: #2d7a52; margin-bottom: 10px;">Barangay Information</h3>
                <p style="color: #666; margin: 0;">Barangay San Vicente II, Silang, Cavite</p>
            </div>
            
            <div style="padding: 20px; background: #f8f9fa; border-radius: 8px; margin-bottom: 15px;">
                <h3 style="color: #2d7a52; margin-bottom: 10px;">Admin Limits</h3>
                <p style="color: #666; margin: 0;">Maximum 3 admins (1 Super Admin + 2 Regular Admins)</p>
            </div>
        </div>
    </div>
</body>
</html>

