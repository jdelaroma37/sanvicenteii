<?php
// admin/admin_help.php
session_start();
require '../config.php';
require 'role_helper.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help & Guide - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar CSS - Same as dashboard */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
        }
        .content-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            transition: all 0.2s ease;
        }
        .content-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .content-card h2 {
            color: #2c3e2d;
            margin-bottom: 20px;
            font-size: 26px;
            font-weight: 800;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .content-card h2 svg {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .content-card h3 {
            color: #2c3e2d;
            margin-top: 25px;
            margin-bottom: 15px;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .content-card h3 svg {
            width: 18px;
            height: 18px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .content-card p {
            color: #6b7280;
            line-height: 1.8;
            margin-bottom: 15px;
            font-size: 16px;
            font-weight: 500;
        }
        .content-card ul {
            margin-left: 25px;
            margin-bottom: 20px;
        }
        .content-card li {
            color: #6b7280;
            line-height: 1.8;
            margin-bottom: 10px;
            font-size: 16px;
            font-weight: 500;
        }
        .content-card strong {
            color: #2c3e2d;
            font-weight: 700;
        }
        .help-section {
            margin-bottom: 30px;
            padding-bottom: 25px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .help-section:last-child {
            border-bottom: none;
        }
        .faq-item {
            margin-bottom: 20px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
        }
        .faq-item:hover {
            border-color: #87A96B;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .faq-question {
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 8px;
            font-size: 18px;
        }
        .faq-answer {
            color: #6b7280;
            line-height: 1.7;
            font-size: 16px;
            font-weight: 500;
        }
        .info-box {
            padding: 20px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .info-box p {
            margin: 0;
            color: #6b7280;
            line-height: 1.6;
            font-size: 16px;
            font-weight: 500;
        }
        .tip-box {
            padding: 20px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .tip-box p {
            margin: 0;
            color: #6b7280;
            line-height: 1.6;
            font-size: 16px;
            font-weight: 500;
        }
        .tip-box strong {
            color: #2c3e2d;
            font-weight: 700;
        }
        .contact-box {
            padding: 20px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .contact-box p {
            margin: 5px 0;
            color: #6b7280;
            line-height: 1.6;
            font-size: 16px;
            font-weight: 500;
        }
        .contact-box strong {
            color: #2c3e2d;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                    <path d="M12 17h.01"/>
                </svg>
            </span>
            Help & Guide
        </h1>
        
        <!-- Getting Started -->
        <div class="content-card">
            <h2>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
                </svg>
                Getting Started
            </h2>
            
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
                        <polyline points="10 17 15 12 10 7"/>
                        <line x1="15" y1="12" x2="3" y2="12"/>
                    </svg>
                    Mag-login gamit ang inyong assigned username at password.
                </h3>
                <p>Para mag-login sa system, pumunta sa login page at ilagay ang inyong username at password na ibinigay ng Super Admin. Siguraduhing tama ang inyong credentials bago mag-click ng "Login" button. Kung may problema sa pag-login, maaaring kontakin ang IT support.</p>
            </div>
            
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="18" height="18" rx="2"/>
                        <path d="M3 9h18M9 21V9"/>
                    </svg>
                    Sa dashboard, makikita ang overview ng system at mga importanteng impormasyon.
                </h3>
                <p>Ang dashboard ay nagpapakita ng summary ng lahat ng importanteng impormasyon sa system. Dito makikita ang bilang ng residents, pending requests, announcements, at iba pang statistics. Gamitin ang dashboard para sa quick overview ng barangay operations.</p>
            </div>
            
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="8" y1="6" x2="21" y2="6"/>
                        <line x1="8" y1="12" x2="21" y2="12"/>
                        <line x1="8" y1="18" x2="21" y2="18"/>
                        <line x1="3" y1="6" x2="3.01" y2="6"/>
                        <line x1="3" y1="12" x2="3.01" y2="12"/>
                        <line x1="3" y1="18" x2="3.01" y2="18"/>
                    </svg>
                    Gumamit ng sidebar menu para ma-access ang iba't ibang modules tulad ng Residents, Documents, Reports, at Manage Users.
                </h3>
                <p>Ang sidebar menu ay nasa kaliwang bahagi ng screen. Dito makikita ang lahat ng available modules. I-click ang anumang menu item para ma-access ang specific module. May mga submenu din para sa mas organized na navigation.</p>
            </div>
        </div>
        
        <!-- Module Guides -->
        <div class="content-card">
            <h2>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="3" y="3" width="18" height="18" rx="2"/>
                    <path d="M9 9h6v6H9z"/>
                </svg>
                Module Guides
            </h2>
            
            <!-- Residents Module -->
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                        <circle cx="12" cy="7" r="4"/>
                    </svg>
                    Residents Module
                </h3>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano mag-add ng bagong resident record:</strong></p>
                    <p>Pumunta sa Residents module at i-click ang "Add New Resident" button. Punan ang lahat ng required fields tulad ng pangalan, address, birthdate, contact number, at iba pang importanteng impormasyon. I-click ang "Save" button para ma-save ang record.</p>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano i-edit o i-update ang impormasyon ng resident:</strong></p>
                    <p>Hanapin ang resident record sa listahan. I-click ang "Edit" button sa tabi ng resident name. Gawin ang mga pagbabago sa impormasyon at i-click ang "Update" button para ma-save ang changes.</p>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano mag-search ng resident gamit ang pangalan o ibang detalye:</strong></p>
                    <p>Gamitin ang search box sa taas ng residents list. Maaaring mag-type ng pangalan, address, o anumang detalye ng resident. Ang system ay automatic na magfi-filter ng results base sa inyong search query.</p>
                </div>
            </div>
            
            <!-- Documents Module -->
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                        <line x1="16" y1="13" x2="8" y2="13"/>
                        <line x1="16" y1="17" x2="8" y2="17"/>
                        <polyline points="10 9 9 9 8 9"/>
                    </svg>
                    Documents Module
                </h3>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano gumawa at mag-process ng mga barangay documents tulad ng clearance, indigency, at residency:</strong></p>
                    <p>Pumunta sa Requests module at hanapin ang document request. I-review ang impormasyon ng resident at i-verify kung complete ang requirements. I-click ang "Approve" button para ma-process ang request. Pagkatapos, maaaring i-generate ang PDF document at i-print o i-save.</p>
                </div>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano mag-print at mag-save ng dokumento:</strong></p>
                    <p>Pagkatapos ma-approve ang request, i-click ang "Generate PDF" button. Ang system ay mag-generate ng PDF file na maaaring i-print o i-download. Para mag-print, i-click ang print button sa PDF viewer. Para mag-save, i-click ang download button.</p>
                </div>
            </div>
            
            <!-- Reports Module -->
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
                        <polyline points="14 2 14 8 20 8"/>
                        <line x1="16" y1="13" x2="8" y2="13"/>
                        <line x1="16" y1="17" x2="8" y2="17"/>
                        <polyline points="10 9 9 9 8 9"/>
                    </svg>
                    Reports Module
                </h3>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano gumawa at mag-generate ng mga ulat at summary ng data:</strong></p>
                    <p>Pumunta sa Records module at piliin ang type ng report na gusto ninyong i-generate. Piliin ang date range at iba pang filters. I-click ang "Generate Report" button. Ang system ay mag-generate ng report na maaaring i-view, i-print, o i-export bilang PDF o Excel file.</p>
                </div>
            </div>
            
            <!-- Manage Users Module -->
            <?php if ($admin_role === 'super_admin'): ?>
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                        <circle cx="9" cy="7" r="4"/>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                    </svg>
                    Manage Users Module
                </h3>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Para sa Super Admin: Paano mag-add, mag-edit, o mag-delete ng admin accounts:</strong></p>
                    <p>Pumunta sa "Manage Admins" sa sidebar. Para mag-add ng bagong admin, i-click ang "Add New Admin" button at punan ang required information. Para mag-edit, hanapin ang admin account at i-click ang "Edit" button. Para mag-delete o mag-deactivate, i-click ang "Deactivate" button. Tandaan na ang Super Admin lang ang may access sa function na ito.</p>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Settings Module -->
            <div class="help-section">
                <h3>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="3"/>
                        <path d="M12 1v6m0 6v6m11-7h-6m-6 0H1"/>
                    </svg>
                    Settings Module
                </h3>
                
                <div style="margin-bottom: 15px;">
                    <p><strong>Paano i-update ang mga impormasyon ng barangay (kung accessible):</strong></p>
                    <p>Pumunta sa "Barangay Settings" sa System submenu (Super Admin only). Dito maaaring i-update ang barangay name, address, contact information, at iba pang barangay details. Gawin ang mga pagbabago at i-click ang "Save Changes" button.</p>
                </div>
            </div>
        </div>
        
        <!-- Common FAQs -->
        <div class="content-card">
            <h2>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
                    <path d="M12 17h.01"/>
                </svg>
                Common FAQs
            </h2>
            
            <div class="faq-item">
                <div class="faq-question">Paano mag-reset ng password?</div>
                <div class="faq-answer">Kung kailangan ninyong mag-reset ng password, pumunta sa "Manage Account" sa sidebar at i-click ang "Change Password" option. Ilagay ang inyong current password at ang bagong password. Kung nakalimutan ninyo ang password, kontakin ang Super Admin o IT support para sa assistance.</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">Ano ang gagawin kapag nakalimutan ang username?</div>
                <div class="faq-answer">Kung nakalimutan ninyo ang username, kontakin ang Super Admin o IT support. Sila ang makakatulong sa inyo para ma-recover ang inyong username. Maaari ring mag-check sa email kung may record ng inyong account creation.</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">Paano mag-report ng errors o technical issues?</div>
                <div class="faq-answer">Para mag-report ng errors o technical issues, kontakin agad ang IT support sa email o contact number na nakalista sa Contact Support section. Ibigay ang detailed description ng problema, kung kailan nangyari, at anumang error messages na nakita ninyo. Maaari ring mag-take ng screenshot para mas mabilis ma-resolve ang issue.</div>
            </div>
            
            <div class="faq-item">
                <div class="faq-question">Kanino pwedeng kontakin para sa support?</div>
                <div class="faq-answer">Para sa technical support, maaaring kontakin ang IT support team sa email: support@barangayportal.com o sa contact number: 09236789435. Available ang suporta mula Lunes hanggang Biyernes, 8AM hanggang 5PM. Para sa non-technical concerns, maaaring kontakin ang barangay office.</div>
            </div>
        </div>
        
        <!-- System Tips and Best Practices -->
        <div class="content-card">
            <h2>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    <path d="M9 12l2 2 4-4"/>
                </svg>
                System Tips and Best Practices
            </h2>
            
            <div class="tip-box">
                <p><strong>Siguraduhing mag-backup ng data nang regular.</strong></p>
                <p>Mahalaga na regular na mag-backup ng data para maiwasan ang pagkawala ng impormasyon. Ang Super Admin ay may access sa backup functions sa System Maintenance module. Regular na i-schedule ang backup operations.</p>
            </div>
            
            <div class="tip-box">
                <p><strong>Gumamit ng malalakas at secure na password.</strong></p>
                <p>Siguraduhing gumamit ng strong password na may combination ng uppercase, lowercase, numbers, at special characters. Huwag ibahagi ang inyong password sa iba at regular na i-update ito para sa mas mataas na security.</p>
            </div>
            
            <div class="tip-box">
                <p><strong>Regular na i-monitor ang activity logs.</strong></p>
                <p>Ang activity logs ay nagpapakita ng lahat ng actions na ginawa sa system. Regular na i-review ang logs para ma-monitor ang system usage at ma-detect ang anumang suspicious activities. Ang Super Admin ay may full access sa activity logs.</p>
            </div>
            
            <div class="tip-box">
                <p><strong>I-maintain ang role-based access para sa seguridad ng system.</strong></p>
                <p>Mahalaga na i-maintain ang proper role-based access control. Ang Regular Admin ay may limited access habang ang Super Admin ay may full system access. Huwag ibahagi ang inyong account credentials at siguraduhing tama ang role assignment para sa bawat admin user.</p>
            </div>
        </div>
        
        <!-- Contact Support -->
        <div class="content-card">
            <h2>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
                Contact Support
            </h2>
            
            <div class="contact-box">
                <p><strong>Para sa teknikal na suporta, maaaring kontakin ang IT support sa:</strong></p>
                <p><strong>Email:</strong> support@barangayportal.com</p>
                <p><strong>Contact Number:</strong> 09236789435</p>
                <p><strong>Available Hours:</strong> Lunes hanggang Biyernes, 8AM hanggang 5PM</p>
                <p style="margin-top: 15px;">Para sa mas mabilis na response, magbigay ng detailed description ng problema, screenshots kung available, at anumang relevant information na makakatulong sa pag-resolve ng issue.</p>
            </div>
        </div>
    </div>
</body>
</html>
