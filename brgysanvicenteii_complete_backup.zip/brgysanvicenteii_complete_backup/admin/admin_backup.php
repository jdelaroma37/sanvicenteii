<?php
// admin/admin_backup.php - Super Admin Only
session_start();
require '../config.php';
require 'role_helper.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';

if ($admin_role !== 'super_admin') {
    $_SESSION['error'] = 'Access denied. Only Super Admins can access backup features.';
    header('Location: admin_dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Backup & Export - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .page-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            background: #2c3e2d;
            color: white;
        }
        .page-actions .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .btn-secondary,
        .page-actions .btn-secondary {
            background: #4b5563 !important;
            color: white !important;
        }
        .btn-secondary:hover,
        .page-actions .btn-secondary:hover {
            background: #374151 !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(75, 85, 99, 0.3);
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .page-description {
            font-size: 14px;
            color: #666;
            margin-top: -10px;
            margin-bottom: 20px;
            font-weight: normal;
        }
        .export-option {
            padding: 25px;
            background: white;
            border-radius: 12px;
            text-decoration: none;
            color: #333;
            border: 2px solid #e0e0e0;
            transition: all 0.3s;
            display: block;
        }
        .export-option:hover {
            border-color: #2c3e2d;
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .export-option-disabled {
            padding: 25px;
            background: white;
            border-radius: 12px;
            border: 2px solid #e0e0e0;
            opacity: 0.7;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
            </span>
            Backup & Export
        </h1>

        <div class="page-actions">
            <a href="admin_barangay_settings.php" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Barangay Settings
            </a>
        </div>
        
        <div class="row-container">
            <div class="content-card" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="font-size: 26px; font-weight: 800; color: #2c3e2d; margin-bottom: 6px; margin-top: 0; letter-spacing: -0.3px; display: flex; align-items: center; gap: 8px;">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2c3e2d; opacity: 0.6;">
                    <path d="M3 2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H3z" stroke="currentColor" stroke-width="1.5" fill="none"/>
                    <path d="M5 6h6M5 9h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Data Export
            </h2>
            <p style="color: #6b7280; font-size: 18px; font-weight: 600; margin-bottom: 16px; margin-top: 0;">Export barangay data and create backups for system records.</p>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                <a href="admin_residents_export.php" class="export-option">
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                        <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2c3e2d;">
                            <path d="M8 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" stroke="currentColor" stroke-width="1.5" fill="none"/>
                            <path d="M2 14c0-3.314 2.686-6 6-6s6 2.686 6 6" stroke="currentColor" stroke-width="1.5" fill="none"/>
                        </svg>
                        <h3 style="margin: 0; color: #2c3e2d; font-size: 16px; font-weight: 700;">Export Residents</h3>
                    </div>
                    <p style="margin: 0; font-size: 13px; color: #6b7280; font-weight: 500;">Export resident data to Excel/CSV</p>
                </a>
                
                <div class="export-option-disabled">
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                        <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2c3e2d;">
                            <path d="M3 2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H3z" stroke="currentColor" stroke-width="1.5" fill="none"/>
                            <path d="M5 6h6M5 9h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        <h3 style="margin: 0; color: #2c3e2d; font-size: 16px; font-weight: 700;">Database Backup</h3>
                    </div>
                    <p style="margin: 0; font-size: 13px; color: #6b7280; font-weight: 500;">Backup database (Coming soon)</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>

