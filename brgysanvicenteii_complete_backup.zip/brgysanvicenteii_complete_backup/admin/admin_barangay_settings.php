<?php
// admin/admin_barangay_settings.php - Super Admin Only
session_start();
require '../config.php';
require 'role_helper.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';

if ($admin_role !== 'super_admin') {
    $_SESSION['error'] = 'Access denied. Only Super Admins can access barangay settings.';
    header('Location: admin_dashboard.php');
    exit;
}

// Settings file
$settings_dir = __DIR__ . '/../data/settings';
if (!is_dir($settings_dir)) {
    mkdir($settings_dir, 0777, true);
}
$settings_file = $settings_dir . '/barangay_settings.json';

// Load settings
$settings = [
    'logo' => 'images/logo.jpg',
    'name' => 'Barangay San Vicente II',
    'address' => 'Silang, Cavite'
];

if (file_exists($settings_file)) {
    $loaded = json_decode(file_get_contents($settings_file), true);
    if (is_array($loaded)) {
        $settings = array_merge($settings, $loaded);
    }
}

// Officials file
$officials_dir = __DIR__ . '/../data/officials';
if (!is_dir($officials_dir)) {
    mkdir($officials_dir, 0777, true);
}
$officials_file = $officials_dir . '/officials.json';

// Load officials
$officials = [];
if (file_exists($officials_file)) {
    $officials = json_decode(file_get_contents($officials_file), true) ?? [];
}
if (!is_array($officials)) {
    $officials = [];
}

// Common positions
$common_positions = [
    'Punong Barangay',
    'Kagawad',
    'SK Chairperson',
    'Kalihim',
    'Ingat-Yaman',
    'Kababaihan/CSO',
    'Tau Gama/CSO',
    'Chief Tanod',
    'Brgy. Driver',
    'BNS',
    'Other'
];

// Handle form submissions
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'update_settings') {
        // Update barangay settings
        $name = trim($_POST['name'] ?? '');
        $address = trim($_POST['address'] ?? '');
        
        if (!$name) {
            $error = 'Barangay name is required.';
        } else {
            $settings['name'] = $name;
            $settings['address'] = $address;
            
            // Handle logo upload
            if (isset($_FILES['logo']) && is_uploaded_file($_FILES['logo']['tmp_name'])) {
                if ($_FILES['logo']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = __DIR__ . '/../images/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_ext = strtolower(pathinfo($_FILES['logo']['name'], PATHINFO_EXTENSION));
                    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    
                    if (in_array($file_ext, $allowed_ext)) {
                        $new_filename = 'logo.' . $file_ext;
                        $upload_path = $upload_dir . $new_filename;
                        
                        if (move_uploaded_file($_FILES['logo']['tmp_name'], $upload_path)) {
                            $settings['logo'] = 'images/' . $new_filename;
                        }
                    }
                }
            }
            
            file_put_contents($settings_file, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $success = 'Barangay settings updated successfully!';
        }
    } elseif ($action === 'update_official') {
        // Update official service years
        $id = $_POST['id'] ?? '';
        $service_year_start = trim($_POST['service_year_start'] ?? '');
        $service_year_end = trim($_POST['service_year_end'] ?? '');
        
        $found = false;
        foreach ($officials as &$off) {
            if (isset($off['id']) && $off['id'] === $id) {
                $off['service_year_start'] = $service_year_start;
                $off['service_year_end'] = $service_year_end;
                $off['updated_at'] = date('Y-m-d H:i:s');
                $found = true;
                break;
            }
        }
        
        if ($found) {
            file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $success = 'Official service years updated successfully!';
        } else {
            $error = 'Official not found.';
        }
    } elseif ($action === 'edit_official') {
        // Edit official details including profile photo
        $id = $_POST['id'] ?? '';
        $name = trim($_POST['name'] ?? '');
        $position = trim($_POST['position'] ?? '');
        $contact = trim($_POST['contact'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $year_batch = trim($_POST['year_batch'] ?? '');
        $service_year_start = trim($_POST['service_year_start'] ?? '');
        $service_year_end = trim($_POST['service_year_end'] ?? '');
        $order = intval($_POST['order'] ?? 0);
        
        if (!$name || !$position) {
            $error = 'Name and position are required.';
        } else {
            $found = false;
            foreach ($officials as &$off) {
                if (isset($off['id']) && $off['id'] === $id) {
                    $off['name'] = $name;
                    $off['position'] = $position;
                    $off['contact'] = $contact;
                    $off['email'] = $email;
                    $off['year_batch'] = $year_batch;
                    $off['service_year_start'] = $service_year_start;
                    $off['service_year_end'] = $service_year_end;
                    $off['order'] = $order;
                    
                    // Handle image upload
                    if (isset($_FILES['photo']) && !empty($_FILES['photo']['name'])) {
                        if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                            if (is_uploaded_file($_FILES['photo']['tmp_name'])) {
                                $upload_dir = __DIR__ . '/../uploads/officials/';
                                if (!is_dir($upload_dir)) {
                                    if (!mkdir($upload_dir, 0777, true)) {
                                        $error = 'Failed to create upload directory: ' . $upload_dir;
                                        break;
                                    }
                                }
                                
                                // Check if directory is writable
                                if (!is_writable($upload_dir)) {
                                    $error = 'Upload directory is not writable: ' . $upload_dir;
                                    break;
                                }
                                
                                // Check file size (5MB max)
                                $max_size = 5 * 1024 * 1024;
                                if ($_FILES['photo']['size'] > $max_size) {
                                    $error = 'File size exceeds 5MB limit.';
                                    break;
                                }
                                
                                $original_name = $_FILES['photo']['name'];
                                $file_ext = strtolower(trim(pathinfo($original_name, PATHINFO_EXTENSION)));
                                
                                // Remove any dots or spaces from extension
                                $file_ext = str_replace(['.', ' '], '', $file_ext);
                                
                                $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                                
                                // Also check MIME type as backup
                                $file_mime = '';
                                if (function_exists('mime_content_type') && file_exists($_FILES['photo']['tmp_name'])) {
                                    $file_mime = mime_content_type($_FILES['photo']['tmp_name']);
                                } elseif (function_exists('finfo_file')) {
                                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                    $file_mime = finfo_file($finfo, $_FILES['photo']['tmp_name']);
                                    finfo_close($finfo);
                                }
                                
                                $allowed_mimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
                                
                                // Check both extension and MIME type
                                $is_valid_ext = in_array($file_ext, $allowed_ext);
                                $is_valid_mime = !empty($file_mime) && in_array($file_mime, $allowed_mimes);
                                
                                if ($is_valid_ext || $is_valid_mime) {
                                    // Use the detected extension or default to jpg if MIME type is valid but extension is missing
                                    if (empty($file_ext) && $is_valid_mime) {
                                        if (strpos($file_mime, 'jpeg') !== false || strpos($file_mime, 'jpg') !== false) {
                                            $file_ext = 'jpg';
                                        } elseif (strpos($file_mime, 'png') !== false) {
                                            $file_ext = 'png';
                                        } elseif (strpos($file_mime, 'gif') !== false) {
                                            $file_ext = 'gif';
                                        } elseif (strpos($file_mime, 'webp') !== false) {
                                            $file_ext = 'webp';
                                        }
                                    }
                                    // Delete old image if exists
                                    if (!empty($off['photo']) && file_exists(__DIR__ . '/../' . $off['photo'])) {
                                        @unlink(__DIR__ . '/../' . $off['photo']);
                                    }
                                    
                                    $new_filename = 'official_' . time() . '_' . uniqid() . '.' . $file_ext;
                                    $upload_path = $upload_dir . $new_filename;
                                    
                                    if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                                        $off['photo'] = 'uploads/officials/' . $new_filename;
                                        // Verify file was saved
                                        if (file_exists($upload_path)) {
                                            // Success - photo saved
                                        } else {
                                            $error = 'Photo uploaded but file verification failed.';
                                        }
                                    } else {
                                        $error = 'Failed to move uploaded file. Check folder permissions on uploads/officials/';
                                    }
                                } else {
                                    $error = 'Invalid file type. Only JPG, PNG, GIF, and WEBP are allowed. File: ' . htmlspecialchars($original_name) . ', Extension: ' . ($file_ext ?: 'none') . ', MIME: ' . ($file_mime ?: 'unknown');
                                }
                            } else {
                                $error = 'File upload security check failed.';
                            }
                        } else {
                            $upload_errors = [
                                UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize in php.ini',
                                UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE in form',
                                UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                                UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                                UPLOAD_ERR_EXTENSION => 'PHP extension stopped the upload'
                            ];
                            $error_msg = $upload_errors[$_FILES['photo']['error']] ?? 'Unknown upload error (code: ' . $_FILES['photo']['error'] . ')';
                            $error = 'File upload error: ' . $error_msg;
                        }
                    }
                    // If no new photo uploaded, keep existing photo (don't change $off['photo'])
                    
                    $off['updated_at'] = date('Y-m-d H:i:s');
                    $found = true;
                    break;
                }
            }
            
            if ($found) {
                // Save to file
                file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                
                // Debug: Check if photo was saved
                $saved_data = json_decode(file_get_contents($officials_file), true);
                $updated_official = null;
                foreach ($saved_data as $saved_off) {
                    if (isset($saved_off['id']) && $saved_off['id'] === $id) {
                        $updated_official = $saved_off;
                        break;
                    }
                }
                
                if ($updated_official && !empty($updated_official['photo'])) {
                    $_SESSION['success'] = 'Official updated successfully! Photo saved.';
                } else {
                    $_SESSION['success'] = 'Official updated successfully!';
                    if (isset($_FILES['photo']) && !empty($_FILES['photo']['name'])) {
                        if (!empty($error)) {
                            $_SESSION['error'] = $error;
                        } else {
                            $_SESSION['error'] = 'Warning: Photo upload may have failed. Please check file permissions.';
                        }
                    }
                }
                
                header('Location: admin_barangay_settings.php');
                exit;
            } else {
                $error = 'Official not found.';
            }
        }
        
        // Reload officials after any update
        if (file_exists($officials_file)) {
            $officials = json_decode(file_get_contents($officials_file), true) ?? [];
            if (!is_array($officials)) {
                $officials = [];
            }
        }
    } elseif ($action === 'create_official') {
        // Create new official
        $name = trim($_POST['name'] ?? '');
        $position = trim($_POST['position'] ?? '');
        $contact = trim($_POST['contact'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $year_batch = trim($_POST['year_batch'] ?? '');
        $service_year_start = trim($_POST['service_year_start'] ?? '');
        $service_year_end = trim($_POST['service_year_end'] ?? '');
        $order = intval($_POST['order'] ?? 0);
        
        if (!$name || !$position) {
            $error = 'Name and position are required.';
        } else {
            // Handle image upload
            $image_path = '';
            if (isset($_FILES['photo']) && !empty($_FILES['photo']['name'])) {
                if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                    if (is_uploaded_file($_FILES['photo']['tmp_name'])) {
                        $upload_dir = __DIR__ . '/../uploads/officials/';
                        if (!is_dir($upload_dir)) {
                            if (!mkdir($upload_dir, 0777, true)) {
                                $error = 'Failed to create upload directory.';
                            }
                        }
                        
                        if (empty($error)) {
                            // Check file size (5MB max)
                            $max_size = 5 * 1024 * 1024;
                            if ($_FILES['photo']['size'] > $max_size) {
                                $error = 'File size exceeds 5MB limit.';
                            } else {
                                $original_name = $_FILES['photo']['name'];
                                $file_ext = strtolower(trim(pathinfo($original_name, PATHINFO_EXTENSION)));
                                $file_ext = str_replace(['.', ' '], '', $file_ext);
                                
                                $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                                
                                // Check MIME type
                                $file_mime = '';
                                if (function_exists('mime_content_type') && file_exists($_FILES['photo']['tmp_name'])) {
                                    $file_mime = mime_content_type($_FILES['photo']['tmp_name']);
                                } elseif (function_exists('finfo_file')) {
                                    $finfo = finfo_open(FILEINFO_MIME_TYPE);
                                    $file_mime = finfo_file($finfo, $_FILES['photo']['tmp_name']);
                                    finfo_close($finfo);
                                }
                                
                                $allowed_mimes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
                                $is_valid_ext = in_array($file_ext, $allowed_ext);
                                $is_valid_mime = !empty($file_mime) && in_array($file_mime, $allowed_mimes);
                                
                                if ($is_valid_ext || $is_valid_mime) {
                                    if (empty($file_ext) && $is_valid_mime) {
                                        if (strpos($file_mime, 'jpeg') !== false || strpos($file_mime, 'jpg') !== false) {
                                            $file_ext = 'jpg';
                                        } elseif (strpos($file_mime, 'png') !== false) {
                                            $file_ext = 'png';
                                        } elseif (strpos($file_mime, 'gif') !== false) {
                                            $file_ext = 'gif';
                                        } elseif (strpos($file_mime, 'webp') !== false) {
                                            $file_ext = 'webp';
                                        }
                                    }
                                    
                                    $new_filename = 'official_' . time() . '_' . uniqid() . '.' . $file_ext;
                                    $upload_path = $upload_dir . $new_filename;
                                    
                                    if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                                        $image_path = 'uploads/officials/' . $new_filename;
                                    } else {
                                        $error = 'Failed to move uploaded file.';
                                    }
                                } else {
                                    $error = 'Invalid file type. Only JPG, PNG, GIF, and WEBP are allowed.';
                                }
                            }
                        }
                    }
                }
            }
            
            if (empty($error)) {
                $new_official = [
                    'id' => uniqid('off_'),
                    'name' => $name,
                    'position' => $position,
                    'contact' => $contact,
                    'email' => $email,
                    'photo' => $image_path,
                    'year_batch' => $year_batch,
                    'service_year_start' => $service_year_start,
                    'service_year_end' => $service_year_end,
                    'order' => $order,
                    'created_at' => date('Y-m-d H:i:s'),
                    'created_by' => $admin_id
                ];
                $officials[] = $new_official;
                file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['success'] = 'Official added successfully!';
                header('Location: admin_barangay_settings.php');
                exit;
            }
        }
    } elseif ($action === 'delete_official') {
        // Delete official
        $id = $_POST['id'] ?? '';
        $found = false;
        foreach ($officials as $key => $off) {
            if (isset($off['id']) && $off['id'] === $id) {
                // Delete image if exists
                if (!empty($off['photo']) && file_exists(__DIR__ . '/../' . $off['photo'])) {
                    @unlink(__DIR__ . '/../' . $off['photo']);
                }
                unset($officials[$key]);
                $officials = array_values($officials);
                $found = true;
                break;
            }
        }
        if ($found) {
            file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['success'] = 'Official deleted successfully!';
        } else {
            $_SESSION['error'] = 'Official not found.';
        }
        header('Location: admin_barangay_settings.php');
        exit;
    } elseif ($action === 'update_signature') {
        // Update document signature
        $signature_type = $_POST['signature_type'] ?? '';
        $signature_name = trim($_POST['signature_name'] ?? '');
        
        if (!$signature_type || !$signature_name) {
            $error = 'Signature type and name are required.';
        } else {
            if (!isset($settings['signatures'])) {
                $settings['signatures'] = [];
            }
            $settings['signatures'][$signature_type] = $signature_name;
            
            // Handle signature image upload
            if (isset($_FILES['signature_image']) && is_uploaded_file($_FILES['signature_image']['tmp_name'])) {
                if ($_FILES['signature_image']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = __DIR__ . '/../images/signatures/';
                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_ext = strtolower(pathinfo($_FILES['signature_image']['name'], PATHINFO_EXTENSION));
                    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                    
                    if (in_array($file_ext, $allowed_ext)) {
                        $new_filename = $signature_type . '_' . time() . '.' . $file_ext;
                        $upload_path = $upload_dir . $new_filename;
                        
                        if (move_uploaded_file($_FILES['signature_image']['tmp_name'], $upload_path)) {
                            $settings['signatures'][$signature_type . '_image'] = 'images/signatures/' . $new_filename;
                        }
                    }
                }
            }
            
            file_put_contents($settings_file, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $success = 'Document signature updated successfully!';
        }
    }
    
    // Reload settings after update
    if (file_exists($settings_file)) {
        $loaded = json_decode(file_get_contents($settings_file), true);
        if (is_array($loaded)) {
            $settings = array_merge($settings, $loaded);
        }
    }
    
    // Reload officials after update
    if (file_exists($officials_file)) {
        $officials = json_decode(file_get_contents($officials_file), true) ?? [];
    }
}

$success_msg = $_SESSION['success'] ?? $success;
$error_msg = $_SESSION['error'] ?? $error;
unset($_SESSION['success'], $_SESSION['error']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Settings - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .page-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            background: #2c3e2d;
            color: white;
        }
        .page-actions .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .table-container {
            overflow-x: auto;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }
        table th {
            background: #2c3e2d;
            color: white;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            border-bottom: 2px solid rgba(212, 175, 55, 0.3);
            border-right: 1px solid rgba(255, 255, 255, 0.1);
        }
        table th:last-child {
            border-right: none;
        }
        table td {
            padding: 12px;
            border-bottom: 1px solid #e0e0e0;
            color: #4b5563;
            font-size: 14px;
            border-right: 1px solid #e0e0e0;
        }
        table td:last-child {
            border-right: none;
        }
        table tbody tr:hover {
            background: #f9fafb;
        }
        table strong {
            color: #2c3e2d;
            font-weight: 700;
            font-size: 14px;
        }
        /* Modal styles */
        .modal {
            display: none !important;
            position: fixed;
            z-index: 9999;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex !important;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 35px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .modal-header h2 {
            font-size: 26px;
            color: #2c3e2d;
            font-weight: 800;
            letter-spacing: -0.3px;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 28px;
            color: #999;
            cursor: pointer;
            transition: color 0.3s;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 700;
            font-size: 16px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .photo-preview-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .photo-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center;
            border: 2px solid #e5e7eb;
            margin: 0 auto;
            display: block;
            aspect-ratio: 1 / 1;
        }
        .form-group input[type="file"] {
            padding: 8px;
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: #d0d0d0;
        }
        .btn-submit {
            flex: 1;
            padding: 12px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .modal-body {
            padding: 20px 0;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }
        .btn-reset {
            padding: 10px 20px;
            background: #dc2626;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-reset:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 38, 38, 0.3);
        }
        .btn-delete-modal {
            padding: 10px 20px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-delete-modal:hover {
            background: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 53, 69, 0.3);
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="12" cy="12" r="3"></circle>
                    <path d="M12 1v6m0 6v6M5.64 5.64l4.24 4.24m4.24 4.24l4.24 4.24M1 12h6m6 0h6M5.64 18.36l4.24-4.24m4.24-4.24l4.24-4.24"></path>
                </svg>
            </span>
            Barangay Settings
        </h1>

        <div class="page-actions">
            <a href="admin_activity_logs.php" class="btn">Activity Logs</a>
            <a href="admin_system_maintenance.php" class="btn">System Maintenance</a>
            <a href="admin_backup.php" class="btn">Backup and Export</a>
        </div>
        
        <?php if ($error_msg): ?>
            <div style="background: #fee; color: #c33; padding: 15px; border-radius: 8px; margin: 20px 0;"><?php echo htmlspecialchars($error_msg); ?></div>
        <?php endif; ?>
        
        <?php if ($success_msg): ?>
            <div style="background: #efe; color: #3c3; padding: 15px; border-radius: 8px; margin: 20px 0;"><?php echo htmlspecialchars($success_msg); ?></div>
        <?php endif; ?>
        
        <!-- Barangay Information -->
        <div class="row-container">
            <div class="content-card" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="font-size: 26px; font-weight: 800; color: #2c3e2d; margin-bottom: 6px; margin-top: 0; letter-spacing: -0.3px; display: flex; align-items: center; gap: 8px;">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2c3e2d; opacity: 0.6;">
                    <rect x="3" y="3" width="10" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M6 7h4M6 10h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Barangay Information
            </h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_settings">
                
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 8px; color: #2c3e2d; font-weight: 600; font-size: 14px;">Logo</label>
                    <img src="../<?php echo htmlspecialchars($settings['logo']); ?>" alt="Logo" style="width: 150px; height: 150px; border-radius: 8px; object-fit: cover; border: 3px solid #d4af37; margin-bottom: 15px; display: block;" id="logoPreview">
                    <input type="file" name="logo" accept="image/*" onchange="previewLogo(this)" style="padding: 8px; border: 1px solid #e0e0e0; border-radius: 8px; width: 100%;">
                    <small style="color: #6b7280; font-size: 13px; display: block; margin-top: 5px; font-weight: 500;">Upload barangay logo (JPG, PNG, GIF, WEBP)</small>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <label for="name" style="display: block; margin-bottom: 8px; color: #2c3e2d; font-weight: 600; font-size: 14px;">Barangay Name *</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($settings['name']); ?>" required style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                </div>
                
                <div style="margin-bottom: 20px;">
                    <label for="address" style="display: block; margin-bottom: 8px; color: #2c3e2d; font-weight: 600; font-size: 14px;">Address *</label>
                    <textarea id="address" name="address" rows="3" required style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; font-family: inherit;"><?php echo htmlspecialchars($settings['address']); ?></textarea>
                </div>
                
                <button type="submit" style="padding: 12px 24px; background: #2c3e2d; color: white; border: none; border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all 0.3s;" onmouseover="this.style.background='#1a2e1b'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(44, 62, 45, 0.3)';" onmouseout="this.style.background='#2c3e2d'; this.style.transform=''; this.style.boxShadow='';">Save Changes</button>
            </form>
            </div>
        </div>
        
        <!-- Officials Management -->
        <div class="row-container">
            <div class="content-card" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="font-size: 26px; font-weight: 800; color: #2c3e2d; margin-bottom: 6px; margin-top: 0; letter-spacing: -0.3px; display: flex; align-items: center; gap: 8px;">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2c3e2d; opacity: 0.6;">
                    <circle cx="8" cy="6" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M4 13.5c0-2 2-3.5 4-3.5s4 1.5 4 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                Officials Management
            </h2>
            <div style="margin-bottom: 20px;">
                <button type="button" onclick="openAddModal()" style="padding: 10px 20px; background: #2c3e2d; color: white; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.3s;" onmouseover="this.style.background='#1a2e1b'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(44, 62, 45, 0.3)';" onmouseout="this.style.background='#2c3e2d'; this.style.transform=''; this.style.boxShadow='';">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                        <path d="M8 3v10M3 8h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                    Add Official
                </button>
            </div>
            
            <?php if (empty($officials)): ?>
                <p style="color: #6b7280; font-size: 16px; text-align: center; padding: 40px; font-weight: 500;">No officials found. Please add officials first.</p>
            <?php else: ?>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($officials as $off): ?>
                                <tr>
                                    <td><strong style="color: #2c3e2d; font-weight: 700; font-size: 14px;"><?php echo htmlspecialchars($off['name'] ?? ''); ?></strong></td>
                                    <td style="color: #6b7280; font-size: 14px; font-weight: 500;"><?php echo htmlspecialchars($off['position'] ?? ''); ?></td>
                                    <td>
                                        <button type="button" class="edit-official-btn" data-official='<?php echo htmlspecialchars(json_encode($off), ENT_QUOTES, 'UTF-8'); ?>' style="padding: 6px 12px; background: #87A96B; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.3s; margin-right: 5px; display: inline-flex; align-items: center; gap: 4px;" onmouseover="this.style.background='#7a9660'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='#87A96B'; this.style.transform='';">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block;">
                                                <path d="M11 2l3 3M9 8l3 3M3 12l5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                <path d="M2 14h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                            </svg>
                                            Edit
                                        </button>
                                        <button type="button" onclick="deleteOfficial('<?php echo htmlspecialchars($off['id'] ?? ''); ?>', '<?php echo htmlspecialchars(addslashes($off['name'] ?? '')); ?>')" style="padding: 6px 12px; background: #dc3545; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; font-weight: 600; transition: all 0.3s; display: inline-flex; align-items: center; gap: 4px;" onmouseover="this.style.background='#c82333'; this.style.transform='translateY(-1px)';" onmouseout="this.style.background='#dc3545'; this.style.transform='';">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block;">
                                                <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                                <path d="M3 4h10M3 8h10M3 12h10" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" opacity="0.3"/>
                                            </svg>
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
            </div>
        </div>
        
        <!-- Document Signatures -->
        <div class="row-container">
            <div class="content-card" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
            <h2 style="font-size: 26px; font-weight: 800; color: #2c3e2d; margin-bottom: 6px; margin-top: 0; letter-spacing: -0.3px; display: flex; align-items: center; gap: 8px;">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="color: #2c3e2d; opacity: 0.6;">
                    <path d="M11 2l3 3M9 8l3 3M3 12l5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Document Signatures
            </h2>
            <p style="color: #6b7280; font-size: 18px; margin-bottom: 20px; font-weight: 600;">Manage digital signatures for document generation.</p>
            
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="update_signature">
                
                <div style="margin-bottom: 20px;">
                    <label for="signature_type" style="display: block; margin-bottom: 8px; color: #2c3e2d; font-weight: 600; font-size: 14px;">Signature Type</label>
                    <select id="signature_type" name="signature_type" required style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                        <option value="punong_barangay">Punong Barangay</option>
                        <option value="kagawad">Kagawad</option>
                        <option value="secretary">Secretary</option>
                    </select>
                </div>
                
                <div style="margin-bottom: 20px;">
                    <label for="signature_name" style="display: block; margin-bottom: 8px; color: #2c3e2d; font-weight: 600; font-size: 14px;">Signature Name</label>
                    <input type="text" id="signature_name" name="signature_name" placeholder="e.g., Hon. Angelina S. Duguran" required style="width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px;">
                </div>
                
                <div style="margin-bottom: 20px;">
                    <label for="signature_image" style="display: block; margin-bottom: 8px; color: #2c3e2d; font-weight: 600; font-size: 14px;">Signature Image (Optional)</label>
                    <input type="file" id="signature_image" name="signature_image" accept="image/*" onchange="previewSignature(this)" style="padding: 8px; border: 1px solid #e0e0e0; border-radius: 8px; width: 100%;">
                    <small style="color: #6b7280; font-size: 13px; display: block; margin-top: 5px; font-weight: 500;">Upload digital signature image</small>
                    <img id="signaturePreview" style="max-width: 200px; max-height: 100px; border: 2px solid #e0e0e0; border-radius: 4px; margin-top: 10px; display: none;">
                </div>
                
                <button type="submit" style="padding: 12px 24px; background: #2c3e2d; color: white; border: none; border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; transition: all 0.3s;" onmouseover="this.style.background='#1a2e1b'; this.style.transform='translateY(-2px)'; this.style.boxShadow='0 4px 8px rgba(44, 62, 45, 0.3)';" onmouseout="this.style.background='#2c3e2d'; this.style.transform=''; this.style.boxShadow='';">Save Signature</button>
            </form>
            
            <?php if (!empty($settings['signatures'])): ?>
                <div style="margin-top: 30px; padding-top: 30px; border-top: 2px solid #e0e0e0;">
                    <h3 style="font-size: 20px; font-weight: 800; color: #2c3e2d; margin-bottom: 15px; letter-spacing: -0.2px;">Saved Signatures</h3>
                    <?php foreach ($settings['signatures'] as $key => $value): ?>
                        <?php if (strpos($key, '_image') === false): ?>
                            <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; margin-bottom: 10px;">
                                <strong style="color: #2c3e2d; font-weight: 800; font-size: 14px;"><?php echo htmlspecialchars(ucfirst(str_replace('_', ' ', $key))); ?>:</strong>
                                <span style="color: #6b7280; font-size: 14px; font-weight: 500; margin-left: 8px;"><?php echo htmlspecialchars($value); ?></span>
                                <?php if (isset($settings['signatures'][$key . '_image'])): ?>
                                    <br><img src="../<?php echo htmlspecialchars($settings['signatures'][$key . '_image']); ?>" style="max-width: 200px; max-height: 100px; border: 2px solid #e0e0e0; border-radius: 4px; margin-top: 10px;">
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Add/Edit Official Modal -->
    <div id="editOfficialModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Edit Official</h2>
                <button class="close-modal" onclick="closeEditModal()">
                    <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
            <form id="editOfficialForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" id="formAction" value="edit_official">
                <input type="hidden" name="id" id="editOfficialId">
                
                <div class="photo-preview-container">
                    <img id="editPhotoPreview" class="photo-preview" style="display: none;">
                    <div id="editPhotoPlaceholder" class="photo-preview" style="display: flex; align-items: center; justify-content: center; background: #2c3e2d; color: white; font-size: 48px; font-weight: 700; border-radius: 50%; aspect-ratio: 1 / 1;">?</div>
                </div>

                <div class="form-group">
                    <label for="editName">Full Name *</label>
                    <input type="text" id="editName" name="name" required placeholder="e.g., Hon. Angelina S. Duguran">
                </div>

                <div class="form-group">
                    <label for="editPosition">Position *</label>
                    <select id="editPosition" name="position" required>
                        <option value="">-- Select Position --</option>
                        <?php foreach ($common_positions as $pos): ?>
                            <option value="<?php echo htmlspecialchars($pos); ?>"><?php echo htmlspecialchars($pos); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="editContact">Contact Number</label>
                    <input type="text" id="editContact" name="contact" placeholder="e.g., 09123456789">
                </div>

                <div class="form-group">
                    <label for="editEmail">Email</label>
                    <input type="email" id="editEmail" name="email" placeholder="e.g., official@barangay.gov.ph">
                </div>

                <div class="form-group">
                    <label for="editYearBatch">Year/Batch</label>
                    <input type="text" id="editYearBatch" name="year_batch" placeholder="e.g., 2023-2025, Batch 2023, or 2 years">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Enter term period, batch year, or years in service</small>
                </div>

                <div class="form-group">
                    <label for="editServiceYearStart">Service Year Start</label>
                    <input type="text" id="editServiceYearStart" name="service_year_start" placeholder="e.g., 2023">
                </div>

                <div class="form-group">
                    <label for="editServiceYearEnd">Service Year End</label>
                    <input type="text" id="editServiceYearEnd" name="service_year_end" placeholder="e.g., 2025">
                </div>

                <div class="form-group">
                    <label for="editOrder">Display Order</label>
                    <input type="number" id="editOrder" name="order" value="0" min="0" placeholder="Lower number appears first">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Set order for officials with the same position (0 = default)</small>
                </div>

                <div class="form-group">
                    <label for="editPhoto">Profile Photo</label>
                    <input type="file" id="editPhoto" name="photo" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" onchange="previewEditPhoto(this)">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Max file size: 5MB. Supported formats: JPG, PNG, GIF, WEBP</small>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeEditModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Delete Official Modal -->
    <div id="deleteOfficialModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Delete Official</h2>
                <button class="close-modal" onclick="closeDeleteModal()">
                    <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
            <div class="modal-body">
                <p style="color: #D9534F; font-weight: 600; font-size: 16px; margin-bottom: 12px;">
                    Are you sure you want to permanently remove this official?
                </p>
                <p style="color: #666; margin-bottom: 8px;">
                    Official: <strong id="deleteOfficialName"></strong>
                </p>
                <p style="color: #999; font-size: 12px;">
                    This action will permanently delete the official and cannot be undone.
                </p>
            </div>
            <div class="modal-footer">
                <form method="POST" action="" id="deleteOfficialForm" style="display: inline;">
                    <input type="hidden" name="action" value="delete_official">
                    <input type="hidden" name="id" id="deleteOfficialId">
                    <button type="button" class="btn-reset" onclick="closeDeleteModal()">Cancel</button>
                    <button type="submit" class="btn-delete-modal" style="padding: 10px 20px;">Yes, Delete</button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function previewLogo(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('logoPreview').src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function previewSignature(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('signaturePreview');
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        function openAddModal() {
            const modal = document.getElementById('editOfficialModal');
            const form = document.getElementById('editOfficialForm');
            
            // Set form to create mode
            document.getElementById('formAction').value = 'create_official';
            document.getElementById('modalTitle').textContent = 'Add Official';
            document.getElementById('editOfficialId').value = '';
            
            // Reset form
            form.reset();
            document.getElementById('editPhotoPreview').style.display = 'none';
            document.getElementById('editPhotoPlaceholder').style.display = 'flex';
            document.getElementById('editPhotoPlaceholder').textContent = '?';
            document.getElementById('editOrder').value = '0';
            
            // Show modal
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function openEditModal(official) {
            console.log('Opening edit modal for:', official);
            
            if (!official) {
                console.error('No official data provided');
                return;
            }
            
            const modal = document.getElementById('editOfficialModal');
            if (!modal) {
                console.error('Modal element not found');
                return;
            }
            
            // Set form to edit mode
            document.getElementById('formAction').value = 'edit_official';
            document.getElementById('modalTitle').textContent = 'Edit Official';
            
            // Populate form fields
            document.getElementById('editOfficialId').value = official.id || '';
            document.getElementById('editName').value = official.name || '';
            document.getElementById('editPosition').value = official.position || '';
            document.getElementById('editContact').value = official.contact || '';
            document.getElementById('editEmail').value = official.email || '';
            document.getElementById('editYearBatch').value = official.year_batch || '';
            document.getElementById('editServiceYearStart').value = official.service_year_start || '';
            document.getElementById('editServiceYearEnd').value = official.service_year_end || '';
            document.getElementById('editOrder').value = official.order || 0;
            
            // Handle photo preview
            const photoPreview = document.getElementById('editPhotoPreview');
            const photoPlaceholder = document.getElementById('editPhotoPlaceholder');
            
            if (official.photo && official.photo.trim() !== '') {
                photoPreview.src = '../' + official.photo;
                photoPreview.style.display = 'block';
                photoPlaceholder.style.display = 'none';
            } else {
                photoPreview.style.display = 'none';
                photoPlaceholder.style.display = 'flex';
                photoPlaceholder.textContent = (official.name || '?').charAt(0).toUpperCase();
            }
            
            // Show modal
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
            console.log('Modal class added, modal should be visible now');
        }
        
        function deleteOfficial(id, name) {
            const modal = document.getElementById('deleteOfficialModal');
            document.getElementById('deleteOfficialId').value = id;
            document.getElementById('deleteOfficialName').textContent = name || 'this official';
            
            modal.classList.add('show');
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function closeDeleteModal() {
            const modal = document.getElementById('deleteOfficialModal');
            modal.classList.remove('show');
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
        
        function closeEditModal() {
            const modal = document.getElementById('editOfficialModal');
            modal.classList.remove('show');
            modal.style.display = 'none';
            document.body.style.overflow = ''; // Restore scrolling
            // Reset form
            document.getElementById('editOfficialForm').reset();
            document.getElementById('editPhotoPreview').style.display = 'none';
            document.getElementById('editPhotoPlaceholder').style.display = 'flex';
        }
        
        function previewEditPhoto(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const photoPreview = document.getElementById('editPhotoPreview');
                    const photoPlaceholder = document.getElementById('editPhotoPlaceholder');
                    photoPreview.src = e.target.result;
                    photoPreview.style.display = 'block';
                    photoPlaceholder.style.display = 'none';
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const editModal = document.getElementById('editOfficialModal');
            const deleteModal = document.getElementById('deleteOfficialModal');
            if (event.target === editModal) {
                closeEditModal();
            }
            if (event.target === deleteModal) {
                closeDeleteModal();
            }
        }
        
        // Add event listeners to all edit buttons
        document.addEventListener('DOMContentLoaded', function() {
            console.log('DOM loaded, setting up edit buttons');
            const editButtons = document.querySelectorAll('.edit-official-btn');
            console.log('Found edit buttons:', editButtons.length);
            
            editButtons.forEach(function(button) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    console.log('Edit button clicked');
                    
                    const officialData = this.getAttribute('data-official');
                    console.log('Official data:', officialData);
                    
                    if (officialData) {
                        try {
                            const official = JSON.parse(officialData);
                            console.log('Parsed official:', official);
                            openEditModal(official);
                        } catch (e) {
                            console.error('Error parsing official data:', e);
                            alert('Error loading official data. Please try again.');
                        }
                    } else {
                        console.error('No official data found in data attribute');
                    }
                });
            });
        });

        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>

