<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

require __DIR__ . '/../config.php';
require __DIR__ . '/role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit;
}

$admin_id = $_SESSION['user_id'];

// Fetch admin profile
$stmt = $pdo->prepare("SELECT full_name, email, photo FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Get admin role
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin_role_data = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin_role_data['role']) ? $admin_role_data['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Barangay Dashboard Data File
$data_dir = __DIR__ . '/../data';
if (!is_dir($data_dir)) {
    mkdir($data_dir, 0777, true);
}
$barangay_data_file = $data_dir . '/barangay_dashboard_data.json';

// Default data structure
$default_data = [
    'barangay_name' => 'Barangay San Vicente II',
    'location' => [
        'municipality' => 'Silang',
        'province' => 'Cavite',
        'region' => 'IV-A',
        'district' => 'District V'
    ],
    'vision' => 'Barangay San Vicente II aims to become one of the progressive barangays in Silang, Cavite with civilized, God-fearing citizens with excellent social knowledge, maintaining economic and social environmental conditions for the community that is free from poverty, pollution, and crimes under decent and strong leadership.',
    'mission' => 'To help the constituents in every possible way for the problems of the Barangay. And to develop basic social services for the citizens and to provide social, economic, environmental, and infrastructure assistance under the spirit of transparency and good governance.',
    'mithiin' => 'To have preparation for possible calamities and disasters. And to be responsible for our environment and teach residents what they should do during disasters.',
    'layunin' => 'To help in providing information on proper preparation for calamities that may come to the residents of Barangay San Vicente II, and to give sufficient knowledge to the residents about disasters.',
    'statistics' => [
        'population' => '5,140',
        'hectares' => '91.35',
        'households' => '1,717',
        'puroks' => '7',
        'sitios' => '2',
        'precincts' => '14'
    ],
    'boundaries' => [
        'north' => 'Barangay Biga 1',
        'south' => 'Barangay San Miguel 1',
        'east' => 'Barangay San Vicente 1',
        'west' => 'Barangay Paligawan'
    ],
    'land_classification' => [
        'Residensyal' => '85 ha',
        'Pang-Komersiyo' => '2 ha',
        'Agrikultura' => '1.15 ha',
        'Idle Land' => '1.20 ha',
        'Pang Turismo' => '2 ha'
    ],
    'classification' => 'Rural',
    'quick_facts' => [
        'registered_voters' => '2,444',
        'distance_from_town' => '~300 km',
        'hotline' => '0905-880-0153'
    ],
    'population_by_gender' => [
        'female' => '2,573 (33 with disabilities)',
        'male' => '2,567 (45 with disabilities)',
        'total_disabilities' => '78'
    ],
    'age_distribution' => [
        '0-11_months' => '441',
        '1-17_years' => '1,062',
        '18-59_years' => '3,292',
        '60_plus_years' => '345'
    ],
    'religion' => [
        'Romano Katoliko' => '80%',
        'Iglesia ni Cristo' => '10%',
        'Protestante' => '4%',
        'Baptist' => '2%',
        'Saksi ni Jehova' => '2%',
        'Christian Born Again' => '1%',
        'Iba pa' => '1%'
    ],
    'history_culture' => [
        'original_name' => 'Brgy. Canario',
        'patron_saint' => 'San Vicente Ferrer y Miguel',
        'pista' => 'February 1-3 (with Silang), April 5 (Patron Saint)',
        'established' => '1991 (divided from San Vicente 1)'
    ],
    'infrastructure' => [
        'Electricity' => '1,717 households',
        'Water (Level 3)' => '1,717 households',
        'Garbage Collection' => '1,717 households',
        'Landline' => '300 households',
        'Cable' => '700 households',
        'Transportation' => '90% coverage'
    ],
    'services' => [
        'Health Center' => '20 sq.m. (Tue, Wed, Thu)',
        'Nutrition Center' => '20 sq.m. (Wed, Fri)',
        'Day Care' => 'RIC-CC (30 students)',
        'Schools' => '2 Private (Casa Real, PLO Global)'
    ]
];

// Load existing data or use defaults
$barangay_data = $default_data;
if (file_exists($barangay_data_file)) {
    $loaded = json_decode(file_get_contents($barangay_data_file), true);
    if (is_array($loaded)) {
        $barangay_data = array_merge($default_data, $loaded);
    }
}

// Handle POST requests for updating data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_barangay_data') {
    $section = $_POST['section'] ?? '';
    
    if ($section === 'location') {
        $barangay_data['location']['municipality'] = trim($_POST['municipality'] ?? '');
        $barangay_data['location']['province'] = trim($_POST['province'] ?? '');
        $barangay_data['location']['region'] = trim($_POST['region'] ?? '');
        $barangay_data['location']['district'] = trim($_POST['district'] ?? '');
    } elseif ($section === 'vision') {
        $barangay_data['vision'] = trim($_POST['vision'] ?? '');
    } elseif ($section === 'mission') {
        $barangay_data['mission'] = trim($_POST['mission'] ?? '');
    } elseif ($section === 'mithiin') {
        $barangay_data['mithiin'] = trim($_POST['mithiin'] ?? '');
    } elseif ($section === 'layunin') {
        $barangay_data['layunin'] = trim($_POST['layunin'] ?? '');
    } elseif ($section === 'statistics') {
        $barangay_data['statistics']['population'] = trim($_POST['population'] ?? '');
        $barangay_data['statistics']['hectares'] = trim($_POST['hectares'] ?? '');
        $barangay_data['statistics']['households'] = trim($_POST['households'] ?? '');
        $barangay_data['statistics']['puroks'] = trim($_POST['puroks'] ?? '');
        $barangay_data['statistics']['sitios'] = trim($_POST['sitios'] ?? '');
        $barangay_data['statistics']['precincts'] = trim($_POST['precincts'] ?? '');
    } elseif ($section === 'boundaries') {
        $barangay_data['boundaries']['north'] = trim($_POST['north'] ?? '');
        $barangay_data['boundaries']['south'] = trim($_POST['south'] ?? '');
        $barangay_data['boundaries']['east'] = trim($_POST['east'] ?? '');
        $barangay_data['boundaries']['west'] = trim($_POST['west'] ?? '');
    } elseif ($section === 'land_classification') {
        $barangay_data['land_classification'] = [];
        if (isset($_POST['land_class']) && is_array($_POST['land_class'])) {
            foreach ($_POST['land_class'] as $key => $value) {
                $barangay_data['land_classification'][$key] = trim($value);
            }
        }
    } elseif ($section === 'classification') {
        $barangay_data['classification'] = trim($_POST['classification'] ?? '');
    } elseif ($section === 'quick_facts') {
        $barangay_data['quick_facts']['registered_voters'] = trim($_POST['registered_voters'] ?? '');
        $barangay_data['quick_facts']['distance_from_town'] = trim($_POST['distance_from_town'] ?? '');
        $barangay_data['quick_facts']['hotline'] = trim($_POST['hotline'] ?? '');
    } elseif ($section === 'population_by_gender') {
        $barangay_data['population_by_gender']['female'] = trim($_POST['female'] ?? '');
        $barangay_data['population_by_gender']['male'] = trim($_POST['male'] ?? '');
        $barangay_data['population_by_gender']['total_disabilities'] = trim($_POST['total_disabilities'] ?? '');
    } elseif ($section === 'age_distribution') {
        $barangay_data['age_distribution']['0-11_months'] = trim($_POST['0-11_months'] ?? '');
        $barangay_data['age_distribution']['1-17_years'] = trim($_POST['1-17_years'] ?? '');
        $barangay_data['age_distribution']['18-59_years'] = trim($_POST['18-59_years'] ?? '');
        $barangay_data['age_distribution']['60_plus_years'] = trim($_POST['60_plus_years'] ?? '');
    } elseif ($section === 'religion') {
        $barangay_data['religion'] = [];
        if (isset($_POST['religion']) && is_array($_POST['religion'])) {
            foreach ($_POST['religion'] as $key => $value) {
                $barangay_data['religion'][$key] = trim($value);
            }
        }
    } elseif ($section === 'history_culture') {
        $barangay_data['history_culture']['original_name'] = trim($_POST['original_name'] ?? '');
        $barangay_data['history_culture']['patron_saint'] = trim($_POST['patron_saint'] ?? '');
        $barangay_data['history_culture']['pista'] = trim($_POST['pista'] ?? '');
        $barangay_data['history_culture']['established'] = trim($_POST['established'] ?? '');
    } elseif ($section === 'infrastructure') {
        $barangay_data['infrastructure'] = [];
        if (isset($_POST['infrastructure']) && is_array($_POST['infrastructure'])) {
            foreach ($_POST['infrastructure'] as $key => $value) {
                $barangay_data['infrastructure'][$key] = trim($value);
            }
        }
    } elseif ($section === 'services') {
        $barangay_data['services'] = [];
        if (isset($_POST['services']) && is_array($_POST['services'])) {
            foreach ($_POST['services'] as $key => $value) {
                $barangay_data['services'][$key] = trim($value);
            }
        }
    }
    
    // Save to file
    file_put_contents($barangay_data_file, json_encode($barangay_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    // Reload data
    $loaded = json_decode(file_get_contents($barangay_data_file), true);
    if (is_array($loaded)) {
        $barangay_data = array_merge($default_data, $loaded);
    }
    
    $_SESSION['success'] = 'Barangay information updated successfully!';
    header('Location: admin_barangay_dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Dashboard - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(245, 245, 220, 0.8);
            box-shadow: 0 0 8px rgba(245, 245, 220, 0.4);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        /* Main Content when sidebar is hidden */
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 25px;
            border-radius: 16px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .content-placeholder {
            padding: 60px 40px;
            text-align: center;
            color: #6b7280;
        }
        .content-placeholder h2 {
            font-size: 30px;
            margin-bottom: 12px;
            color: #2c3e2d;
            font-weight: 800;
        }
        .content-placeholder p {
            font-size: 20px;
            font-weight: 600;
            color: #6b7280;
            line-height: 1.6;
        }
        .content-placeholder-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            opacity: 0.3;
            color: #87A96B;
        }
        .content-placeholder-icon svg {
            width: 100%;
            height: 100%;
        }
        /* Bento Grid Layout */
        .bento-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            grid-template-rows: auto auto auto;
            gap: 20px;
            margin-bottom: 20px;
            max-width: 1180px;
        }
        
        /* Left Column - Tall Vertical (Full Height) */
        .bento-left {
            grid-column: 1;
            grid-row: 1 / -1;
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 30px;
            border-radius: 20px;
            border: 1px solid #e5e7eb;
            display: flex;
            flex-direction: column;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .bento-left:hover {
            border-color: #87A96B;
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
            transform: translateY(-2px);
        }
        
        /* Right Column - Top Horizontal */
        .bento-right-top {
            grid-column: 2;
            grid-row: 1;
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 30px;
            border-radius: 20px;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .bento-right-top:hover {
            border-color: #87A96B;
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
            transform: translateY(-2px);
        }
        
        /* Right Column - Middle Square */
        .bento-right-middle {
            grid-column: 2;
            grid-row: 2;
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 30px;
            border-radius: 20px;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .bento-right-middle:hover {
            border-color: #87A96B;
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
            transform: translateY(-2px);
        }
        
        /* Right Column - Bottom Small Horizontal */
        .bento-right-bottom {
            grid-column: 2;
            grid-row: 3;
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 25px 30px;
            border-radius: 20px;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        
        .bento-right-bottom:hover {
            border-color: #87A96B;
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
            transform: translateY(-2px);
        }
        
        /* Bento Card Styles */
        .bento-card-title {
            font-size: 24px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .bento-card-title-icon {
            width: 24px;
            height: 24px;
            color: #87A96B;
        }
        
        .bento-card-content {
            color: #4b5563;
            font-size: 15px;
            line-height: 1.8;
        }
        
        .bento-section {
            margin-bottom: 25px;
        }
        
        .bento-section:last-child {
            margin-bottom: 0;
        }
        
        .bento-section-title {
            font-size: 18px;
            font-weight: 800;
            color: #87A96B;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
        }
        
        .bento-section-content {
            font-size: 18px;
            font-weight: 600;
            color: #4b5563;
            line-height: 1.7;
        }
        
        .bento-section-content p {
            color: #4b5563;
            font-weight: 600;
        }
        
        .bento-section-content strong {
            color: #1f2937;
            font-weight: 800;
        }
        
        .bento-stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }
        
        .bento-stat-item {
            text-align: center;
        }
        
        .bento-stat-value {
            font-size: 40px;
            font-weight: 800;
            color: #000000;
            margin-bottom: 5px;
        }
        
        .bento-stat-label {
            font-size: 16px;
            font-weight: 700;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .bento-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .bento-list-item {
            padding: 8px 0;
            color: #4b5563;
            font-size: 18px;
            font-weight: 600;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
        }
        
        .bento-list-item:last-child {
            border-bottom: none;
        }
        
        .bento-list-item strong {
            color: #1f2937;
            font-weight: 800;
        }
        
        .bento-badge {
            display: inline-block;
            padding: 6px 14px;
            background: rgba(135, 169, 107, 0.1);
            color: #87A96B;
            border: 1px solid rgba(135, 169, 107, 0.2);
            border-radius: 12px;
            font-size: 16px;
            font-weight: 800;
            margin-right: 8px;
            margin-bottom: 8px;
        }
        
        /* Summary Grid (for additional sections) */
        .summary-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .summary-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 25px;
            border-radius: 20px;
            border: 1px solid #e5e7eb;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }
        .summary-card:hover {
            border-color: #87A96B;
            box-shadow: 0 4px 12px rgba(135, 169, 107, 0.15);
            transform: translateY(-2px);
        }
        .summary-card-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 16px;
        }
        .summary-card-icon {
            width: 40px;
            height: 40px;
            background: rgba(135, 169, 107, 0.1);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: #87A96B;
        }
        .summary-card-icon svg {
            width: 24px;
            height: 24px;
        }
        .summary-card-title {
            font-size: 18px;
            font-weight: 800;
            color: #1f2937;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .summary-card-content {
            color: #4b5563;
            font-size: 18px;
            font-weight: 600;
            line-height: 1.6;
        }
        .summary-card-value {
            font-size: 30px;
            font-weight: 800;
            color: #87A96B;
            margin-bottom: 8px;
        }
        .summary-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .summary-list li {
            padding: 6px 0;
            color: #4b5563;
            font-size: 18px;
            font-weight: 600;
            border-bottom: 1px solid #e5e7eb;
        }
        .summary-list li:last-child {
            border-bottom: none;
        }
        .summary-list li strong {
            color: #1f2937;
            font-weight: 800;
        }
        .purok-list {
            margin-top: 8px;
        }
        .purok-list-item {
            padding: 4px 0;
            color: #4b5563;
            font-size: 14px;
        }
        @media (max-width: 1024px) {
            .bento-grid {
                grid-template-columns: 1fr;
                grid-template-rows: auto;
            }
            .bento-left {
                grid-column: 1;
                grid-row: 1;
            }
            .bento-right-top {
                grid-column: 1;
                grid-row: 2;
            }
            .bento-right-middle {
                grid-column: 1;
                grid-row: 3;
            }
            .bento-right-bottom {
                grid-column: 1;
                grid-row: 4;
            }
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .summary-grid {
                grid-template-columns: 1fr;
            }
            .bento-stats-grid {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            .bento-right-bottom > div {
                grid-template-columns: 1fr !important;
            }
        }
        
        /* Edit Button Styles */
        .edit-btn {
            background: #87A96B;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            margin-top: 10px;
        }
        .edit-btn:hover {
            background: #7a9660;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(135, 169, 107, 0.3);
        }
        .edit-btn svg {
            width: 14px;
            height: 14px;
        }
        .bento-section-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .summary-card-header {
            position: relative;
        }
        .summary-card-edit-btn {
            position: absolute;
            top: 0;
            right: 0;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 30px;
            border: 1px solid #888;
            border-radius: 12px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e5e7eb;
        }
        .modal-header h2 {
            font-size: 24px;
            font-weight: 800;
            color: #2c3e2d;
            margin: 0;
        }
        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.3s;
        }
        .close:hover,
        .close:focus {
            color: #000;
        }
        .modal-body {
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 600;
            font-size: 14px;
        }
        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            font-family: inherit;
        }
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        .form-group-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 2px solid #e5e7eb;
        }
        .btn-primary {
            background: #2c3e2d;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-primary:hover {
            background: #1a2e1b;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
        }
        .btn-secondary {
            background: #6b7280;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-secondary:hover {
            background: #4b5563;
        }
        .success-message {
            background: #d1fae5;
            color: #065f46;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            border: 1px solid #6ee7b7;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 3000;
            max-width: 400px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            animation: slideIn 0.3s ease-out;
        }
        @keyframes slideIn {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="7" height="7"></rect>
                    <rect x="14" y="3" width="7" height="7"></rect>
                    <rect x="14" y="14" width="7" height="7"></rect>
                    <rect x="3" y="14" width="7" height="7"></rect>
                </svg>
            </span>
            Barangay Dashboard
        </h1>

        <!-- Modern Bento Grid Layout -->
        <div class="row-container">
            <div class="bento-grid">
                <!-- Left Column: Overview & Vision/Mission (Tall Vertical) -->
                <div class="bento-left">
                    <h2 class="bento-card-title">
                        <svg class="bento-card-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                            <circle cx="12" cy="10" r="3"></circle>
                        </svg>
                        <?php echo htmlspecialchars($barangay_data['barangay_name']); ?>
                    </h2>
                    
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Location</span>
                            <button class="edit-btn" onclick="openEditModal('location')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <p><strong>Bayan/Lungsod:</strong> <?php echo htmlspecialchars($barangay_data['location']['municipality']); ?></p>
                            <p><strong>Lalawigan:</strong> <?php echo htmlspecialchars($barangay_data['location']['province']); ?></p>
                            <p><strong>Rehiyon:</strong> <?php echo htmlspecialchars($barangay_data['location']['region']); ?></p>
                            <p><strong>Distrito:</strong> <?php echo htmlspecialchars($barangay_data['location']['district']); ?></p>
                        </div>
                    </div>
                    
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Vision</span>
                            <button class="edit-btn" onclick="openEditModal('vision')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <?php echo htmlspecialchars($barangay_data['vision']); ?>
                        </div>
                    </div>
                    
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Mission</span>
                            <button class="edit-btn" onclick="openEditModal('mission')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <?php echo htmlspecialchars($barangay_data['mission']); ?>
                        </div>
                    </div>
                    
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Mithiin</span>
                            <button class="edit-btn" onclick="openEditModal('mithiin')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <?php echo htmlspecialchars($barangay_data['mithiin']); ?>
                        </div>
                    </div>
                    
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Objectives</span>
                            <button class="edit-btn" onclick="openEditModal('layunin')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <?php echo htmlspecialchars($barangay_data['layunin']); ?>
                        </div>
                    </div>
                </div>
                
                <!-- Right Top: Key Statistics (Horizontal) -->
                <div class="bento-right-top">
                    <h2 class="bento-card-title" style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="display: flex; align-items: center; gap: 10px;">
                            <svg class="bento-card-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="12" y1="20" x2="12" y2="10"></line>
                                <line x1="18" y1="20" x2="18" y2="4"></line>
                                <line x1="6" y1="20" x2="6" y2="16"></line>
                            </svg>
                            Key Statistics
                        </span>
                        <button class="edit-btn" onclick="openEditModal('statistics')">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </h2>
                    <div class="bento-stats-grid">
                        <div class="bento-stat-item">
                            <div class="bento-stat-value"><?php echo htmlspecialchars($barangay_data['statistics']['population']); ?></div>
                            <div class="bento-stat-label">Population</div>
                        </div>
                        <div class="bento-stat-item">
                            <div class="bento-stat-value"><?php echo htmlspecialchars($barangay_data['statistics']['hectares']); ?></div>
                            <div class="bento-stat-label">Hectares</div>
                        </div>
                        <div class="bento-stat-item">
                            <div class="bento-stat-value"><?php echo htmlspecialchars($barangay_data['statistics']['households']); ?></div>
                            <div class="bento-stat-label">Households</div>
                        </div>
                    </div>
                    <div style="margin-top: 25px; padding-top: 25px; border-top: 1px solid #e5e7eb;">
                        <div class="bento-stats-grid">
                            <div class="bento-stat-item">
                                <div class="bento-stat-value"><?php echo htmlspecialchars($barangay_data['statistics']['puroks']); ?></div>
                                <div class="bento-stat-label">Puroks</div>
                            </div>
                            <div class="bento-stat-item">
                                <div class="bento-stat-value"><?php echo htmlspecialchars($barangay_data['statistics']['sitios']); ?></div>
                                <div class="bento-stat-label">Sitios</div>
                            </div>
                            <div class="bento-stat-item">
                                <div class="bento-stat-value"><?php echo htmlspecialchars($barangay_data['statistics']['precincts']); ?></div>
                                <div class="bento-stat-label">Precincts</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Right Middle: Geographical Information (Square) -->
                <div class="bento-right-middle">
                    <h2 class="bento-card-title" style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="display: flex; align-items: center; gap: 10px;">
                            <svg class="bento-card-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="9" y1="3" x2="9" y2="21"></line>
                                <line x1="3" y1="9" x2="21" y2="9"></line>
                            </svg>
                            Geographical Information
                        </span>
                    </h2>
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Boundaries</span>
                            <button class="edit-btn" onclick="openEditModal('boundaries')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <ul class="bento-list">
                                <li><strong>Hilaga (North):</strong> <?php echo htmlspecialchars($barangay_data['boundaries']['north']); ?></li>
                                <li><strong>Timog (South):</strong> <?php echo htmlspecialchars($barangay_data['boundaries']['south']); ?></li>
                                <li><strong>Silangan (East):</strong> <?php echo htmlspecialchars($barangay_data['boundaries']['east']); ?></li>
                                <li><strong>Kanluran (West):</strong> <?php echo htmlspecialchars($barangay_data['boundaries']['west']); ?></li>
                            </ul>
                        </div>
                    </div>
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Land Classification</span>
                            <button class="edit-btn" onclick="openEditModal('land_classification')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <?php foreach ($barangay_data['land_classification'] as $type => $value): ?>
                                <span class="bento-badge"><?php echo htmlspecialchars($type); ?>: <?php echo htmlspecialchars($value); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="bento-section">
                        <div class="bento-section-title">
                            <span>Classification</span>
                            <button class="edit-btn" onclick="openEditModal('classification')">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                </svg>
                                Edit
                            </button>
                        </div>
                        <div class="bento-section-content">
                            <span class="bento-badge" style="background: rgba(135, 169, 107, 0.2);"><?php echo htmlspecialchars($barangay_data['classification']); ?></span>
                        </div>
                    </div>
                </div>
                
                <!-- Right Bottom: Quick Facts (Small Horizontal) -->
                <div class="bento-right-bottom">
                    <h2 class="bento-card-title" style="font-size: 16px; margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
                        <span style="display: flex; align-items: center; gap: 8px;">
                            <svg class="bento-card-title-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 20px; height: 20px;">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="12" y1="16" x2="12" y2="12"></line>
                                <line x1="12" y1="8" x2="12.01" y2="8"></line>
                            </svg>
                            Quick Facts
                        </span>
                        <button class="edit-btn" onclick="openEditModal('quick_facts')" style="font-size: 11px; padding: 6px 12px;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width: 12px; height: 12px;">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </h2>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px;">
                        <div>
                            <div style="font-size: 12px; color: #6b7280; margin-bottom: 5px;">Registered Voters</div>
                            <div style="font-size: 20px; font-weight: 700; color: #000000;"><?php echo htmlspecialchars($barangay_data['quick_facts']['registered_voters']); ?></div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: #6b7280; margin-bottom: 5px;">Distance from Town</div>
                            <div style="font-size: 20px; font-weight: 700; color: #000000;"><?php echo htmlspecialchars($barangay_data['quick_facts']['distance_from_town']); ?></div>
                        </div>
                        <div>
                            <div style="font-size: 12px; color: #6b7280; margin-bottom: 5px;">Hotline</div>
                            <div style="font-size: 16px; font-weight: 700; color: #000000;"><?php echo htmlspecialchars($barangay_data['quick_facts']['hotline']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Additional Information Sections -->
        <div class="row-container">
            <div class="summary-grid">
                <!-- Population Details Card -->
                <div class="summary-card">
                    <div class="summary-card-header">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div class="summary-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                                    <circle cx="9" cy="7" r="4"></circle>
                                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                                </svg>
                            </div>
                            <div class="summary-card-title">Population by Gender</div>
                        </div>
                        <button class="edit-btn" onclick="openEditModal('population_by_gender')" style="margin-top: 0;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </div>
                    <div class="summary-card-content">
                        <ul class="summary-list">
                            <li><strong>Female:</strong> <?php echo htmlspecialchars($barangay_data['population_by_gender']['female']); ?></li>
                            <li><strong>Male:</strong> <?php echo htmlspecialchars($barangay_data['population_by_gender']['male']); ?></li>
                            <li><strong>Total with Disabilities:</strong> <?php echo htmlspecialchars($barangay_data['population_by_gender']['total_disabilities']); ?></li>
                        </ul>
                    </div>
                </div>

                <!-- Age Distribution Card -->
                <div class="summary-card">
                    <div class="summary-card-header">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div class="summary-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <polyline points="12 6 12 12 16 14"></polyline>
                                </svg>
                            </div>
                            <div class="summary-card-title">Age Distribution</div>
                        </div>
                        <button class="edit-btn" onclick="openEditModal('age_distribution')" style="margin-top: 0;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </div>
                    <div class="summary-card-content">
                        <ul class="summary-list">
                            <li><strong>0-11 months:</strong> <?php echo htmlspecialchars($barangay_data['age_distribution']['0-11_months']); ?></li>
                            <li><strong>1-17 years:</strong> <?php echo htmlspecialchars($barangay_data['age_distribution']['1-17_years']); ?></li>
                            <li><strong>18-59 years:</strong> <?php echo htmlspecialchars($barangay_data['age_distribution']['18-59_years']); ?></li>
                            <li><strong>60+ years:</strong> <?php echo htmlspecialchars($barangay_data['age_distribution']['60_plus_years']); ?></li>
                        </ul>
                    </div>
                </div>

                <!-- Religion Card -->
                <div class="summary-card">
                    <div class="summary-card-header">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div class="summary-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>
                                </svg>
                            </div>
                            <div class="summary-card-title">Religion</div>
                        </div>
                        <button class="edit-btn" onclick="openEditModal('religion')" style="margin-top: 0;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </div>
                    <div class="summary-card-content">
                        <ul class="summary-list">
                            <?php foreach ($barangay_data['religion'] as $religion => $percentage): ?>
                                <li><strong><?php echo htmlspecialchars($religion); ?>:</strong> <?php echo htmlspecialchars($percentage); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <!-- History & Culture Card -->
                <div class="summary-card">
                    <div class="summary-card-header">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div class="summary-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
                                    <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
                                </svg>
                            </div>
                            <div class="summary-card-title">History & Culture</div>
                        </div>
                        <button class="edit-btn" onclick="openEditModal('history_culture')" style="margin-top: 0;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </div>
                    <div class="summary-card-content">
                        <p style="margin-bottom: 12px;"><strong>Original Name:</strong> <?php echo htmlspecialchars($barangay_data['history_culture']['original_name']); ?></p>
                        <p style="margin-bottom: 12px;"><strong>Patron Saint:</strong> <?php echo htmlspecialchars($barangay_data['history_culture']['patron_saint']); ?></p>
                        <p style="margin-bottom: 12px;"><strong>Pista:</strong> <?php echo htmlspecialchars($barangay_data['history_culture']['pista']); ?></p>
                        <p><strong>Established:</strong> <?php echo htmlspecialchars($barangay_data['history_culture']['established']); ?></p>
                    </div>
                </div>

                <!-- Infrastructure Card -->
                <div class="summary-card">
                    <div class="summary-card-header">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div class="summary-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                                </svg>
                            </div>
                            <div class="summary-card-title">Infrastructure</div>
                        </div>
                        <button class="edit-btn" onclick="openEditModal('infrastructure')" style="margin-top: 0;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </div>
                    <div class="summary-card-content">
                        <ul class="summary-list">
                            <?php foreach ($barangay_data['infrastructure'] as $item => $value): ?>
                                <li><strong><?php echo htmlspecialchars($item); ?>:</strong> <?php echo htmlspecialchars($value); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <!-- Services Card -->
                <div class="summary-card">
                    <div class="summary-card-header">
                        <div style="display: flex; align-items: center; gap: 12px; flex: 1;">
                            <div class="summary-card-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg>
                            </div>
                            <div class="summary-card-title">Services</div>
                        </div>
                        <button class="edit-btn" onclick="openEditModal('services')" style="margin-top: 0;">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                            Edit
                        </button>
                    </div>
                    <div class="summary-card-content">
                        <ul class="summary-list">
                            <?php foreach ($barangay_data['services'] as $service => $value): ?>
                                <li><strong><?php echo htmlspecialchars($service); ?>:</strong> <?php echo htmlspecialchars($value); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </div>
    
    <!-- Success Message -->
    <?php if (isset($_SESSION['success'])): ?>
        <div class="success-message">
            <?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?>
        </div>
        <script>
            setTimeout(function() {
                const msg = document.querySelector('.success-message');
                if (msg) {
                    msg.style.animation = 'slideIn 0.3s ease-out reverse';
                    setTimeout(function() {
                        msg.style.display = 'none';
                    }, 300);
                }
            }, 3000);
        </script>
    <?php endif; ?>
    
    <!-- Edit Modals -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Edit Information</h2>
                <span class="close" onclick="closeEditModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form id="editForm" method="POST">
                    <input type="hidden" name="action" value="update_barangay_data">
                    <input type="hidden" name="section" id="modalSection">
                    <div id="modalFormContent"></div>
                    <div class="form-actions">
                        <button type="button" class="btn-secondary" onclick="closeEditModal()">Cancel</button>
                        <button type="submit" class="btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Barangay data from PHP
        const barangayData = <?php echo json_encode($barangay_data, JSON_UNESCAPED_UNICODE); ?>;
        
        function openEditModal(section) {
            const modal = document.getElementById('editModal');
            const modalTitle = document.getElementById('modalTitle');
            const modalSection = document.getElementById('modalSection');
            const modalFormContent = document.getElementById('modalFormContent');
            
            modalSection.value = section;
            modal.style.display = 'block';
            
            let title = '';
            let formHTML = '';
            
            switch(section) {
                case 'location':
                    title = 'Edit Location';
                    formHTML = `
                        <div class="form-group">
                            <label>Bayan/Lungsod</label>
                            <input type="text" name="municipality" value="${barangayData.location.municipality}" required>
                        </div>
                        <div class="form-group">
                            <label>Lalawigan</label>
                            <input type="text" name="province" value="${barangayData.location.province}" required>
                        </div>
                        <div class="form-group">
                            <label>Rehiyon</label>
                            <input type="text" name="region" value="${barangayData.location.region}" required>
                        </div>
                        <div class="form-group">
                            <label>Distrito</label>
                            <input type="text" name="district" value="${barangayData.location.district}" required>
                        </div>
                    `;
                    break;
                case 'vision':
                    title = 'Edit Vision';
                    formHTML = `
                        <div class="form-group">
                            <label>Vision</label>
                            <textarea name="vision" required>${barangayData.vision}</textarea>
                        </div>
                    `;
                    break;
                case 'mission':
                    title = 'Edit Mission';
                    formHTML = `
                        <div class="form-group">
                            <label>Mission</label>
                            <textarea name="mission" required>${barangayData.mission}</textarea>
                        </div>
                    `;
                    break;
                case 'mithiin':
                    title = 'Edit Mithiin';
                    formHTML = `
                        <div class="form-group">
                            <label>Mithiin</label>
                            <textarea name="mithiin" required>${barangayData.mithiin}</textarea>
                        </div>
                    `;
                    break;
                case 'layunin':
                    title = 'Edit Objectives';
                    formHTML = `
                        <div class="form-group">
                            <label>Objectives</label>
                            <textarea name="layunin" required>${barangayData.layunin}</textarea>
                        </div>
                    `;
                    break;
                case 'statistics':
                    title = 'Edit Statistics';
                    formHTML = `
                        <div class="form-group-row">
                            <div class="form-group">
                                <label>Population</label>
                                <input type="text" name="population" value="${barangayData.statistics.population}" required>
                            </div>
                            <div class="form-group">
                                <label>Hectares</label>
                                <input type="text" name="hectares" value="${barangayData.statistics.hectares}" required>
                            </div>
                        </div>
                        <div class="form-group-row">
                            <div class="form-group">
                                <label>Households</label>
                                <input type="text" name="households" value="${barangayData.statistics.households}" required>
                            </div>
                            <div class="form-group">
                                <label>Puroks</label>
                                <input type="text" name="puroks" value="${barangayData.statistics.puroks}" required>
                            </div>
                        </div>
                        <div class="form-group-row">
                            <div class="form-group">
                                <label>Sitios</label>
                                <input type="text" name="sitios" value="${barangayData.statistics.sitios}" required>
                            </div>
                            <div class="form-group">
                                <label>Precincts</label>
                                <input type="text" name="precincts" value="${barangayData.statistics.precincts}" required>
                            </div>
                        </div>
                    `;
                    break;
                case 'boundaries':
                    title = 'Edit Boundaries';
                    formHTML = `
                        <div class="form-group">
                            <label>Hilaga (North)</label>
                            <input type="text" name="north" value="${barangayData.boundaries.north}" required>
                        </div>
                        <div class="form-group">
                            <label>Timog (South)</label>
                            <input type="text" name="south" value="${barangayData.boundaries.south}" required>
                        </div>
                        <div class="form-group">
                            <label>Silangan (East)</label>
                            <input type="text" name="east" value="${barangayData.boundaries.east}" required>
                        </div>
                        <div class="form-group">
                            <label>Kanluran (West)</label>
                            <input type="text" name="west" value="${barangayData.boundaries.west}" required>
                        </div>
                    `;
                    break;
                case 'land_classification':
                    title = 'Edit Land Classification';
                    formHTML = Object.keys(barangayData.land_classification).map(key => `
                        <div class="form-group">
                            <label>${key}</label>
                            <input type="text" name="land_class[${key}]" value="${barangayData.land_classification[key]}" required>
                        </div>
                    `).join('');
                    break;
                case 'classification':
                    title = 'Edit Classification';
                    formHTML = `
                        <div class="form-group">
                            <label>Classification</label>
                            <input type="text" name="classification" value="${barangayData.classification}" required>
                        </div>
                    `;
                    break;
                case 'quick_facts':
                    title = 'Edit Quick Facts';
                    formHTML = `
                        <div class="form-group">
                            <label>Registered Voters</label>
                            <input type="text" name="registered_voters" value="${barangayData.quick_facts.registered_voters}" required>
                        </div>
                        <div class="form-group">
                            <label>Distance from Town</label>
                            <input type="text" name="distance_from_town" value="${barangayData.quick_facts.distance_from_town}" required>
                        </div>
                        <div class="form-group">
                            <label>Hotline</label>
                            <input type="text" name="hotline" value="${barangayData.quick_facts.hotline}" required>
                        </div>
                    `;
                    break;
                case 'population_by_gender':
                    title = 'Edit Population by Gender';
                    formHTML = `
                        <div class="form-group">
                            <label>Female</label>
                            <input type="text" name="female" value="${barangayData.population_by_gender.female}" required>
                        </div>
                        <div class="form-group">
                            <label>Male</label>
                            <input type="text" name="male" value="${barangayData.population_by_gender.male}" required>
                        </div>
                        <div class="form-group">
                            <label>Total with Disabilities</label>
                            <input type="text" name="total_disabilities" value="${barangayData.population_by_gender.total_disabilities}" required>
                        </div>
                    `;
                    break;
                case 'age_distribution':
                    title = 'Edit Age Distribution';
                    formHTML = `
                        <div class="form-group">
                            <label>0-11 months</label>
                            <input type="text" name="0-11_months" value="${barangayData.age_distribution['0-11_months']}" required>
                        </div>
                        <div class="form-group">
                            <label>1-17 years</label>
                            <input type="text" name="1-17_years" value="${barangayData.age_distribution['1-17_years']}" required>
                        </div>
                        <div class="form-group">
                            <label>18-59 years</label>
                            <input type="text" name="18-59_years" value="${barangayData.age_distribution['18-59_years']}" required>
                        </div>
                        <div class="form-group">
                            <label>60+ years</label>
                            <input type="text" name="60_plus_years" value="${barangayData.age_distribution['60_plus_years']}" required>
                        </div>
                    `;
                    break;
                case 'religion':
                    title = 'Edit Religion';
                    formHTML = Object.keys(barangayData.religion).map(key => `
                        <div class="form-group">
                            <label>${key}</label>
                            <input type="text" name="religion[${key}]" value="${barangayData.religion[key]}" required>
                        </div>
                    `).join('');
                    break;
                case 'history_culture':
                    title = 'Edit History & Culture';
                    formHTML = `
                        <div class="form-group">
                            <label>Original Name</label>
                            <input type="text" name="original_name" value="${barangayData.history_culture.original_name}" required>
                        </div>
                        <div class="form-group">
                            <label>Patron Saint</label>
                            <input type="text" name="patron_saint" value="${barangayData.history_culture.patron_saint}" required>
                        </div>
                        <div class="form-group">
                            <label>Pista</label>
                            <input type="text" name="pista" value="${barangayData.history_culture.pista}" required>
                        </div>
                        <div class="form-group">
                            <label>Established</label>
                            <input type="text" name="established" value="${barangayData.history_culture.established}" required>
                        </div>
                    `;
                    break;
                case 'infrastructure':
                    title = 'Edit Infrastructure';
                    formHTML = Object.keys(barangayData.infrastructure).map(key => `
                        <div class="form-group">
                            <label>${key}</label>
                            <input type="text" name="infrastructure[${key}]" value="${barangayData.infrastructure[key]}" required>
                        </div>
                    `).join('');
                    break;
                case 'services':
                    title = 'Edit Services';
                    formHTML = Object.keys(barangayData.services).map(key => `
                        <div class="form-group">
                            <label>${key}</label>
                            <input type="text" name="services[${key}]" value="${barangayData.services[key]}" required>
                        </div>
                    `).join('');
                    break;
            }
            
            modalTitle.textContent = title;
            modalFormContent.innerHTML = formHTML;
        }
        
        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('editModal');
            if (event.target == modal) {
                closeEditModal();
            }
        }
    </script>
</body>
</html>

