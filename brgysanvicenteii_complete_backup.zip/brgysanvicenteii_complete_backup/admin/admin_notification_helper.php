<?php
/**
 * Admin Notification Helper
 * 
 * This helper function creates admin notifications and saves them to admin_notifications.json
 * 
 * @param string $type - Notification type (e.g., 'new_walkin_request', 'admin_added', 'password_changed', etc.)
 * @param string $title - Notification title
 * @param string $message - Notification message
 * @param string $target_role - Who should see this: 'all', 'super_admin', 'regular_admin'
 * @param array $extra_data - Additional data to store with notification
 * @return bool - Returns true if notification was created successfully
 */
function createAdminNotification($type, $title, $message, $target_role = 'all', $extra_data = []) {
    $notifDir = __DIR__ . '/../data/notifications';
    if (!is_dir($notifDir)) {
        mkdir($notifDir, 0777, true);
    }
    
    $adminNotifFile = $notifDir . '/admin_notifications.json';
    
    // Load existing notifications
    $admin_notifications = [];
    if (file_exists($adminNotifFile)) {
        $admin_notifications = json_decode(file_get_contents($adminNotifFile), true) ?? [];
    }
    
    // Create new notification
    $notification = [
        'type' => $type,
        'title' => $title,
        'message' => $message,
        'target_role' => $target_role,
        'created_at' => date('Y-m-d H:i:s'),
        'read' => false
    ];
    
    // Merge extra data
    if (!empty($extra_data)) {
        $notification = array_merge($notification, $extra_data);
    }
    
    // Add to notifications array
    $admin_notifications[] = $notification;
    
    // Save to file
    $result = file_put_contents($adminNotifFile, json_encode($admin_notifications, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    // Send push notification to all admins (or specific admin if specified)
    if ($result !== false) {
        require_once __DIR__ . '/../push_notification_helper.php';
        
        $options = [
            'url' => $extra_data['link'] ?? 'admin/admin_notifications.php',
            'icon' => '/images/logo.jpg',
            'tag' => $type . '_' . ($extra_data['request_id'] ?? time()),
            'id' => $extra_data['request_id'] ?? null,
            'type' => $type
        ];
        
        // If specific admin_id is provided, send only to that admin
        if (isset($extra_data['admin_id'])) {
            sendPushNotification('admin', $extra_data['admin_id'], $title, $message, $options);
        } else {
            // Send to all admins
            sendPushNotificationToAll('admin', $title, $message, $options);
        }
        
        // Also send to workers
        sendPushNotificationToAll('worker', $title, $message, $options);
    }
    
    return $result !== false;
}

/**
 * Example usage:
 * 
 * // When a new walk-in request is created
 * createAdminNotification(
 *     'new_walkin_request',
 *     'New Walk-In Request',
 *     "New Walk-In Request from {$resident_name} – Request #{$request_number}",
 *     'all',
 *     ['request_id' => $request_id, 'request_number' => $request_number, 'resident_name' => $resident_name]
 * );
 * 
 * // When an admin is added (super admin only)
 * createAdminNotification(
 *     'admin_added',
 *     'New Admin Added',
 *     "A new admin account has been created: {$admin_name} ({$admin_email})",
 *     'super_admin',
 *     ['admin_id' => $admin_id, 'admin_name' => $admin_name, 'admin_email' => $admin_email]
 * );
 * 
 * // When password is changed (super admin only)
 * createAdminNotification(
 *     'password_changed',
 *     'Password Changed',
 *     "Password has been changed for admin: {$admin_name}",
 *     'super_admin',
 *     ['admin_id' => $admin_id, 'admin_name' => $admin_name]
 * );
 * 
 * // When a request status is updated (all admins)
 * createAdminNotification(
 *     'request_status_updated',
 *     'Request Status Updated',
 *     "Request #{$request_number} status has been updated to {$status}",
 *     'all',
 *     ['request_id' => $request_id, 'request_number' => $request_number, 'status' => $status]
 * );
 */
?>

