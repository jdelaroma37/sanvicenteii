<?php
// admin/admin_requests_archive.php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

// Start output buffering to catch any errors
ob_start();

try {
    session_start();
    
    // Check if config file exists
    $config_path = __DIR__ . '/../config.php';
    if (!file_exists($config_path)) {
        die("Error: config.php not found at: " . $config_path);
    }
    
    require $config_path;
    
    // Check if PDO connection exists
    if (!isset($pdo)) {
        die("Error: Database connection not established. Please check config.php");
    }
    
    // Check if admin is logged in
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header('Location: admin_login.php');
        exit;
    }
    
    if (!isset($_SESSION['user_id'])) {
        header('Location: admin_login.php');
        exit;
    }
    
    $admin_id = $_SESSION['user_id'];
    $error = $_SESSION['error'] ?? '';
    $success = $_SESSION['success'] ?? '';
    unset($_SESSION['error']);
    unset($_SESSION['success']);
    
    // Get admin role for sidebar
    try {
        $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
        $stmt->execute([$admin_id]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
        $_SESSION['admin_role'] = $admin_role;
    } catch (PDOException $e) {
        $admin_role = 'regular_admin';
        $_SESSION['admin_role'] = $admin_role;
    }
} catch (Exception $e) {
    ob_end_clean();
    die("Fatal Error: " . $e->getMessage() . " in " . $e->getFile() . " on line " . $e->getLine());
}

// File-based monitoring archive (JSON)
$monitoring_requests_dir = __DIR__ . '/../data/requests';
$monitoring_archive_dir = __DIR__ . '/../data/request_archive';
$monitoring_archive_file = $monitoring_archive_dir . '/archived_requests.json';
if (!is_dir($monitoring_archive_dir)) {
    @mkdir($monitoring_archive_dir, 0777, true);
}
$monitoring_archived = [];
if (file_exists($monitoring_archive_file)) {
    $monitoring_archived = json_decode(file_get_contents($monitoring_archive_file), true);
    if (!is_array($monitoring_archived)) {
        $monitoring_archived = [];
    }
}

// Handle restore action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restore') {
    $archive_id = intval($_POST['archive_id'] ?? 0);
    if ($archive_id > 0) {
        try {
            $pdo->beginTransaction();
            
            // Get archived request data
            $stmt = $pdo->prepare("SELECT * FROM walk_in_requests_archive WHERE archive_id = ? AND restored_at IS NULL");
            $stmt->execute([$archive_id]);
            $archived_request = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($archived_request) {
                // Check if original request ID still exists
                $original_id = $archived_request['original_request_id'];
                $stmt = $pdo->prepare("SELECT request_id FROM walk_in_requests WHERE request_id = ?");
                $stmt->execute([$original_id]);
                $existing = $stmt->fetch();
                
                // If original ID exists, update it, otherwise insert as new
                // Restore ALL fields from archive to ensure complete document restoration
                if ($existing) {
                    // Restore to original ID - update ALL fields
                    $restore_sql = "UPDATE walk_in_requests SET 
                        request_number = ?, resident_id = ?, resident_name = ?, resident_email = ?, resident_contact = ?,
                        category = ?, type = ?, description = ?, attachment_url = ?, status = ?, admin_notes = ?,
                        admin_attachment_url = ?, appointment_date = ?, appointment_time = ?, processed_by = ?,
                        created_at = ?, updated_at = ?
                        WHERE request_id = ?";
                    
                    $restore_stmt = $pdo->prepare($restore_sql);
                    $restore_stmt->execute([
                        $archived_request['request_number'],
                        $archived_request['resident_id'],
                        $archived_request['resident_name'],
                        $archived_request['resident_email'],
                        $archived_request['resident_contact'],
                        $archived_request['category'],
                        $archived_request['type'],
                        $archived_request['description'],
                        $archived_request['attachment_url'],
                        $archived_request['status'],
                        $archived_request['admin_notes'],
                        $archived_request['admin_attachment_url'],
                        $archived_request['appointment_date'],
                        $archived_request['appointment_time'],
                        $archived_request['processed_by'],
                        $archived_request['created_at'],
                        $archived_request['updated_at'],
                        $original_id
                    ]);
                } else {
                    // Insert as new record with original ID - insert ALL fields
                    $restore_sql = "INSERT INTO walk_in_requests (
                        request_id, request_number, resident_id, resident_name, resident_email, resident_contact,
                        category, type, description, attachment_url, status, admin_notes, admin_attachment_url,
                        appointment_date, appointment_time, processed_by, created_at, updated_at
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                    )";
                    
                    $restore_stmt = $pdo->prepare($restore_sql);
                    $restore_stmt->execute([
                        $original_id,
                        $archived_request['request_number'],
                        $archived_request['resident_id'],
                        $archived_request['resident_name'],
                        $archived_request['resident_email'],
                        $archived_request['resident_contact'],
                        $archived_request['category'],
                        $archived_request['type'],
                        $archived_request['description'],
                        $archived_request['attachment_url'],
                        $archived_request['status'],
                        $archived_request['admin_notes'],
                        $archived_request['admin_attachment_url'],
                        $archived_request['appointment_date'],
                        $archived_request['appointment_time'],
                        $archived_request['processed_by'],
                        $archived_request['created_at'],
                        $archived_request['updated_at']
                    ]);
                }
                
                // Mark as restored in archive
                $stmt = $pdo->prepare("UPDATE walk_in_requests_archive SET restored_at = NOW(), restored_by = ? WHERE archive_id = ?");
                $stmt->execute([$admin_id, $archive_id]);
                
                // Log activity (if activity_log table exists)
                try {
                    $stmt = $pdo->prepare("INSERT INTO activity_log (admin_id, action_type, table_name, record_id, description) VALUES (?, 'RESTORE', 'walk_in_requests', ?, ?)");
                    $stmt->execute([$admin_id, $original_id, "Admin restored request #{$archived_request['request_number']} from archive"]);
                } catch (PDOException $e) {
                    // Activity log table might not exist, that's okay
                }
                
                $pdo->commit();
                $_SESSION['success'] = 'Request restored successfully!';
            } else {
                $pdo->rollBack();
                $_SESSION['error'] = 'Archived request not found or already restored.';
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $_SESSION['error'] = 'Error restoring request: ' . $e->getMessage();
        }
    }
    header('Location: admin_requests_archive.php');
    exit;
}

// Handle restore for monitoring (file-based) archive
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'restore_monitoring') {
    $archive_id = trim($_POST['archive_id'] ?? '');
    if ($archive_id !== '') {
        $archiveData = [];
        if (file_exists($monitoring_archive_file)) {
            $archiveData = json_decode(file_get_contents($monitoring_archive_file), true);
            if (!is_array($archiveData)) {
                $archiveData = [];
            }
        }

        $restored = false;
        foreach ($archiveData as $idx => $archived) {
            if (($archived['archive_id'] ?? '') !== $archive_id) {
                continue;
            }

            $archived_type = $archived['archived_type'] ?? 'individual';
            $source_file = $archived['archived_from'] ?? ($archived_type === 'summary' ? 'requests.json' : ('req_' . ($archived['id'] ?? 'unknown') . '.json'));

            // Remove archive metadata before restore
            unset($archived['archive_id'], $archived['archived_at'], $archived['archived_from'], $archived['archived_type'], $archived['deleted_at'], $archived['deleted_by']);

            if ($archived_type === 'summary') {
                $target = $monitoring_requests_dir . '/' . $source_file;
                $content = [];
                if (file_exists($target)) {
                    $decoded = json_decode(file_get_contents($target), true);
                    if (is_array($decoded)) {
                        $content = $decoded;
                    }
                }
                if (!is_array($content)) {
                    $content = [];
                }
                $content[] = $archived;
                file_put_contents($target, json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $restored = true;
            } else {
                $filename = $source_file ?: ('req_' . ($archived['id'] ?? uniqid()) . '.json');
                $archived_path = $monitoring_archive_dir . '/' . $filename;
                $target = $monitoring_requests_dir . '/' . $filename;

                if (file_exists($archived_path)) {
                    if (!@rename($archived_path, $target)) {
                        @copy($archived_path, $target);
                        @unlink($archived_path);
                    }
                    $restored = true;
                } else {
                    file_put_contents($target, json_encode($archived, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                    $restored = true;
                }
            }

            if ($restored) {
                unset($archiveData[$idx]);
                $archiveData = array_values($archiveData);
                file_put_contents($monitoring_archive_file, json_encode($archiveData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                $_SESSION['success'] = 'Monitoring request restored from archive.';
            }
            break;
        }

        if (!$restored) {
            $_SESSION['error'] = 'Archived monitoring entry not found or could not be restored.';
        }
    }
    header('Location: admin_requests_archive.php');
    exit;
}

// Handle archive action (archive a request from walk_in_requests)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'archive') {
    $request_id = intval($_POST['request_id'] ?? 0);
    if ($request_id > 0) {
        try {
            $pdo->beginTransaction();
            
            // Check if archive table exists
            $check_stmt = $pdo->query("SHOW TABLES LIKE 'walk_in_requests_archive'");
            if ($check_stmt->rowCount() == 0) {
                $pdo->rollBack();
                $_SESSION['error'] = 'Archive table does not exist. Please create it first.';
                header('Location: admin_requests_archive.php');
                exit;
            }
            
            // Get the complete request data
            $stmt = $pdo->prepare("SELECT * FROM walk_in_requests WHERE request_id = ?");
            $stmt->execute([$request_id]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$request) {
                $pdo->rollBack();
                $_SESSION['error'] = 'Request not found.';
                header('Location: admin_walkin_request.php');
                exit;
            }
            
            // Check if already archived
            $check_archived = $pdo->prepare("SELECT archive_id FROM walk_in_requests_archive WHERE original_request_id = ? AND restored_at IS NULL");
            $check_archived->execute([$request_id]);
            if ($check_archived->fetch()) {
                $pdo->rollBack();
                $_SESSION['error'] = 'Request is already archived.';
                header('Location: admin_walkin_request.php');
                exit;
            }
            
            // Insert complete request data into archive table
            $archive_sql = "INSERT INTO walk_in_requests_archive (
                original_request_id, request_number, resident_id, resident_name, resident_email, 
                resident_contact, category, type, description, attachment_url, status, 
                admin_notes, admin_attachment_url, appointment_date, appointment_time, 
                processed_by, created_at, updated_at, archived_at, archived_by
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?
            )";
            
            $archive_stmt = $pdo->prepare($archive_sql);
            $archive_stmt->execute([
                $request['request_id'],
                $request['request_number'],
                $request['resident_id'],
                $request['resident_name'],
                $request['resident_email'],
                $request['resident_contact'],
                $request['category'],
                $request['type'],
                $request['description'],
                $request['attachment_url'],
                $request['status'],
                $request['admin_notes'],
                $request['admin_attachment_url'],
                $request['appointment_date'],
                $request['appointment_time'],
                $request['processed_by'],
                $request['created_at'],
                $request['updated_at'],
                $admin_id
            ]);
            
            // Delete from main table
            $delete_stmt = $pdo->prepare("DELETE FROM walk_in_requests WHERE request_id = ?");
            $delete_stmt->execute([$request_id]);
            
            // Log activity
            try {
                $stmt = $pdo->prepare("INSERT INTO activity_log (admin_id, action_type, table_name, record_id, description) VALUES (?, 'ARCHIVE', 'walk_in_requests', ?, ?)");
                $stmt->execute([$admin_id, $request_id, "Admin archived request #{$request['request_number']}"]);
            } catch (PDOException $e) {
                // Activity log table might not exist, that's okay
            }
            
            $pdo->commit();
            $_SESSION['success'] = 'Request archived successfully!';
        } catch (PDOException $e) {
            $pdo->rollBack();
            $_SESSION['error'] = 'Error archiving request: ' . $e->getMessage();
        }
    }
    header('Location: admin_walkin_request.php');
    exit;
}

// Handle create archive table action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_table') {
    try {
        // Check if table already exists first
        $check_stmt = $pdo->query("SHOW TABLES LIKE 'walk_in_requests_archive'");
        if ($check_stmt->rowCount() > 0) {
            $_SESSION['success'] = 'Archive table already exists!';
            header('Location: admin_requests_archive.php');
            exit;
        }
        
        // Read and execute SQL from file
        $sql_file = __DIR__ . '/create_requests_archive_table.sql';
        if (file_exists($sql_file)) {
            $sql = file_get_contents($sql_file);
            // Remove comments and split by semicolon
            $sql = preg_replace('/--.*$/m', '', $sql);
            $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
            
            // Execute SQL statements
            $statements = array_filter(array_map('trim', explode(';', $sql)));
            foreach ($statements as $statement) {
                if (!empty($statement)) {
                    $pdo->exec($statement);
                }
            }
        } else {
            // Create table directly if SQL file doesn't exist
            $create_table_sql = "CREATE TABLE IF NOT EXISTS walk_in_requests_archive (
                archive_id INT AUTO_INCREMENT PRIMARY KEY,
                original_request_id INT NOT NULL,
                request_number VARCHAR(50) NOT NULL,
                resident_id INT,
                resident_name VARCHAR(255) NOT NULL,
                resident_email VARCHAR(255),
                resident_contact VARCHAR(50),
                category VARCHAR(100) NOT NULL,
                type VARCHAR(100) NOT NULL,
                description TEXT,
                attachment_url VARCHAR(500),
                status ENUM('Pending', 'Under Review', 'Completed', 'Rejected') DEFAULT 'Pending',
                admin_notes TEXT,
                admin_attachment_url VARCHAR(500),
                appointment_date DATE,
                appointment_time TIME,
                processed_by INT,
                created_at DATETIME DEFAULT NULL,
                updated_at DATETIME DEFAULT NULL,
                archived_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                archived_by INT DEFAULT NULL,
                restored_at DATETIME DEFAULT NULL,
                restored_by INT DEFAULT NULL,
                INDEX idx_original_request_id (original_request_id),
                INDEX idx_request_number (request_number),
                INDEX idx_status (status),
                INDEX idx_archived_at (archived_at),
                INDEX idx_restored_at (restored_at),
                INDEX idx_resident_id (resident_id),
                INDEX idx_archived_by (archived_by)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
            $pdo->exec($create_table_sql);
        }
        
        // Verify table was created
        $verify_stmt = $pdo->query("SHOW TABLES LIKE 'walk_in_requests_archive'");
        if ($verify_stmt->rowCount() > 0) {
            $_SESSION['success'] = 'Archive table created successfully! You can now archive completed/rejected requests.';
        } else {
            $_SESSION['error'] = 'Table creation completed but verification failed. Please refresh the page.';
        }
    } catch (PDOException $e) {
        $_SESSION['error'] = 'Error creating archive table: ' . $e->getMessage();
    }
    header('Location: admin_requests_archive.php');
    exit;
}

// Check if archive table exists
$archive_table_exists = false;
try {
    $stmt = $pdo->query("SHOW TABLES LIKE 'walk_in_requests_archive'");
    $archive_table_exists = ($stmt && $stmt->rowCount() > 0);
} catch (PDOException $e) {
    $archive_table_exists = false;
}

// Get filter parameters
$status_filter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';
$filter_date = $_GET['filter_date'] ?? '';

// Build query for archived requests
$where_conditions = ["restored_at IS NULL"];
$params = [];

if ($status_filter !== 'all') {
    $where_conditions[] = "status = ?";
    $params[] = $status_filter;
}

if (!empty($search)) {
    $where_conditions[] = "(request_number LIKE ? OR resident_name LIKE ? OR category LIKE ? OR type LIKE ?)";
    $search_param = "%{$search}%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if (!empty($filter_date)) {
    switch ($filter_date) {
        case 'today':
            $where_conditions[] = "DATE(archived_at) = CURDATE()";
            break;
        case 'week':
            $where_conditions[] = "archived_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
            break;
        case 'month':
            $where_conditions[] = "archived_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            break;
        case 'year':
            $where_conditions[] = "archived_at >= DATE_SUB(NOW(), INTERVAL 365 DAY)";
            break;
    }
}

$where_clause = implode(' AND ', $where_conditions);

// Get total count
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

if ($archive_table_exists) {
    try {
        $count_query = "SELECT COUNT(*) FROM walk_in_requests_archive WHERE $where_clause";
        $count_stmt = $pdo->prepare($count_query);
        $count_stmt->execute($params);
        $total_archived = $count_stmt->fetchColumn();
        $total_pages = ceil($total_archived / $per_page);
        
    // Get archived requests - get ALL fields for complete document
    $query = "SELECT archive_id, original_request_id, request_number, resident_id, resident_name, 
        resident_email, resident_contact, category, type, description, attachment_url, status, 
        admin_notes, admin_attachment_url, appointment_date, appointment_time, processed_by, 
        created_at, updated_at, archived_at, archived_by
        FROM walk_in_requests_archive 
        WHERE $where_clause 
        ORDER BY archived_at DESC 
        LIMIT $per_page OFFSET $offset";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $archived_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get admin names who archived
        foreach ($archived_requests as &$request) {
            if ($request['archived_by']) {
                try {
                    $stmt = $pdo->prepare("SELECT full_name FROM admins WHERE id = ?");
                    $stmt->execute([$request['archived_by']]);
                    $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                    $request['archived_by_name'] = $admin['full_name'] ?? 'Unknown';
                } catch (PDOException $e) {
                    $request['archived_by_name'] = 'Unknown';
                }
            } else {
                $request['archived_by_name'] = 'System';
            }
        }
        
        // Get total archived count for stats
        try {
            $total_archived_count = $pdo->query("SELECT COUNT(*) FROM walk_in_requests_archive WHERE restored_at IS NULL")->fetchColumn();
        } catch (PDOException $e) {
            $total_archived_count = 0;
        }
        
        // Get stats by status
        $stats = [];
        try {
            $stmt = $pdo->query("SELECT status, COUNT(*) as count FROM walk_in_requests_archive WHERE restored_at IS NULL GROUP BY status");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $stats[$row['status']] = $row['count'];
            }
        } catch (PDOException $e) {
            $stats = [];
        }
    } catch (PDOException $e) {
        $total_archived = 0;
        $total_pages = 0;
        $archived_requests = [];
        $total_archived_count = 0;
        $stats = [];
        $error = 'Database error: ' . $e->getMessage();
    }
} else {
    $total_archived = 0;
    $total_pages = 0;
    $archived_requests = [];
    $total_archived_count = 0;
    $stats = [];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Request Archive - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar - Same styles as other admin pages */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
            list-style: none;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 24px;
            height: 24px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .stat-card h3 {
            font-size: 14px;
            color: #666;
            margin-bottom: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        .stat-card .value {
            font-size: 32px;
            font-weight: 800;
            color: #2c3e2d;
        }
        .filter-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .filter-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        .filter-group label {
            font-size: 13px;
            font-weight: 600;
            color: #2c3e2d;
            margin-bottom: 5px;
        }
        .filter-group input,
        .filter-group select {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s;
            background: rgba(255, 255, 255, 0.8);
        }
        .filter-group input:focus,
        .filter-group select:focus {
            outline: none;
            border-color: #87A96B;
            background: white;
            box-shadow: 0 0 0 3px rgba(135, 169, 107, 0.1);
        }
        .filter-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
            justify-content: flex-end;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-filter {
            background: #2c3e2d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            text-decoration: none;
        }
        .btn-filter:hover {
            background: #1a2e1b;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
        }
        .btn-reset {
            background: #dc2626;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none !important;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .btn-reset:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 38, 38, 0.3);
            text-decoration: none !important;
        }
        .btn-reset:visited,
        .btn-reset:active,
        .btn-reset:focus {
            text-decoration: none !important;
            color: white;
        }
        .btn-restore {
            padding: 6px 12px;
            background: #1E4D2B;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.3s;
        }
        .btn-restore:hover {
            background: #2d7a52;
            transform: translateY(-1px);
        }
        .table-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 25px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        table th {
            background: #2c3e2d;
            padding: 16px;
            text-align: left;
            font-weight: 700;
            color: white;
            font-size: 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        table td {
            padding: 16px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            font-size: 16px;
            font-weight: 500;
            color: #6b7280;
            background: rgba(255, 255, 255, 0.5);
        }
        table tr:hover td {
            background: rgba(135, 169, 107, 0.1);
        }
        .request-status {
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }
        .request-status.completed {
            background: rgba(135, 169, 107, 0.2);
            color: #2c3e2d;
        }
        .request-status.rejected {
            background: rgba(244, 67, 54, 0.2);
            color: #842029;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3c3;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        .pagination a,
        .pagination span {
            padding: 8px 12px;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            text-decoration: none;
            color: #1E4D2B;
            font-size: 14px;
        }
        .pagination a:hover {
            background: #1E4D2B;
            color: white;
        }
        .pagination .current {
            background: #1E4D2B;
            color: white;
            border-color: #1E4D2B;
        }
        .no-data {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 12px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .modal-header h2 {
            color: #1E4D2B;
            font-size: 24px;
        }
        .close-modal {
            font-size: 28px;
            font-weight: bold;
            color: #999;
            cursor: pointer;
            border: none;
            background: none;
        }
        .close-modal:hover {
            color: #1E4D2B;
        }
        .modal-body {
            margin-bottom: 20px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <path d="M3 9h18"></path>
                    <path d="M9 21V9"></path>
                </svg>
            </span>
            Request Archive
        </h1>
        
        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <?php if (!$archive_table_exists): ?>
            <div class="error" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 15px;">
                <div style="flex: 1;">
                    <strong style="display: block; margin-bottom: 5px; font-size: 16px;">⚠️ Archive Table Not Found</strong>
                    <p style="margin: 0; color: #666;">The walk_in_requests_archive table does not exist. Click the button below to create it automatically.</p>
                </div>
                <form method="POST" action="" style="margin: 0;">
                    <input type="hidden" name="action" value="create_table">
                    <button type="submit" class="btn-filter" style="white-space: nowrap;">
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8 2v12M2 8h12" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        </svg>
                        Create Archive Table
                    </button>
                </form>
            </div>
        <?php else: ?>
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Archived</h3>
                    <div class="value"><?php echo number_format($total_archived_count); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Completed</h3>
                    <div class="value"><?php echo number_format($stats['Completed'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Rejected</h3>
                    <div class="value"><?php echo number_format($stats['Rejected'] ?? 0); ?></div>
                </div>
            </div>
            
            <div class="filter-card">
                <form method="GET" action="">
                    <div class="filter-row">
                        <div class="filter-group">
                            <label>Search</label>
                            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Request number, name, category...">
                        </div>
                        <div class="filter-group">
                            <label>Status</label>
                            <select name="status">
                                <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                                <option value="Completed" <?php echo $status_filter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="Rejected" <?php echo $status_filter === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                            </select>
                        </div>
                        <div class="filter-group">
                            <label>Date Filter</label>
                            <select name="filter_date">
                                <option value="">All Time</option>
                                <option value="today" <?php echo $filter_date === 'today' ? 'selected' : ''; ?>>Today</option>
                                <option value="week" <?php echo $filter_date === 'week' ? 'selected' : ''; ?>>Last 7 Days</option>
                                <option value="month" <?php echo $filter_date === 'month' ? 'selected' : ''; ?>>Last 30 Days</option>
                                <option value="year" <?php echo $filter_date === 'year' ? 'selected' : ''; ?>>Last Year</option>
                            </select>
                        </div>
                    </div>
                    <div class="filter-actions">
                        <button type="submit" class="btn-filter">Filter</button>
                        <a href="admin_requests_archive.php" class="btn-reset">Reset</a>
                    </div>
                </form>
            </div>
            
            <div class="table-card">
                <div class="table-container">
                <?php if (empty($archived_requests)): ?>
                    <div class="no-data">
                        <h3>No Archived Requests</h3>
                        <p>There are no archived requests.</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Request #</th>
                                <th>Resident Name</th>
                                <th>Category</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th>Archived Date</th>
                                <th>Archived By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($archived_requests as $request): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($request['request_number']); ?></td>
                                    <td><?php echo htmlspecialchars($request['resident_name']); ?></td>
                                    <td><?php echo htmlspecialchars($request['category']); ?></td>
                                    <td><?php echo htmlspecialchars($request['type']); ?></td>
                                    <td>
                                        <span class="request-status <?php echo strtolower($request['status']); ?>">
                                            <?php echo htmlspecialchars($request['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $request['archived_at'] ? date('M d, Y h:i A', strtotime($request['archived_at'])) : 'N/A'; ?></td>
                                    <td><?php echo htmlspecialchars($request['archived_by_name']); ?></td>
                                    <td>
                                        <button class="btn-restore" onclick="openRestoreModal(<?php echo $request['archive_id']; ?>, '<?php echo htmlspecialchars($request['request_number'], ENT_QUOTES); ?>')">
                                            Restore
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?>&status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&filter_date=<?php echo urlencode($filter_date); ?>">Previous</a>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                                <?php if ($i == $page): ?>
                                    <span class="current"><?php echo $i; ?></span>
                                <?php else: ?>
                                    <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&filter_date=<?php echo urlencode($filter_date); ?>"><?php echo $i; ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo $page + 1; ?>&status=<?php echo urlencode($status_filter); ?>&search=<?php echo urlencode($search); ?>&filter_date=<?php echo urlencode($filter_date); ?>">Next</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="table-card" style="margin-top: 20px;">
            <div class="table-container">
                <h2 style="margin: 0 0 12px 0; color: #1E4D2B;">Monitoring Requests Archive</h2>
                <?php if (empty($monitoring_archived)): ?>
                    <div class="no-data">
                        <h3>No Archived Monitoring Requests</h3>
                        <p>There are no archived monitoring requests.</p>
                    </div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>Full Name</th>
                                <th>Document Type</th>
                                <th>Status</th>
                                <th>Archived Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($monitoring_archived as $arch): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($arch['fullname'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($arch['documentType'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($arch['status'] ?? 'N/A'); ?></td>
                                    <td>
                                        <?php
                                            $archivedAt = $arch['archived_at'] ?? ($arch['deleted_at'] ?? '');
                                            echo $archivedAt ? date('M d, Y h:i A', strtotime($archivedAt)) : 'N/A';
                                        ?>
                                    </td>
                                    <td>
                                        <?php if (!empty($arch['archive_id'])): ?>
                                            <form method="POST" action="" style="display:inline;">
                                                <input type="hidden" name="action" value="restore_monitoring">
                                                <input type="hidden" name="archive_id" value="<?php echo htmlspecialchars($arch['archive_id']); ?>">
                                                <button type="submit" class="btn-restore" style="padding: 8px 14px;">Restore</button>
                                            </form>
                                        <?php else: ?>
                                            <span style="color:#9ca3af;">Unavailable</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Restore Confirmation Modal -->
    <div id="restoreModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Restore Request</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body">
                <p style="color: #1E4D2B; font-weight: 600; font-size: 16px;">
                    Are you sure you want to restore this request?
                </p>
                <p style="margin-top: 10px; color: #666;">
                    Request: <strong id="restoreRequestNumber"></strong>
                </p>
                <p style="margin-top: 10px; color: #999; font-size: 12px;">
                    This will restore the request to the active requests list.
                </p>
            </div>
            <div class="modal-footer">
                <form method="POST" action="" id="restoreForm" style="display: inline;">
                    <input type="hidden" name="action" value="restore">
                    <input type="hidden" name="archive_id" id="restoreArchiveId">
                    <button type="button" class="btn-reset" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-restore" style="padding: 10px 20px; font-size: 14px;">
                        Yes, Restore
                    </button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function openRestoreModal(archiveId, requestNumber) {
            document.getElementById('restoreArchiveId').value = archiveId;
            document.getElementById('restoreRequestNumber').textContent = requestNumber;
            document.getElementById('restoreModal').style.display = 'block';
        }
        
        function closeModal() {
            document.getElementById('restoreModal').style.display = 'none';
        }
        
        window.onclick = function(event) {
            const modal = document.getElementById('restoreModal');
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>

