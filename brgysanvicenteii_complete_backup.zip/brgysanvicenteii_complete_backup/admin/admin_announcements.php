<?php
// admin/admin_announcements.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar - IMPORTANT: Set before including sidebar component
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

$announcements_file = __DIR__ . '/../data/announcements/announcement.json';

// Load announcements
$announcements = [];
if (file_exists($announcements_file)) {
    $announcements = json_decode(file_get_contents($announcements_file), true) ?? [];
}
if (!is_array($announcements)) {
    $announcements = [];
}

// No form submissions - this is a display-only page

// Sort announcements by date value (newest first, then by created_at)
usort($announcements, function($a, $b) {
    $dateA = $a['date_value'] ?? $a['created_at'] ?? '';
    $dateB = $b['date_value'] ?? $b['created_at'] ?? '';
    if ($dateA && $dateB) {
        return strcmp($dateB, $dateA);
    }
    return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
});

// Get announcement types
$types = ['General', 'Event', 'News', 'Important', 'Update'];

// Get announcement categories
$categories = [
    'General Announcement',
    'Upcoming Announcement',
    'Projects',
    'Events',
    'News',
    'Important Notice',
    'Community Update'
];

// Group announcements by category
$grouped_announcements = [];
foreach ($announcements as $ann) {
    $cat = $ann['category'] ?? 'General Announcement';
    if (!isset($grouped_announcements[$cat])) {
        $grouped_announcements[$cat] = [];
    }
    $grouped_announcements[$cat][] = $ann;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a svg {
            flex-shrink: 0;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        /* Submenu */
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .row-container > .section-title:first-child {
            margin-top: 0;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .btn-primary {
            padding: 12px 24px;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(26, 95, 63, 0.3);
            background: linear-gradient(135deg, #2d7a52 0%, #1a5f3f 100%);
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Announcements Grid */
        .announcements-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
        }
        .announcement-card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: all 0.2s;
            border: 1px solid #e5e7eb;
        }
        .announcement-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .announcement-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f0f0f0;
        }
        .announcement-body {
            padding: 20px;
        }
        .announcement-type {
            display: inline-block;
            padding: 4px 12px;
            background: #2c3e2d;
            color: white;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            margin-bottom: 10px;
        }
        .announcement-title {
            font-size: 18px;
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 10px;
        }
        .announcement-description {
            font-size: 14px;
            color: #4b5563;
            line-height: 1.6;
            margin-bottom: 15px;
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .announcement-date {
            font-size: 12px;
            color: #6b7280;
            margin-bottom: 0;
        }
        .announcement-actions {
            display: flex;
            gap: 10px;
        }
        .btn-edit, .btn-delete {
            flex: 1;
            padding: 8px;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-edit {
            background: #d4af37;
            color: white;
        }
        .btn-edit:hover {
            background: #e6c55a;
            transform: translateY(-2px);
        }
        .btn-delete {
            background: #c33;
            color: white;
        }
        .btn-delete:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 35px;
            width: 100%;
            max-width: 750px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            border-left: 4px solid #d4af37;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }
        .modal-header h2 {
            font-size: 24px;
            color: #1a5f3f;
            font-weight: 700;
            position: relative;
            padding-bottom: 10px;
        }
        .modal-header h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, #d4af37 0%, #e6c55a 100%);
            border-radius: 2px;
        }
        .close-modal {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            transition: color 0.3s;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .close-modal svg {
            width: 24px;
            height: 24px;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #1a5f3f;
            font-weight: 600;
            font-size: 14px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        .form-group input[type="file"] {
            padding: 8px;
        }
        .image-preview {
            margin-top: 10px;
            max-width: 100%;
            border-radius: 8px;
            max-height: 200px;
            object-fit: cover;
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: #d0d0d0;
        }
        .btn-submit {
            flex: 1;
            padding: 12px;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(26, 95, 63, 0.3);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        .category-section {
            margin-bottom: 0;
        }
        .category-header {
            font-size: 26px;
            color: #2c3e2d;
            margin-bottom: 15px;
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 10px;
            letter-spacing: -0.3px;
        }
        .category-count {
            font-size: 14px;
            color: #6b7280;
            font-weight: 600;
            background: rgba(107, 114, 128, 0.1);
            padding: 4px 12px;
            border-radius: 12px;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .page-title {
                font-size: 24px;
            }
            .announcements-grid {
                grid-template-columns: 1fr;
            }
            .row-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php 
    // Ensure admin_role is set before including sidebar
    if (!isset($admin_role)) {
        $admin_id = $_SESSION['user_id'] ?? 0;
        if (isset($_SESSION['admin_role'])) {
            $admin_role = $_SESSION['admin_role'];
        } elseif (isset($pdo) && $admin_id) {
            try {
                $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
                $_SESSION['admin_role'] = $admin_role;
            } catch (Exception $e) {
                $admin_role = 'regular_admin';
            }
        } else {
            $admin_role = 'regular_admin';
        }
    }
    include 'admin_dashboard_sidebar.php'; 
    ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <path d="M22 6l-10 7L2 6"/>
                </svg>
            </span>
            Announcements
        </h1>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if (empty($announcements)): ?>
            <div class="row-container">
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width: 80px; height: 80px; margin: 0 auto 20px; opacity: 0.3; color: #9ca3af;">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <path d="M22 6l-10 7L2 6"/>
                    </svg>
                    <h3 style="color: #2c3e2d; margin-bottom: 10px;">No Announcements Yet</h3>
                    <p style="color: #6b7280;">Create your first announcement to keep residents informed.</p>
                </div>
            </div>
        <?php else: ?>
            <?php foreach ($grouped_announcements as $category => $cat_announcements): ?>
                <div class="row-container">
                    <h2 class="section-title">
                        <span class="section-title-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <path d="M22 6l-10 7L2 6"/>
                            </svg>
                        </span>
                        <?php echo htmlspecialchars($category); ?> 
                        <span class="category-count" style="margin-left: auto;"><?php echo count($cat_announcements); ?></span>
                    </h2>
                    <div class="announcements-grid">
                        <?php foreach ($cat_announcements as $ann): ?>
                            <div class="announcement-card">
                                <?php if (!empty($ann['image'])): ?>
                                    <img src="../<?php echo htmlspecialchars($ann['image']); ?>" alt="<?php echo htmlspecialchars($ann['title']); ?>" class="announcement-image">
                                <?php endif; ?>
                                <div class="announcement-body">
                                    <span class="announcement-type"><?php echo htmlspecialchars($ann['type'] ?? 'General'); ?></span>
                                    <h3 class="announcement-title"><?php echo htmlspecialchars($ann['title']); ?></h3>
                                    <p class="announcement-description"><?php echo htmlspecialchars($ann['description']); ?></p>
                                    <div class="announcement-date">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                            <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                            <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                        </svg>
                                        <?php echo htmlspecialchars($ann['date'] ?? 'N/A'); ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <script>
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                // Show/hide floating toggle button
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        // Initialize sidebar state
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>

