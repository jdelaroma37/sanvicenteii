<?php
// admin/role_helper.php

function isSuperAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'super_admin';
}

function isRegularAdmin() {
    return isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'regular_admin';
}

function canPerformAction($action) {
    $permissions = [
        'super_admin' => ['delete', 'manage_accounts', 'view_financial', 'edit_records'],
        'regular_admin' => ['edit_records']
    ];

    $role = $_SESSION['admin_role'] ?? 'regular_admin';
    return in_array($action, $permissions[$role] ?? []);
}

function requireSuperAdmin() {
    if (!isSuperAdmin()) {
        header("Location: unauthorized.php");
        exit;
    }
}

function requirePermission($action) {
    if (!canPerformAction($action)) {
        header("Location: unauthorized.php");
        exit;
    }
}

function getAdminRoleDisplay() {
    return $_SESSION['admin_role'] === 'super_admin' ? "Super Admin" : "Admin";
}

function canViewFinancial() {
    return canPerformAction("view_financial");
}

function canDelete() {
    return canPerformAction("delete");
}
