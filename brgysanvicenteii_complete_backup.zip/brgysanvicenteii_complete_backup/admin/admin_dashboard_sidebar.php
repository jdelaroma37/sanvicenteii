<?php
if (!isset($_SESSION)) {
    session_start();
}

require_once __DIR__ . '/../lang/language_helper.php';

// Get admin role
$admin_role = $_SESSION['admin_role'] ?? 'regular_admin';
if (!isset($_SESSION['admin_role']) && isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/../config.php';
    try {
        $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
        $_SESSION['admin_role'] = $admin_role;
    } catch (Exception $e) {
        $admin_role = 'regular_admin';
    }
}

// Get current page to set active state
$current_page = basename($_SERVER['PHP_SELF']);

// Get unread notification count
$unread_notifications_count = 0;
if (isset($_SESSION['user_id'])) {
    $notifDir = __DIR__ . '/../data/notifications';
    $adminNotifFile = $notifDir . '/admin_notifications.json';
    
    if (file_exists($adminNotifFile)) {
        $admin_notifications = json_decode(file_get_contents($adminNotifFile), true) ?? [];
        
        // Filter notifications based on role
        foreach ($admin_notifications as $notif) {
            $notif_role = $notif['target_role'] ?? 'all';
            $is_unread = !isset($notif['read']) || $notif['read'] == false;
            
            if ($is_unread) {
                if ($admin_role === 'super_admin') {
                    $unread_notifications_count++;
                } else {
                    if ($notif_role === 'all' || $notif_role === 'regular_admin') {
                        $excluded_types = ['admin_added', 'password_changed', 'failed_login', 'system_update', 'system_error'];
                        if (!in_array($notif['type'] ?? '', $excluded_types)) {
                            $unread_notifications_count++;
                        }
                    }
                }
            }
        }
    }
}
?>

<!-- Floating Toggle Button (shown when sidebar is hidden) -->
<button class="sidebar-toggle-float" id="sidebarToggleFloat" onclick="toggleSidebar()" title="<?php echo htmlspecialchars(trans('nav_show_sidebar')); ?>" style="display: none;">
    <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M3 4l5 5-5 5M9 4l5 5-5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
</button>

<div class="sidebar" id="sidebar">
    <button class="sidebar-toggle" id="sidebarToggle" onclick="toggleSidebar()" title="<?php echo htmlspecialchars(trans('nav_hide_sidebar')); ?>">
        <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
        </svg>
    </button>
    <div class="sidebar-logo">
        <img src="../images/logo.jpg" alt="Barangay Logo">
        <h2>BARANGAY SAN VICENTE II</h2>
        <p>Silang, Cavite</p>
    </div>
    <ul class="nav-menu">
        <li class="has-submenu <?php echo (in_array($current_page, ['admin_dashboard.php', 'admin_barangay_dashboard.php'])) ? 'active' : ''; ?>">
            <a href="#" onclick="toggleSubmenu(event, this.parentElement)">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <rect x="2" y="2" width="4" height="4" stroke="currentColor" stroke-width="1.5"/>
                    <rect x="10" y="2" width="4" height="4" stroke="currentColor" stroke-width="1.5"/>
                    <rect x="2" y="10" width="4" height="4" stroke="currentColor" stroke-width="1.5"/>
                    <rect x="10" y="10" width="4" height="4" stroke="currentColor" stroke-width="1.5"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_dashboard_menu')); ?> <span class="arrow-icon">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;">
                        <path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span></a>
            <ul class="submenu">
                <li><a href="admin_dashboard.php" <?php echo ($current_page === 'admin_dashboard.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_dashboard_menu')); ?></a></li>
                <li><a href="admin_barangay_dashboard.php" <?php echo ($current_page === 'admin_barangay_dashboard.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_barangay_dashboard')); ?></a></li>
            </ul>
        </li>
        <li><a href="admin_notifications.php" <?php echo ($current_page === 'admin_notifications.php') ? 'class="active"' : ''; ?> style="position: relative;">
            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                <path d="M6 2a2 2 0 0 0-2 2v.5c0 1.5-.5 3-1.5 4L2 10a1 1 0 0 0 1 1h10a1 1 0 0 0 1-1l-.5-1.5c-1-1-1.5-2.5-1.5-4V4a2 2 0 0 0-2-2H6z" stroke="currentColor" stroke-width="1.5" fill="none"/>
                <path d="M6 12v1a2 2 0 0 0 2 2h0a2 2 0 0 0 2-2v-1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <?php echo htmlspecialchars(trans('nav_notifications')); ?>
            <?php if ($unread_notifications_count > 0): ?>
                <span class="notification-badge"><?php echo $unread_notifications_count > 99 ? '99+' : $unread_notifications_count; ?></span>
            <?php endif; ?>
        </a></li>
        <li><a href="admin_announcements.php" <?php echo ($current_page === 'admin_announcements.php') ? 'class="active"' : ''; ?>>
            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                <path d="M8 1v2M5 3h6M3 6c0 3 2 5 5 5s5-2 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                <path d="M3 6v6c0 1 1 2 2 2h6c1 0 2-1 2-2V6" stroke="currentColor" stroke-width="1.5" fill="none"/>
            </svg>
            <?php echo htmlspecialchars(trans('nav_announcements')); ?></a></li>
        <li><a href="admin_officials.php" <?php echo ($current_page === 'admin_officials.php') ? 'class="active"' : ''; ?>>
            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                <circle cx="8" cy="6" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                <path d="M4 13.5c0-2 2-3.5 4-3.5s4 1.5 4 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <?php echo htmlspecialchars(trans('nav_officials')); ?></a></li>
        <li class="has-submenu <?php echo (in_array($current_page, ['admin_residents.php', 'admin_residents_voters.php', 'admin_residents_registered.php', 'admin_residents_archive.php'])) ? 'active' : ''; ?>">
            <a href="#" onclick="toggleSubmenu(event, this.parentElement)">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <path d="M8 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6z" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M3 13.5c0-2 2.5-3.5 5-3.5s5 1.5 5 3.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <circle cx="12" cy="6" r="1.5" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M10.5 10.5c0-1 1-1.5 1.5-1.5s1.5 0.5 1.5 1.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_residents')); ?> <span class="arrow-icon">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;">
                        <path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span></a>
            <ul class="submenu">
                <li><a href="admin_residents.php" <?php echo ($current_page === 'admin_residents.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_residents')); ?></a></li>
                <li><a href="admin_residents_voters.php" <?php echo ($current_page === 'admin_residents_voters.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_residents_voters')); ?></a></li>
                <li><a href="admin_residents_registered.php" <?php echo ($current_page === 'admin_residents_registered.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_residents_registered')); ?></a></li>
                <li><a href="admin_residents_archive.php" <?php echo ($current_page === 'admin_residents_archive.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_residents_archive')); ?></a></li>
            </ul>
        </li>
        <li class="has-submenu <?php echo (in_array($current_page, ['admin_monitoring_request.php', 'admin_issuance_details.php', 'admin_walkin_request.php', 'admin_requests_archive.php'])) ? 'active' : ''; ?>">
            <a href="#" onclick="toggleSubmenu(event, this.parentElement)">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <rect x="3" y="3" width="10" height="12" rx="1" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M6 7h4M6 10h4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_requests')); ?> <span class="arrow-icon">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;">
                        <path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span></a>
            <ul class="submenu">
                <li><a href="admin_monitoring_request.php" <?php echo ($current_page === 'admin_monitoring_request.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_request_monitoring')); ?></a></li>
                <li><a href="admin_issuance_details.php" <?php echo ($current_page === 'admin_issuance_details.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_request_issuance')); ?></a></li>
                <li><a href="admin_walkin_request.php" <?php echo ($current_page === 'admin_walkin_request.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_request_walkin')); ?></a></li>
                <li><a href="admin_requests_archive.php" <?php echo ($current_page === 'admin_requests_archive.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_request_archive')); ?></a></li>
            </ul>
        </li>
        <li class="has-submenu <?php echo (in_array($current_page, ['admin_records_messages.php', 'admin_records_projects.php', 'admin_records_financial.php'])) ? 'active' : ''; ?>">
            <a href="#" onclick="toggleSubmenu(event, this.parentElement)">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <path d="M3 3h10a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1z" stroke="currentColor" stroke-width="1.5" fill="none"/>
                    <path d="M3 6h10M3 9h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_records')); ?> <span class="arrow-icon">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;">
                        <path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span></a>
            <ul class="submenu">
                <li><a href="admin_records_messages.php" <?php echo ($current_page === 'admin_records_messages.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_records_messages')); ?></a></li>
                <li><a href="admin_records_projects.php" <?php echo ($current_page === 'admin_records_projects.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_records_projects')); ?></a></li>
                <li><a href="admin_records_financial.php" <?php echo ($current_page === 'admin_records_financial.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_records_financial')); ?></a></li>
            </ul>
        </li>
        <li class="has-submenu <?php echo (in_array($current_page, ['admin_announcement_management.php', 'admin_programs_events.php', 'admin_event_calendar.php', 'admin_progress_projects.php'])) ? 'active' : ''; ?>">
            <a href="#" onclick="toggleSubmenu(event, this.parentElement)">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M6 7l2 2 4-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_content_management')); ?> <span class="arrow-icon">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;">
                        <path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span></a>
            <ul class="submenu">
                <li><a href="admin_announcement_management.php" <?php echo ($current_page === 'admin_announcement_management.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_announcements_manage')); ?></a></li>
                <li><a href="admin_programs_events.php" <?php echo ($current_page === 'admin_programs_events.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_programs_services')); ?></a></li>
                <li><a href="admin_event_calendar.php" <?php echo ($current_page === 'admin_event_calendar.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_event_calendar')); ?></a></li>
                <li><a href="admin_progress_projects.php" <?php echo ($current_page === 'admin_progress_projects.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_progress_projects')); ?></a></li>
            </ul>
        </li>
        <li class="has-submenu <?php echo (in_array($current_page, ['admin_barangay_settings.php', 'admin_activity_logs.php', 'admin_system_maintenance.php', 'admin_backup.php'])) ? 'active' : ''; ?>">
            <a href="#" onclick="toggleSubmenu(event, this.parentElement)">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5" fill="none"/>
                    <circle cx="8" cy="8" r="1" fill="currentColor"/>
                    <path d="M8 2v2M8 12v2M2 8h2M12 8h2M3.5 3.5l1.4 1.4M11.1 11.1l1.4 1.4M3.5 12.5l1.4-1.4M11.1 4.9l1.4-1.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_system')); ?> <span class="arrow-icon">
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" style="vertical-align: middle;">
                        <path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                </span></a>
            <ul class="submenu">
                <li><a href="admin_barangay_settings.php" <?php echo ($current_page === 'admin_barangay_settings.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_barangay_settings')); ?></a></li>
                <li><a href="admin_activity_logs.php" <?php echo ($current_page === 'admin_activity_logs.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_activity_logs')); ?></a></li>
                <li><a href="admin_system_maintenance.php" <?php echo ($current_page === 'admin_system_maintenance.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_system_maintenance')); ?></a></li>
                <li><a href="admin_backup.php" <?php echo ($current_page === 'admin_backup.php') ? 'class="active"' : ''; ?>><?php echo htmlspecialchars(trans('nav_backup_export')); ?></a></li>
            </ul>
        </li>
        <li><a href="admin_help.php" class="help-guide-link <?php echo ($current_page === 'admin_help.php') ? 'active' : ''; ?>">
            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                <circle cx="8" cy="8" r="6" stroke="currentColor" stroke-width="1.5"/>
                <path d="M8 6v2M8 10h.01" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <?php echo htmlspecialchars(trans('nav_help_guide')); ?></a></li>
        <li style="margin-top: 15px;">
            <a href="admin_manage_account.php" class="manage-account-btn <?php echo ($current_page === 'admin_manage_account.php') ? 'active' : ''; ?>">
                <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                    <circle cx="6" cy="5" r="2" stroke="currentColor" stroke-width="1.5"/>
                    <path d="M2 12c0-1.5 1.5-2.5 4-2.5s4 1 4 2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    <circle cx="11.5" cy="7" r="2" stroke="currentColor" stroke-width="1.5" fill="none"/>
                    <circle cx="11.5" cy="7" r="0.7" fill="currentColor"/>
                    <path d="M11.5 5.5v3M11.5 7h-1.4M11.5 7h1.4M9.8 5.2l3.4 3.4M9.8 8.8l3.4-3.4M13.2 5.2l-3.4 3.4M13.2 8.8l-3.4-3.4" stroke="currentColor" stroke-width="1" stroke-linecap="round"/>
                </svg>
                <?php echo htmlspecialchars(trans('nav_manage_account')); ?>
            </a>
        </li>
        <?php if ($admin_role === 'super_admin'): ?>
        <li><a href="admin_manage_admins.php" <?php echo ($current_page === 'admin_manage_admins.php') ? 'class="active"' : ''; ?>>
            <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 12px; vertical-align: middle;">
                <circle cx="7" cy="6" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                <path d="M3 13.5c0-2 2-3 4-3s4 1 4 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                <circle cx="12" cy="7" r="1.8" stroke="currentColor" stroke-width="1.5"/>
                <path d="M10.5 13c0-1.5 1-2.5 1.5-2.5s1.5 1 1.5 2.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
            </svg>
            <?php echo htmlspecialchars(trans('nav_admin_staff_management')); ?></a></li>
        <?php endif; ?>
        <li style="margin-top: 20px;">
            <form method="POST" action="logout.php" style="margin: 0;">
                <button type="submit" class="logout-btn">
                    <svg width="18" height="18" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-right: 8px; vertical-align: middle;">
                        <path d="M6 2h6a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                        <path d="M10 8H2M4 5l-3 3 3 3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    <?php echo htmlspecialchars(trans('nav_logout')); ?>
                </button>
            </form>
        </li>
    </ul>
</div>

<style>
    /* Notification Badge */
    .notification-badge {
        position: absolute;
        top: 8px;
        right: 8px;
        background: #c33;
        color: white;
        border-radius: 10px;
        padding: 2px 6px;
        font-size: 11px;
        font-weight: 700;
        min-width: 18px;
        text-align: center;
        line-height: 14px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        z-index: 10;
    }
    
    /* Ensure notification link is positioned relatively */
    .nav-menu > li > a[href*="notifications"] {
        position: relative;
    }
    
    /* Logout button with icon - ensure flex display */
    .logout-btn {
        display: inline-flex !important;
        align-items: center;
        justify-content: center;
    }
    
    /* Help and Guide - no transparent background */
    .help-guide-link {
        background: transparent !important;
    }
    .help-guide-link:hover {
        background: transparent !important;
        color: white !important;
    }
    .help-guide-link.active {
        background: transparent !important;
        font-weight: 600;
    }
    
    /* Manage Account button - plain text with icon, no background until active */
    .manage-account-btn,
    .manage-account-btn:hover {
        display: flex !important;
        align-items: center !important;
        justify-content: flex-start !important;
        text-align: left !important;
        border: none !important;
        box-shadow: none !important;
        outline: none !important;
        background: transparent !important;
        padding: 14px 18px !important;
        font-size: 16px !important;
        font-weight: 500 !important;
    }
    
    /* Manage Account active state - only show background when active */
    .manage-account-btn.active {
        background: rgba(255,255,255,0.2) !important;
    }
    
    .manage-account-btn:hover {
        background: rgba(255,255,255,0.1) !important;
        color: #fff !important;
    }
    
    /* Admin & Staff Management - no border, no box-shadow, clean style */
    .nav-menu > li > a[href*="manage_admins"],
    .nav-menu > li > a[href*="manage_admins"]:hover,
    .nav-menu > li > a[href*="manage_admins"].active {
        border: none !important;
        outline: none !important;
        box-shadow: none !important;
    }
    .nav-menu > li > a[href*="manage_admins"] {
        background: transparent !important;
    }
    .nav-menu > li > a[href*="manage_admins"]:hover {
        background: rgba(255,255,255,0.1) !important;
        color: #fff !important;
    }
    .nav-menu > li > a[href*="manage_admins"].active {
        background: rgba(255,255,255,0.2) !important;
    }
    
    /* Sidebar Toggle Button */
    .sidebar-toggle {
        position: absolute;
        top: 20px;
        left: 20px;
        background: rgba(0, 0, 0, 0.1);
        border: 2px solid rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 1000;
        color: #000;
        padding: 0;
    }
    .sidebar-toggle:hover {
        background: rgba(0, 0, 0, 0.2);
        border-color: rgba(0, 0, 0, 0.3);
        transform: scale(1.05);
        color: #fff;
    }
    .sidebar-toggle svg {
        width: 18px;
        height: 18px;
        transition: transform 0.3s;
    }
    
    /* Sidebar Hidden State */
    .sidebar.hidden {
        transform: translateX(100%);
        transition: transform 0.3s ease-in-out;
    }
    
    /* Main Content when sidebar is hidden */
    body.sidebar-hidden .main-content {
        margin-right: 0 !important;
        width: 100% !important;
    }
    
    /* All Sidebar Navigation Links - Hover Effect */
    .sidebar .nav-menu > li > a:hover,
    .sidebar .nav-menu > li > a:hover svg,
    .sidebar .submenu a:hover,
    .sidebar .submenu a:hover svg,
    .sidebar .nav-menu > li > a:hover .arrow-icon svg {
        color: #fff !important;
        transition: color 0.3s ease;
    }
    
    /* Logout Button Hover */
    .sidebar .logout-btn:hover,
    .sidebar .logout-btn:hover svg {
        color: #fff !important;
        transition: color 0.3s ease;
    }
    
    /* Sidebar Logo Text Hover (if needed) */
    .sidebar .sidebar-logo h2:hover,
    .sidebar .sidebar-logo p:hover {
        color: #fff;
        transition: color 0.3s ease;
    }
    
    /* Floating Toggle Button (shown when sidebar is hidden) */
    .sidebar-toggle-float {
        position: fixed;
        top: 20px;
        right: 20px;
        background: #87A96B;
        border: 2px solid rgba(0, 0, 0, 0.2);
        border-radius: 8px;
        width: 44px;
        height: 44px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 1001;
        color: #000;
        padding: 0;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .sidebar-toggle-float:hover {
        background: #7a9660;
        transform: scale(1.1);
        box-shadow: 0 6px 16px rgba(0,0,0,0.2);
        color: #fff;
    }
    .sidebar-toggle-float svg {
        width: 20px;
        height: 20px;
    }
    body.sidebar-hidden .sidebar-toggle-float {
        display: flex !important;
    }
</style>

<script>
    function toggleSubmenu(event, element) {
        event.preventDefault();
        element.classList.toggle('active');
    }
    
    // Auto-expand submenu if current page is in it
    document.addEventListener('DOMContentLoaded', function() {
        const currentPage = '<?php echo $current_page; ?>';
        const submenuPages = {
            'admin_dashboard.php': 'Dashboard',
            'admin_barangay_dashboard.php': 'Dashboard',
            'admin_residents.php': 'Residents',
            'admin_residents_voters.php': 'Residents',
            'admin_residents_registered.php': 'Residents',
            'admin_residents_archive.php': 'Residents',
            'admin_monitoring_request.php': 'Requests',
            'admin_issuance_details.php': 'Requests',
            'admin_walkin_request.php': 'Requests',
            'admin_requests_archive.php': 'Requests',
            'admin_records_messages.php': 'Records',
            'admin_records_projects.php': 'Records',
            'admin_records_financial.php': 'Records',
            'admin_announcement_management.php': 'Content Management',
            'admin_programs_events.php': 'Content Management',
            'admin_event_calendar.php': 'Content Management',
            'admin_progress_projects.php': 'Content Management',
            'admin_barangay_settings.php': 'System',
            'admin_activity_logs.php': 'System',
            'admin_system_maintenance.php': 'System',
            'admin_backup.php': 'System'
        };
        
        if (submenuPages[currentPage]) {
            const submenuItems = document.querySelectorAll('.has-submenu');
            submenuItems.forEach(item => {
                const link = item.querySelector('a');
                if (link && link.textContent.trim().includes(submenuPages[currentPage])) {
                    item.classList.add('active');
                }
            });
        }
        
        // Load sidebar state from localStorage
        const sidebarState = localStorage.getItem('sidebarHidden');
        const sidebar = document.getElementById('sidebar');
        const toggleFloat = document.getElementById('sidebarToggleFloat');
        
        if (sidebarState === 'true' && sidebar) {
            sidebar.classList.add('hidden');
            document.body.classList.add('sidebar-hidden');
            if (toggleFloat) {
                toggleFloat.style.display = 'flex';
            }
        } else {
            if (toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        }
    });
    
    // Toggle Sidebar Function
    function toggleSidebar() {
        const sidebar = document.getElementById('sidebar');
        const body = document.body;
        const toggleFloat = document.getElementById('sidebarToggleFloat');
        
        if (sidebar) {
            sidebar.classList.toggle('hidden');
            body.classList.toggle('sidebar-hidden');
            
            // Show/hide floating button
            if (toggleFloat) {
                if (sidebar.classList.contains('hidden')) {
                    toggleFloat.style.display = 'flex';
                } else {
                    toggleFloat.style.display = 'none';
                }
            }
            
            // Save state to localStorage
            const isHidden = sidebar.classList.contains('hidden');
            localStorage.setItem('sidebarHidden', isHidden);
        }
    }
</script>
