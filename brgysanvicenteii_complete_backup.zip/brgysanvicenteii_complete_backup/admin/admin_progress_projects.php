<?php
// admin/admin_progress_projects.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

$projects_file = __DIR__ . '/../data/projects.json';

// Load projects
$projects = [];
if (file_exists($projects_file)) {
    $projects = json_decode(file_get_contents($projects_file), true) ?? [];
}
if (!is_array($projects)) {
    $projects = [];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'edit') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $status = trim($_POST['status'] ?? 'Planning');
        $progress = (int)($_POST['progress'] ?? 0);
        $start_date = trim($_POST['start_date'] ?? '');
        $target_date = trim($_POST['target_date'] ?? '');
        $budget = trim($_POST['budget'] ?? '');
        $contractor = trim($_POST['contractor'] ?? '');
        
        if (!$title || !$description) {
            $_SESSION['error'] = 'Title and description are required.';
            header('Location: admin_progress_projects.php');
            exit;
        }
        
        if ($action === 'create') {
            $new_project = [
                'id' => uniqid('proj_'),
                'title' => $title,
                'description' => $description,
                'status' => $status,
                'progress' => $progress,
                'start_date' => $start_date,
                'target_date' => $target_date,
                'budget' => $budget,
                'contractor' => $contractor,
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $admin_id
            ];
            $projects[] = $new_project;
            $success = 'Project created successfully!';
        } else {
            $id = $_POST['id'] ?? '';
            $found = false;
            foreach ($projects as &$proj) {
                if (isset($proj['id']) && $proj['id'] === $id) {
                    $proj['title'] = $title;
                    $proj['description'] = $description;
                    $proj['status'] = $status;
                    $proj['progress'] = $progress;
                    $proj['start_date'] = $start_date;
                    $proj['target_date'] = $target_date;
                    $proj['budget'] = $budget;
                    $proj['contractor'] = $contractor;
                    $proj['updated_at'] = date('Y-m-d H:i:s');
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $success = 'Project updated successfully!';
            } else {
                $_SESSION['error'] = 'Project not found.';
                header('Location: admin_progress_projects.php');
                exit;
            }
        }
        
        file_put_contents($projects_file, json_encode($projects, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $_SESSION['success'] = $success;
        header('Location: admin_progress_projects.php');
        exit;
    } elseif ($action === 'delete') {
        $id = $_POST['id'] ?? '';
        $found = false;
        foreach ($projects as $key => $proj) {
            if (isset($proj['id']) && $proj['id'] === $id) {
                unset($projects[$key]);
                $projects = array_values($projects);
                $found = true;
                break;
            }
        }
        if ($found) {
            file_put_contents($projects_file, json_encode($projects, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['success'] = 'Project deleted successfully!';
        } else {
            $_SESSION['error'] = 'Project not found.';
        }
        header('Location: admin_progress_projects.php');
        exit;
    }
}

// Sort by status and progress
usort($projects, function($a, $b) {
    $status_order = ['Planning' => 1, 'In Progress' => 2, 'On Hold' => 3, 'Completed' => 4, 'Cancelled' => 5];
    $a_order = $status_order[$a['status'] ?? 'Planning'] ?? 99;
    $b_order = $status_order[$b['status'] ?? 'Planning'] ?? 99;
    if ($a_order !== $b_order) {
        return $a_order - $b_order;
    }
    return ($b['progress'] ?? 0) - ($a['progress'] ?? 0);
});

$statuses = ['Planning', 'In Progress', 'On Hold', 'Completed', 'Cancelled'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Progress/Projects - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .page-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            background: #2c3e2d;
            color: white;
        }
        .page-actions .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .btn-secondary,
        .page-actions .btn-secondary {
            background: #4b5563 !important;
            color: white !important;
        }
        .btn-secondary:hover,
        .page-actions .btn-secondary:hover {
            background: #374151 !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(75, 85, 99, 0.3);
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .btn-primary {
            padding: 12px 24px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .error, .success {
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        .error {
            background: #fee;
            color: #c33;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            border-left: 3px solid #3c3;
        }
        .projects-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin-bottom: 30px;
        }
        .project-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            padding: 25px;
            transition: all 0.3s;
            border-left: 4px solid #d4af37;
        }
        .project-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .project-header {
            display: flex;
            justify-content: space-between;
            align-items: start;
            margin-bottom: 15px;
        }
        .project-title {
            font-size: 20px;
            font-weight: 700;
            color: #1a5f3f;
            flex: 1;
        }
        .project-status {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-planning { background: #e3f2fd; color: #1976d2; }
        .status-progress { background: #fff3e0; color: #f57c00; }
        .status-hold { background: #fce4ec; color: #c2185b; }
        .status-completed { background: #e8f5e9; color: #388e3c; }
        .status-cancelled { background: #ffebee; color: #d32f2f; }
        .project-description {
            font-size: 14px;
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .progress-section {
            margin-bottom: 15px;
        }
        .progress-label {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 13px;
            color: #666;
        }
        .progress-bar {
            width: 100%;
            height: 20px;
            background: #e0e0e0;
            border-radius: 10px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #1a5f3f 0%, #2d7a52 100%);
            transition: width 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 11px;
            font-weight: 600;
        }
        .project-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 15px;
            font-size: 13px;
            color: #666;
        }
        .project-info-item {
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .project-actions {
            display: flex;
            gap: 10px;
            margin-top: 15px;
        }
        .btn-edit, .btn-delete {
            flex: 1;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
        }
        .btn-edit {
            background: #d4af37;
            color: white;
        }
        .btn-edit:hover {
            background: #e6c55a;
            transform: translateY(-2px);
        }
        .btn-delete {
            background: #c33;
            color: white;
        }
        .btn-delete:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 35px;
            width: 100%;
            max-width: 750px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            border-left: 4px solid #d4af37;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }
        .modal-header h2 {
            font-size: 24px;
            color: #1a5f3f;
            font-weight: 700;
        }
        .close-modal {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 24px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #1a5f3f;
            font-weight: 600;
            font-size: 14px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
        }
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel, .btn-submit {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel {
            background: #e0e0e0;
            color: #333;
        }
        .btn-submit {
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
        }
        @media (max-width: 1024px) {
            .projects-grid {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .form-row {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php 
    if (!isset($admin_role)) {
        $admin_id = $_SESSION['user_id'] ?? 0;
        if (isset($_SESSION['admin_role'])) {
            $admin_role = $_SESSION['admin_role'];
        } elseif (isset($pdo) && $admin_id) {
            try {
                $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
                $_SESSION['admin_role'] = $admin_role;
            } catch (Exception $e) {
                $admin_role = 'regular_admin';
            }
        } else {
            $admin_role = 'regular_admin';
        }
    }
    include 'admin_dashboard_sidebar.php'; 
    ?>

    <div class="main-content">
        <div class="page-header">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
                </svg>
            </span>
            Progress/Projects
        </h1>
        </div>

        <div class="page-actions">
            <a href="admin_announcement_management.php" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Announcement Management
            </a>
        </div>

        <div style="display: flex; justify-content: flex-end; margin-bottom: 30px;">
            <button class="btn-primary" onclick="openCreateModal()">Create Project</button>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="row-container">
            <?php if (empty($projects)): ?>
                <div class="empty-state">
                    <h3>No Projects Yet</h3>
                    <p>Create your first project to start tracking progress.</p>
                </div>
            <?php else: ?>
                <div class="projects-grid">
                <?php foreach ($projects as $proj): ?>
                    <div class="project-card">
                        <div class="project-header">
                            <h3 class="project-title"><?php echo htmlspecialchars($proj['title']); ?></h3>
                            <span class="project-status status-<?php echo strtolower(str_replace(' ', '-', $proj['status'] ?? 'Planning')); ?>">
                                <?php echo htmlspecialchars($proj['status'] ?? 'Planning'); ?>
                            </span>
                        </div>
                        <p class="project-description"><?php echo htmlspecialchars($proj['description']); ?></p>
                        
                        <div class="progress-section">
                            <div class="progress-label">
                                <span>Progress</span>
                                <span><?php echo ($proj['progress'] ?? 0); ?>%</span>
                            </div>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: <?php echo ($proj['progress'] ?? 0); ?>%;">
                                    <?php if (($proj['progress'] ?? 0) > 10): ?>
                                        <?php echo ($proj['progress'] ?? 0); ?>%
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="project-info">
                            <?php if (!empty($proj['start_date'])): ?>
                                <div class="project-info-item">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5"/>
                                    </svg>
                                    Start: <?php echo date('M d, Y', strtotime($proj['start_date'])); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($proj['target_date'])): ?>
                                <div class="project-info-item">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5"/>
                                    </svg>
                                    Target: <?php echo date('M d, Y', strtotime($proj['target_date'])); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($proj['budget'])): ?>
                                <div class="project-info-item">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M8 2v12M5 5h6M5 9h6" stroke="currentColor" stroke-width="1.5"/>
                                    </svg>
                                    Budget: ₱<?php echo number_format($proj['budget'], 2); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($proj['contractor'])): ?>
                                <div class="project-info-item">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <circle cx="8" cy="6" r="2.5" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M4 13.5c0-2 2-3.5 4-3.5s4 1.5 4 3.5" stroke="currentColor" stroke-width="1.5"/>
                                    </svg>
                                    <?php echo htmlspecialchars($proj['contractor']); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="project-actions">
                            <button class="btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($proj)); ?>)">
                                <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                                    <path d="M11 2l3 3M9 8l3 3M3 12l5-5M2 11l8-8" stroke="currentColor" stroke-width="1.5"/>
                                </svg>
                                Edit
                            </button>
                            <button class="btn-delete" onclick="deleteProject('<?php echo htmlspecialchars($proj['id']); ?>')">
                                <svg width="14" height="14" viewBox="0 0 16 16" fill="none">
                                    <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5"/>
                                </svg>
                                Delete
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Create/Edit Modal -->
    <div id="projectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Create Project</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <form id="projectForm" method="POST">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="projectId">
                
                <div class="form-group">
                    <label for="title">Project Title *</label>
                    <input type="text" id="title" name="title" required>
                </div>

                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" required></textarea>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="status">Status *</label>
                        <select id="status" name="status" required>
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?php echo htmlspecialchars($status); ?>"><?php echo htmlspecialchars($status); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="progress">Progress (%)</label>
                        <input type="number" id="progress" name="progress" min="0" max="100" value="0">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="start_date">Start Date</label>
                        <input type="date" id="start_date" name="start_date">
                    </div>
                    <div class="form-group">
                        <label for="target_date">Target Date</label>
                        <input type="date" id="target_date" name="target_date">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="budget">Budget (₱)</label>
                        <input type="number" id="budget" name="budget" step="0.01" min="0">
                    </div>
                    <div class="form-group">
                        <label for="contractor">Contractor/Responsible</label>
                        <input type="text" id="contractor" name="contractor">
                    </div>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="deleteId">
    </form>

    <script>
        function openCreateModal() {
            document.getElementById('modalTitle').textContent = 'Create Project';
            document.getElementById('formAction').value = 'create';
            document.getElementById('projectForm').reset();
            document.getElementById('projectId').value = '';
            document.getElementById('progress').value = '0';
            document.getElementById('projectModal').classList.add('show');
        }

        function openEditModal(project) {
            document.getElementById('modalTitle').textContent = 'Edit Project';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('projectId').value = project.id;
            document.getElementById('title').value = project.title || '';
            document.getElementById('description').value = project.description || '';
            document.getElementById('status').value = project.status || 'Planning';
            document.getElementById('progress').value = project.progress || 0;
            document.getElementById('start_date').value = project.start_date || '';
            document.getElementById('target_date').value = project.target_date || '';
            document.getElementById('budget').value = project.budget || '';
            document.getElementById('contractor').value = project.contractor || '';
            document.getElementById('projectModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('projectModal').classList.remove('show');
        }

        function deleteProject(id) {
            if (confirm('Are you sure you want to delete this project?')) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }

        window.onclick = function(event) {
            const modal = document.getElementById('projectModal');
            if (event.target === modal) {
                closeModal();
            }
        }

        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>
