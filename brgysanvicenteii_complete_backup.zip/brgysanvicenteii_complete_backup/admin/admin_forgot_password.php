<?php
// admin/admin_forgot_password.php
session_start();
require '../config.php';

// If already logged in as admin, redirect to dashboard
if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
    header('Location: admin_dashboard.php');
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    
    // Validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } else {
        // Check if admin exists
        $stmt = $pdo->prepare("SELECT id, email, full_name FROM admins WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($admin) {
            // Generate reset token (simple approach - store in session)
            $reset_token = bin2hex(random_bytes(32));
            $_SESSION['reset_token'] = $reset_token;
            $_SESSION['reset_email'] = $email;
            $_SESSION['reset_expiry'] = time() + 3600; // 1 hour expiry
            
            // Redirect to reset password page
            header('Location: admin_reset_password.php');
            exit;
        } else {
            $error = 'No admin account found with this email address.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .modal-container {
            display: flex;
            width: 100%;
            max-width: 900px;
            min-height: 550px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.15);
            overflow: hidden;
            animation: slideUp 0.4s ease;
        }
        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .form-section {
            flex: 1;
            padding: 30px 25px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            background: #ffffff;
        }
        .visual-section {
            flex: 1;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 50%, #1a5f3f 100%);
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 30px 25px;
            overflow: hidden;
        }
        .visual-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: 
                repeating-linear-gradient(
                    45deg,
                    rgba(212, 175, 55, 0.1) 0px,
                    rgba(212, 175, 55, 0.1) 20px,
                    transparent 20px,
                    transparent 40px
                );
            opacity: 0.3;
        }
        .visual-content {
            position: relative;
            z-index: 1;
            text-align: center;
            color: white;
        }
        .visual-icon {
            width: 80px;
            height: 80px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 18px;
            backdrop-filter: blur(10px);
            border: 2px solid rgba(212, 175, 55, 0.3);
        }
        .visual-icon img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #d4af37;
        }
        .visual-quote {
            font-size: 16px;
            font-weight: 600;
            line-height: 1.4;
            margin-bottom: 18px;
            color: white;
        }
        .visual-author {
            font-size: 12px;
            font-weight: 500;
            color: rgba(255, 255, 255, 0.9);
        }
        .logo {
            text-align: center;
            margin-bottom: 18px;
        }
        .logo img {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #d4af37;
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        h1 {
            color: #1a5f3f;
            text-align: center;
            margin-bottom: 4px;
            font-size: 20px;
            font-weight: 700;
        }
        .subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 25px;
            font-size: 14px;
            line-height: 1.5;
        }
        .form-group {
            margin-bottom: 16px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #1a5f3f;
            font-weight: 600;
            font-size: 11px;
        }
        input[type="email"] {
            width: 100%;
            padding: 9px 11px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 12px;
            transition: all 0.3s;
            background: #fafafa;
        }
        input[type="email"]:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 13px;
            border-left: 4px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 15px;
            font-size: 13px;
            border-left: 4px solid #3c3;
        }
        .btn {
            width: 100%;
            padding: 10px;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 5px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(26, 95, 63, 0.3);
            background: linear-gradient(135deg, #2d7a52 0%, #1a5f3f 100%);
        }
        .btn:active {
            transform: translateY(0);
        }
        .links {
            text-align: center;
            margin-top: 12px;
            padding-top: 12px;
            border-top: 1px solid #e0e0e0;
        }
        .links a {
            color: #1a5f3f;
            text-decoration: none;
            font-size: 11px;
            transition: color 0.3s;
            font-weight: 500;
        }
        .links a:hover {
            color: #d4af37;
            text-decoration: underline;
        }
        .back-home {
            text-align: center;
            margin-top: 15px;
        }
        .back-home a {
            color: #666;
            text-decoration: none;
            font-size: 12px;
            transition: color 0.3s;
            display: inline-flex;
            align-items: center;
        }
        .back-home a:hover {
            color: #1a5f3f;
            text-decoration: underline;
        }
        /* Mobile Responsive */
        @media (max-width: 768px) {
            .modal-container {
                flex-direction: column;
                max-width: 100%;
                min-height: auto;
            }
            .visual-section {
                display: none;
            }
            .form-section {
                padding: 40px 30px;
            }
        }

        @media (max-width: 480px) {
            body {
                padding: 10px;
            }
            .form-section {
                padding: 30px 20px;
            }
            h1 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="modal-container">
        <div class="form-section">
            <div class="logo">
                <img src="../images/logo.jpg" alt="Barangay Logo">
            </div>
            <h1>Forgot Password</h1>
            <p class="subtitle">Enter your email address and we'll help you reset your password.</p>

            <?php if ($error): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="POST" action="" autocomplete="off">
                <div class="form-group">
                    <label for="email">Admin Email Address</label>
                    <input type="email" id="email" name="email" placeholder="Enter your admin email" autocomplete="off" required>
                </div>

                <button type="submit" class="btn">Continue</button>
            </form>

            <div class="links">
                <a href="admin_login.php">← Back to Login</a>
            </div>

            <div class="back-home">
                <a href="../index.php">
                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                        <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                    </svg>
                    Back to Home
                </a>
            </div>
        </div>

        <div class="visual-section">
            <div class="visual-content">
                <div class="visual-icon">
                    <img src="../images/logo.jpg" alt="Barangay Logo">
                </div>
                <div class="visual-quote">
                    "Don't worry, we've got you covered. Reset your password securely and get back to serving the community."
                </div>
                <div class="visual-author">
                    BARANGAY SAN VICENTE II
                </div>
            </div>
        </div>
    </div>
</body>
</html>

