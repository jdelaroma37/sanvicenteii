<?php
// admin/admin_activity_logs.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar - IMPORTANT: Set before including sidebar component
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Only super admin can access activity logs
if ($admin_role !== 'super_admin') {
    header('Location: admin_dashboard.php');
    exit;
}

// Load activity logs from database or JSON file
// For now, we'll use sample data structure that can be replaced with actual database queries
$logs_file = __DIR__ . '/../data/activity_logs.json';
$logs = [];
if (file_exists($logs_file)) {
    $logs = json_decode(file_get_contents($logs_file), true) ?? [];
}
if (!is_array($logs)) {
    $logs = [];
}

// Sample logs if empty (for demonstration)
if (empty($logs)) {
    $logs = [
        [
            'id' => 'L-2025-0001',
            'timestamp' => date('Y-m-d\TH:i:s', strtotime('-2 days')),
            'user' => 'Super Admin',
            'actor' => 'Super Admin',
            'action' => 'Created a new user account',
            'target' => 'Juan Dela Cruz (Barangay Staff)',
            'ip' => '192.168.1.10',
            'notes' => 'Initial account for encoding staff. Temporary password set.',
        ],
        [
            'id' => 'L-2025-0002',
            'timestamp' => date('Y-m-d\TH:i:s', strtotime('-1 day')),
            'user' => 'Super Admin',
            'actor' => 'Super Admin',
            'action' => 'Generated barangay clearance',
            'target' => 'Joseph Ramos',
            'ip' => '192.168.1.10',
            'notes' => 'Clearance #CL-2025-11024 issued; paid via GCASH TXN-2025-1004.',
        ],
        [
            'id' => 'L-2025-0003',
            'timestamp' => date('Y-m-d\TH:i:s', strtotime('-3 days')),
            'user' => 'Super Admin',
            'actor' => 'System',
            'action' => 'Performed database backup',
            'target' => 'Full backup (daily)',
            'ip' => '127.0.0.1',
            'notes' => 'Backup completed successfully (size: 120MB).',
        ],
        [
            'id' => 'L-2025-0004',
            'timestamp' => date('Y-m-d\TH:i:s', strtotime('-4 days')),
            'user' => 'Super Admin',
            'actor' => 'Super Admin',
            'action' => 'Updated resident information',
            'target' => 'Anna Lopez (Blk 3 Lot 21)',
            'ip' => '192.168.1.11',
            'notes' => 'Address corrected per submitted ID and Barangay Certification.',
        ],
    ];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activity Log - Barangay San Vicente II</title>
    <!-- React and ReactDOM -->
    <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
    <!-- Babel Standalone for JSX transformation -->
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a svg {
            flex-shrink: 0;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        /* Submenu */
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .page-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            background: #2c3e2d;
            color: white;
        }
        .page-actions .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .btn-secondary,
        .page-actions .btn-secondary {
            background: #4b5563 !important;
            color: white !important;
        }
        .btn-secondary:hover,
        .page-actions .btn-secondary:hover {
            background: #374151 !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(75, 85, 99, 0.3);
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <?php 
    // Ensure admin_role is set before including sidebar
    if (!isset($admin_role)) {
        $admin_id = $_SESSION['user_id'] ?? 0;
        if (isset($_SESSION['admin_role'])) {
            $admin_role = $_SESSION['admin_role'];
        } elseif (isset($pdo) && $admin_id) {
            try {
                $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
                $_SESSION['admin_role'] = $admin_role;
            } catch (Exception $e) {
                $admin_role = 'regular_admin';
            }
        } else {
            $admin_role = 'regular_admin';
        }
    }
    include 'admin_dashboard_sidebar.php'; 
    ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
            </span>
            Activity Logs
        </h1>

        <div class="page-actions">
            <button id="export-csv-btn" class="btn" onclick="exportActivityLogs();" style="background: #d4af37; color: white; border: none; cursor: pointer;" onmouseover="this.style.background='#e6c55a';" onmouseout="this.style.background='#d4af37';">Export CSV</button>
            <a href="admin_barangay_settings.php" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Barangay Settings
            </a>
        </div>

        <?php if ($error): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-4 rounded">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4 rounded">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>

        <div class="row-container">
            <!-- React Component Container -->
            <div id="activity-log-root"></div>
        </div>
    </div>

    <script type="text/babel">
        const { useState, useMemo } = React;

        // Sample logs data from PHP
        const SAMPLE_LOGS = <?php echo json_encode($logs, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT); ?>;

        function formatDate(iso) {
            const d = new Date(iso);
            return d.toLocaleString();
        }

        // Global variable to store filtered logs
        let globalFilteredLogs = [];

        function exportToCSV(rows) {
            const headers = [
                "ID",
                "Timestamp",
                "User",
                "Actor",
                "Action",
                "Target",
                "IP",
                "Notes",
            ];
            const csv = [headers.join(",")]
                .concat(
                    rows.map((r) =>
                        [
                            r.id,
                            r.timestamp,
                            r.user,
                            r.actor,
                            `"${r.action.replace(/"/g, '""')}"`,
                            `"${(r.target || "").replace(/"/g, '""')}"`,
                            r.ip,
                            `"${(r.notes || "").replace(/"/g, '""')}"`,
                        ].join(",")
                    )
                )
                .join("\n");
            const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `barangay-activity-logs-${new Date().toISOString()}.csv`;
            a.click();
            URL.revokeObjectURL(url);
        }

        // Global function to export from top button
        window.exportActivityLogs = function() {
            exportToCSV(globalFilteredLogs.length > 0 ? globalFilteredLogs : SAMPLE_LOGS);
        };

        // API ENDPOINTS (sample)
        // Replace with your actual backend URLs
        const API = {
            delete: (id) => fetch(`/api/logs/${id}`, { method: "DELETE" }),
            restore: (id) => fetch(`/api/logs/${id}/restore`, { method: "POST" }),
            review: (id) => fetch(`/api/logs/${id}/review`, { method: "POST" }),
        };

        function BarangayActivityLog() {
            const [query, setQuery] = useState("");
            const [actionFilter, setActionFilter] = useState("All");
            const [page, setPage] = useState(1);
            const [perPage] = useState(10);
            const [selected, setSelected] = useState(null);
            const [logs] = useState(SAMPLE_LOGS);

            const actions = useMemo(() => {
                const setA = new Set(logs.map((l) => l.action));
                return ["All", ...Array.from(setA)];
            }, [logs]);

            const filtered = useMemo(() => {
                const q = query.trim().toLowerCase();
                const result = logs.filter((l) => {
                    if (actionFilter !== "All" && l.action !== actionFilter) return false;
                    if (!q) return true;
                    return (
                        l.id.toLowerCase().includes(q) ||
                        l.user.toLowerCase().includes(q) ||
                        (l.target || "").toLowerCase().includes(q) ||
                        l.action.toLowerCase().includes(q) ||
                        (l.notes || "").toLowerCase().includes(q)
                    );
                });
                // Update global variable for export button
                globalFilteredLogs = result;
                return result;
            }, [logs, query, actionFilter]);

            const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
            const pageItems = filtered.slice((page - 1) * perPage, page * perPage);

            function openDetails(log) {
                setSelected(log);
            }

            function closeDetails() {
                setSelected(null);
            }

            return (
                <div style={{ padding: '0', minHeight: '100vh', background: '#f5f5f5' }}>
                    <header style={{ 
                        display: 'flex', 
                        justifyContent: 'space-between', 
                        alignItems: 'flex-start', 
                        marginBottom: '30px',
                        background: 'white',
                        padding: '25px 30px',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        borderLeft: '4px solid #d4af37'
                    }}>
                        <div>
                            <h1 style={{ 
                                fontSize: '26px', 
                                fontWeight: '800', 
                                color: '#2c3e2d',
                                marginBottom: '6px',
                                marginTop: '0',
                                letterSpacing: '-0.3px',
                                position: 'relative',
                                paddingLeft: '15px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px'
                            }}>
                                <span style={{
                                    position: 'absolute',
                                    left: '0',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    width: '4px',
                                    height: '30px',
                                    background: 'rgba(212, 175, 55, 0.6)',
                                    borderRadius: '2px'
                                }}></span>
                                Activity Log
                            </h1>
                            <p style={{ fontSize: '18px', color: '#6b7280', marginTop: '5px', fontWeight: '600' }}>
                                Bilang Super Admin, dito mo makikita at matutunton lahat ng mahahalagang gawain sa sistema.
                            </p>
                        </div>
                    </header>

                    <section style={{
                        background: 'white',
                        padding: '20px',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        marginBottom: '25px'
                    }}>
                        <div style={{ display: 'flex', gap: '15px', alignItems: 'center', flexWrap: 'wrap' }}>
                            <input
                                value={query}
                                onChange={(e) => { setQuery(e.target.value); setPage(1); }}
                                placeholder="Hanapin ang ID, user, action o target..."
                                style={{
                                    flex: '1',
                                    minWidth: '250px',
                                    padding: '12px',
                                    border: '2px solid #e0e0e0',
                                    borderRadius: '8px',
                                    fontSize: '14px',
                                    transition: 'all 0.3s',
                                    background: '#fafafa'
                                }}
                                onFocus={(e) => {
                                    e.target.style.borderColor = '#d4af37';
                                    e.target.style.background = '#fff';
                                    e.target.style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                                }}
                                onBlur={(e) => {
                                    e.target.style.borderColor = '#e0e0e0';
                                    e.target.style.background = '#fafafa';
                                    e.target.style.boxShadow = 'none';
                                }}
                            />
                            <select
                                value={actionFilter}
                                onChange={(e) => { setActionFilter(e.target.value); setPage(1); }}
                                style={{
                                    padding: '12px',
                                    border: '2px solid #e0e0e0',
                                    borderRadius: '8px',
                                    fontSize: '14px',
                                    background: '#fafafa',
                                    cursor: 'pointer',
                                    transition: 'all 0.3s'
                                }}
                                onFocus={(e) => {
                                    e.target.style.borderColor = '#d4af37';
                                    e.target.style.background = '#fff';
                                    e.target.style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                                }}
                                onBlur={(e) => {
                                    e.target.style.borderColor = '#e0e0e0';
                                    e.target.style.background = '#fafafa';
                                    e.target.style.boxShadow = 'none';
                                }}
                            >
                                {actions.map((a) => (
                                    <option key={a} value={a}>{a}</option>
                                ))}
                            </select>
                            <div style={{ 
                                fontSize: '14px', 
                                color: '#6b7280',
                                padding: '12px 20px',
                                background: 'rgba(212, 175, 55, 0.1)',
                                borderRadius: '8px',
                                fontWeight: '600'
                            }}>
                                Total: <strong style={{ color: '#2c3e2d', fontWeight: '700' }}>{filtered.length}</strong>
                            </div>
                        </div>
                    </section>

                    <section style={{
                        background: 'white',
                        borderRadius: '12px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        overflow: 'hidden'
                    }}>
                        <table style={{ width: '100%', fontSize: '14px', borderCollapse: 'collapse' }}>
                            <thead style={{ background: '#2c3e2d' }}>
                                <tr style={{ textAlign: 'left' }}>
                                    <th style={{ padding: '15px 20px', color: 'white', fontWeight: '600', borderBottom: '2px solid rgba(212, 175, 55, 0.3)' }}>Timestamp</th>
                                    <th style={{ padding: '15px 20px', color: 'white', fontWeight: '600', borderBottom: '2px solid rgba(212, 175, 55, 0.3)' }}>User</th>
                                    <th style={{ padding: '15px 20px', color: 'white', fontWeight: '600', borderBottom: '2px solid rgba(212, 175, 55, 0.3)' }}>Action</th>
                                    <th style={{ padding: '15px 20px', color: 'white', fontWeight: '600', borderBottom: '2px solid rgba(212, 175, 55, 0.3)' }}>Target</th>
                                    <th style={{ padding: '15px 20px', color: 'white', fontWeight: '600', borderBottom: '2px solid rgba(212, 175, 55, 0.3)' }}>IP</th>
                                    <th style={{ padding: '15px 20px', color: 'white', fontWeight: '600', borderBottom: '2px solid rgba(212, 175, 55, 0.3)' }}>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                {pageItems.length === 0 && (
                                    <tr>
                                        <td colSpan={6} style={{ padding: '40px 20px', textAlign: 'center', color: '#6b7280', fontSize: '14px', fontWeight: '500' }}>
                                            Walang tala para sa kasalukuyang filter.
                                        </td>
                                    </tr>
                                )}
                                {pageItems.map((log, idx) => (
                                    <tr 
                                        key={log.id} 
                                        style={{ 
                                            borderTop: idx > 0 ? '1px solid #e0e0e0' : 'none',
                                            transition: 'background 0.2s'
                                        }}
                                        onMouseEnter={(e) => e.target.style.background = '#f9f9f9'}
                                        onMouseLeave={(e) => e.target.style.background = 'transparent'}
                                    >
                                        <td style={{ padding: '15px 20px', verticalAlign: 'top', color: '#4b5563', fontSize: '14px' }}>
                                            {formatDate(log.timestamp)}
                                        </td>
                                        <td style={{ padding: '15px 20px', verticalAlign: 'top' }}>
                                            <div style={{ fontWeight: '700', color: '#2c3e2d', marginBottom: '4px', fontSize: '14px' }}>
                                                {log.user}
                                            </div>
                                            <div style={{ fontSize: '13px', color: '#6b7280', fontWeight: '500' }}>{log.actor}</div>
                                        </td>
                                        <td style={{ padding: '15px 20px', verticalAlign: 'top', color: '#4b5563', fontSize: '14px' }}>
                                            {log.action}
                                        </td>
                                        <td style={{ padding: '15px 20px', verticalAlign: 'top', color: '#4b5563', fontSize: '14px' }}>
                                            {log.target}
                                        </td>
                                        <td style={{ padding: '15px 20px', verticalAlign: 'top', color: '#4b5563', fontFamily: 'monospace', fontSize: '13px' }}>
                                            {log.ip}
                                        </td>
                                        <td style={{ padding: '15px 20px', verticalAlign: 'top' }}>
                                            <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                                                <button
                                                    onClick={() => openDetails(log)}
                                                    style={{
                                                        padding: '8px 12px',
                                                        border: '2px solid #1a5f3f',
                                                        background: 'transparent',
                                                        color: '#1a5f3f',
                                                        borderRadius: '6px',
                                                        fontSize: '13px',
                                                        fontWeight: '600',
                                                        cursor: 'pointer',
                                                        width: '100%',
                                                        transition: 'all 0.3s'
                                                    }}
                                                    onMouseEnter={(e) => {
                                                        e.target.style.background = '#1a5f3f';
                                                        e.target.style.color = 'white';
                                                    }}
                                                    onMouseLeave={(e) => {
                                                        e.target.style.background = 'transparent';
                                                        e.target.style.color = '#1a5f3f';
                                                    }}
                                                >
                                                    View
                                                </button>
                                                <button
                                                    onClick={() => API.delete(log.id)}
                                                    style={{
                                                        padding: '8px 12px',
                                                        border: '2px solid #c33',
                                                        background: 'transparent',
                                                        color: '#c33',
                                                        borderRadius: '6px',
                                                        fontSize: '13px',
                                                        fontWeight: '600',
                                                        cursor: 'pointer',
                                                        width: '100%',
                                                        transition: 'all 0.3s'
                                                    }}
                                                    onMouseEnter={(e) => {
                                                        e.target.style.background = '#c33';
                                                        e.target.style.color = 'white';
                                                    }}
                                                    onMouseLeave={(e) => {
                                                        e.target.style.background = 'transparent';
                                                        e.target.style.color = '#c33';
                                                    }}
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>

                        <div style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            padding: '15px 20px',
                            borderTop: '2px solid #e0e0e0',
                            background: '#f9f9f9'
                        }}>
                            <div style={{ fontSize: '14px', color: '#666' }}>
                                Page {page} of {totalPages}
                            </div>
                            <div style={{ display: 'flex', gap: '10px' }}>
                                <button
                                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                                    disabled={page === 1}
                                    style={{
                                        padding: '8px 16px',
                                        border: '2px solid #1a5f3f',
                                        background: page === 1 ? '#e0e0e0' : 'transparent',
                                        color: page === 1 ? '#999' : '#1a5f3f',
                                        borderRadius: '6px',
                                        fontSize: '14px',
                                        fontWeight: '600',
                                        cursor: page === 1 ? 'not-allowed' : 'pointer',
                                        transition: 'all 0.3s'
                                    }}
                                    onMouseEnter={(e) => {
                                        if (page !== 1) {
                                            e.target.style.background = '#1a5f3f';
                                            e.target.style.color = 'white';
                                        }
                                    }}
                                    onMouseLeave={(e) => {
                                        if (page !== 1) {
                                            e.target.style.background = 'transparent';
                                            e.target.style.color = '#1a5f3f';
                                        }
                                    }}
                                >
                                    Prev
                                </button>
                                <button
                                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                                    disabled={page === totalPages}
                                    style={{
                                        padding: '8px 16px',
                                        border: '2px solid #1a5f3f',
                                        background: page === totalPages ? '#e0e0e0' : 'transparent',
                                        color: page === totalPages ? '#999' : '#1a5f3f',
                                        borderRadius: '6px',
                                        fontSize: '14px',
                                        fontWeight: '600',
                                        cursor: page === totalPages ? 'not-allowed' : 'pointer',
                                        transition: 'all 0.3s'
                                    }}
                                    onMouseEnter={(e) => {
                                        if (page !== totalPages) {
                                            e.target.style.background = '#1a5f3f';
                                            e.target.style.color = 'white';
                                        }
                                    }}
                                    onMouseLeave={(e) => {
                                        if (page !== totalPages) {
                                            e.target.style.background = 'transparent';
                                            e.target.style.color = '#1a5f3f';
                                        }
                                    }}
                                >
                                    Next
                                </button>
                            </div>
                        </div>
                    </section>

                    {/* Details Modal */}
                    {selected && (
                        <div style={{
                            position: 'fixed',
                            inset: '0',
                            zIndex: '1000',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            padding: '20px'
                        }}>
                            <div 
                                style={{
                                    position: 'absolute',
                                    inset: '0',
                                    background: 'rgba(0,0,0,0.5)'
                                }}
                                onClick={closeDetails}
                            ></div>
                            <div style={{
                                background: 'white',
                                borderRadius: '12px',
                                boxShadow: '0 10px 40px rgba(0,0,0,0.3)',
                                maxWidth: '700px',
                                width: '100%',
                                padding: '35px',
                                position: 'relative',
                                zIndex: '10',
                                borderLeft: '4px solid #d4af37'
                            }}>
                                <div style={{
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'flex-start',
                                    marginBottom: '25px',
                                    paddingBottom: '15px',
                                    borderBottom: '2px solid #e0e0e0'
                                }}>
                                    <div>
                                        <h2 style={{
                                            fontSize: '26px',
                                            color: '#2c3e2d',
                                            fontWeight: '800',
                                            marginBottom: '5px',
                                            position: 'relative',
                                            paddingBottom: '10px',
                                            letterSpacing: '-0.3px'
                                        }}>
                                            <span style={{
                                                position: 'absolute',
                                                bottom: '0',
                                                left: '0',
                                                width: '60px',
                                                height: '3px',
                                                background: 'linear-gradient(90deg, #d4af37 0%, #e6c55a 100%)',
                                                borderRadius: '2px'
                                            }}></span>
                                            Log Details
                                        </h2>
                                        <p style={{ fontSize: '13px', color: '#666', marginTop: '8px' }}>
                                            ID: {selected.id}
                                        </p>
                                    </div>
                                    <button 
                                        onClick={closeDetails}
                                        style={{
                                            background: 'none',
                                            border: 'none',
                                            color: '#999',
                                            fontSize: '24px',
                                            cursor: 'pointer',
                                            padding: '4px',
                                            lineHeight: '1',
                                            transition: 'color 0.3s'
                                        }}
                                        onMouseEnter={(e) => e.target.style.color = '#c33'}
                                        onMouseLeave={(e) => e.target.style.color = '#999'}
                                    >
                                        ×
                                    </button>
                                </div>
                                <div style={{
                                    display: 'grid',
                                    gridTemplateColumns: '1fr 1fr',
                                    gap: '20px',
                                    fontSize: '14px',
                                    color: '#333'
                                }}>
                                    <div>
                                        <div style={{ fontSize: '14px', color: '#2c3e2d', marginBottom: '8px', fontWeight: '600' }}>
                                            Timestamp
                                        </div>
                                        <div style={{ color: '#4b5563', fontSize: '14px' }}>{formatDate(selected.timestamp)}</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '14px', color: '#2c3e2d', marginBottom: '8px', fontWeight: '600' }}>
                                            User / Actor
                                        </div>
                                        <div style={{ color: '#4b5563', fontSize: '14px' }}>{selected.user} / {selected.actor}</div>
                                    </div>
                                    <div style={{ gridColumn: '1 / -1' }}>
                                        <div style={{ fontSize: '14px', color: '#2c3e2d', marginBottom: '8px', fontWeight: '600' }}>
                                            Action
                                        </div>
                                        <div style={{ color: '#2c3e2d', fontWeight: '700', fontSize: '14px' }}>
                                            {selected.action}
                                        </div>
                                    </div>
                                    <div style={{ gridColumn: '1 / -1' }}>
                                        <div style={{ fontSize: '14px', color: '#2c3e2d', marginBottom: '8px', fontWeight: '600' }}>
                                            Target
                                        </div>
                                        <div style={{ color: '#4b5563', fontSize: '14px' }}>{selected.target}</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '14px', color: '#2c3e2d', marginBottom: '8px', fontWeight: '600' }}>
                                            IP Address
                                        </div>
                                        <div style={{ color: '#4b5563', fontFamily: 'monospace', fontSize: '13px' }}>
                                            {selected.ip}
                                        </div>
                                    </div>
                                    <div style={{ gridColumn: '1 / -1' }}>
                                        <div style={{ fontSize: '14px', color: '#2c3e2d', marginBottom: '8px', fontWeight: '600' }}>
                                            Notes
                                        </div>
                                        <div style={{
                                            color: '#4b5563',
                                            whiteSpace: 'pre-wrap',
                                            fontSize: '14px',
                                            lineHeight: '1.6',
                                            padding: '12px',
                                            background: '#f9f9f9',
                                            borderRadius: '6px',
                                            border: '1px solid #e0e0e0'
                                        }}>
                                            {selected.notes}
                                        </div>
                                    </div>
                                </div>
                                <div style={{
                                    marginTop: '30px',
                                    display: 'flex',
                                    justifyContent: 'flex-end',
                                    gap: '10px'
                                }}>
                                    <button 
                                        onClick={closeDetails}
                                        style={{
                                            padding: '12px 24px',
                                            background: 'linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%)',
                                            color: 'white',
                                            border: 'none',
                                            borderRadius: '8px',
                                            fontSize: '14px',
                                            fontWeight: '600',
                                            cursor: 'pointer',
                                            transition: 'all 0.3s',
                                            boxShadow: '0 4px 6px rgba(0,0,0,0.1)'
                                        }}
                                        onMouseEnter={(e) => {
                                            e.target.style.transform = 'translateY(-2px)';
                                            e.target.style.boxShadow = '0 6px 12px rgba(26, 95, 63, 0.3)';
                                        }}
                                        onMouseLeave={(e) => {
                                            e.target.style.transform = 'translateY(0)';
                                            e.target.style.boxShadow = '0 4px 6px rgba(0,0,0,0.1)';
                                        }}
                                    >
                                        Close
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            );
        }

        // Render the component
        const root = ReactDOM.createRoot(document.getElementById('activity-log-root'));
        root.render(<BarangayActivityLog />);
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>
