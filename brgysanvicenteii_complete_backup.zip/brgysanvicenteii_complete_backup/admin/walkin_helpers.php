<?php
// Helper functions for walk-in requests

/**
 * Generate a unique request number in format: WR-YYYY-NNNN
 * Example: WR-2025-0193
 */
function generateWalkInRequestNumber($pdo) {
    $year = date('Y');
    
    // Get the last request number for this year
    $stmt = $pdo->prepare("SELECT request_number FROM walk_in_requests WHERE request_number LIKE ? ORDER BY request_number DESC LIMIT 1");
    $pattern = "WR-{$year}-%";
    $stmt->execute([$pattern]);
    $last_request = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($last_request) {
        // Extract the number part
        $parts = explode('-', $last_request['request_number']);
        $last_number = intval($parts[2] ?? 0);
        $new_number = $last_number + 1;
    } else {
        $new_number = 1;
    }
    
    // Format with leading zeros (4 digits)
    $formatted_number = str_pad($new_number, 4, '0', STR_PAD_LEFT);
    
    return "WR-{$year}-{$formatted_number}";
}

/**
 * Create a walk-in request (for use in resident submission forms)
 */
function createWalkInRequest($pdo, $data) {
    $request_number = generateWalkInRequestNumber($pdo);
    
    $stmt = $pdo->prepare("INSERT INTO walk_in_requests 
        (request_number, resident_id, resident_name, resident_email, resident_contact, 
         category, type, description, attachment_url, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')");
    
    $stmt->execute([
        $request_number,
        $data['resident_id'] ?? null,
        $data['resident_name'],
        $data['resident_email'] ?? null,
        $data['resident_contact'] ?? null,
        $data['category'],
        $data['type'],
        $data['description'] ?? '',
        $data['attachment_url'] ?? null
    ]);
    
    $request_id = $pdo->lastInsertId();
    
    // Send notification to admin using helper function
    if (file_exists(__DIR__ . '/admin_notification_helper.php')) {
        require_once __DIR__ . '/admin_notification_helper.php';
        createAdminNotification(
            'new_walkin_request',
            'New Walk-In Request',
            "New Walk-In Request from {$data['resident_name']} – Request #{$request_number}",
            'all',
            [
                'request_id' => $request_id,
                'request_number' => $request_number,
                'resident_name' => $data['resident_name']
            ]
        );
    }
    
    return [
        'request_id' => $request_id,
        'request_number' => $request_number
    ];
}

