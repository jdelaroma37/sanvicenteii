<?php
// admin/admin_system_info.php - Super Admin Only
session_start();
require '../config.php';
require 'role_helper.php';

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';

if ($admin_role !== 'super_admin') {
    $_SESSION['error'] = 'Access denied. Only Super Admins can view system information.';
    header('Location: admin_dashboard.php');
    exit;
}

// Get system info
$php_version = phpversion();
$mysql_version = $pdo->query("SELECT VERSION()")->fetchColumn();
$server_software = $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>System Info - Barangay San Vicente II</title>
    <link rel="stylesheet" href="css/admin_dashboard.css">
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">ℹ️ System Information</h1>
        
        <div class="content-card" style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-top: 30px;">
            <h2 style="color: #1a5f3f; margin-bottom: 20px;">🖥️ Server Information</h2>
            
            <div style="display: grid; gap: 15px;">
                <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #1a5f3f;">
                    <strong style="color: #1a5f3f;">PHP Version:</strong>
                    <span style="color: #666; margin-left: 10px;"><?php echo htmlspecialchars($php_version); ?></span>
                </div>
                <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #2d7a52;">
                    <strong style="color: #1a5f3f;">MySQL Version:</strong>
                    <span style="color: #666; margin-left: 10px;"><?php echo htmlspecialchars($mysql_version); ?></span>
                </div>
                <div style="padding: 15px; background: #f8f9fa; border-radius: 8px; border-left: 4px solid #d4af37;">
                    <strong style="color: #1a5f3f;">Server Software:</strong>
                    <span style="color: #666; margin-left: 10px;"><?php echo htmlspecialchars($server_software); ?></span>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

