<?php
// admin/mark_notification_read.php
session_start();
require '../config.php';
require 'role_helper.php';
header('Content-Type: application/json');

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['index']) || !is_numeric($input['index'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

$index = intval($input['index']);

// Load admin notifications
$notifDir = __DIR__ . '/../data/notifications';
if (!is_dir($notifDir)) mkdir($notifDir, 0777, true);
$adminNotifFile = $notifDir . '/admin_notifications.json';

$admin_notifications = [];
if (file_exists($adminNotifFile)) {
    $admin_notifications = json_decode(file_get_contents($adminNotifFile), true) ?? [];
}

// Check if index is valid
if (!isset($admin_notifications[$index])) {
    echo json_encode(['status' => 'error', 'message' => 'Notification not found']);
    exit;
}

// Mark as read
$admin_notifications[$index]['read'] = true;

// Save to file
$result = file_put_contents($adminNotifFile, json_encode($admin_notifications, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

if ($result !== false) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to save notification']);
}
?>

