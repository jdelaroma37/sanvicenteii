<?php
// admin/admin_residents.php
session_start();
require '../config.php';
require 'role_helper.php';
require_once __DIR__ . '/../lang/language_helper.php';

// Fixed barangay name for all records
$fixedBarangay = 'San Vicente II';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Check if columns exist
$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'deleted_at'")->fetch();
$deleted_at_exists = !empty($columns_check);

$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'account_status'")->fetch();
$account_status_exists = !empty($columns_check);

// Handle inline actions (edit/delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $resident_id = isset($_POST['resident_id']) ? (int) $_POST['resident_id'] : 0;

    if ($resident_id <= 0) {
        $_SESSION['error'] = 'Invalid resident selected.';
        header('Location: admin_residents.php');
        exit;
    }

    if ($action === 'delete') {
        try {
            if ($deleted_at_exists) {
                $stmt = $pdo->prepare("UPDATE residents SET deleted_at = NOW() WHERE id = ?");
                $stmt->execute([$resident_id]);
            } else {
                $stmt = $pdo->prepare("DELETE FROM residents WHERE id = ?");
                $stmt->execute([$resident_id]);
            }
            $_SESSION['success'] = 'Resident has been removed.';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Failed to delete resident: ' . $e->getMessage();
        }
        header('Location: admin_residents.php');
        exit;
    }

    if ($action === 'update') {
        $email = trim($_POST['email'] ?? '');
        $contact_number = trim($_POST['contact_number'] ?? '');
        $civil_status = trim($_POST['civil_status'] ?? '');
        $home_number = trim($_POST['home_number'] ?? '');
        $street = trim($_POST['street'] ?? '');
        $barangay = $fixedBarangay;
        $municipality = trim($_POST['municipality'] ?? '');
        $city_province = trim($_POST['city_province'] ?? '');

        $update_fields = [
            'email' => $email,
            'contact_number' => $contact_number,
            'civil_status' => $civil_status,
            'home_number' => $home_number,
            'street' => $street,
            'barangay' => $barangay,
            'municipality' => $municipality,
            'city_province' => $city_province
        ];

        if ($account_status_exists) {
            $account_status = trim($_POST['account_status'] ?? 'Pending Verification');
            $update_fields['account_status'] = $account_status;
        }

        $set_parts = [];
        $params = [];
        foreach ($update_fields as $column => $value) {
            $set_parts[] = "$column = ?";
            $params[] = $value;
        }
        $params[] = $resident_id;

        try {
            $stmt = $pdo->prepare("UPDATE residents SET " . implode(', ', $set_parts) . " WHERE id = ?");
            $stmt->execute($params);
            $_SESSION['success'] = 'Resident details updated.';
        } catch (Exception $e) {
            $_SESSION['error'] = 'Failed to update resident: ' . $e->getMessage();
        }
        header('Location: admin_residents.php');
        exit;
    }
}

// Get search and filter parameters
$search = $_GET['search'] ?? '';
$status_filter = $_GET['status'] ?? 'all';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Build query
$where_conditions = [];
$params = [];

if ($deleted_at_exists) {
    $where_conditions[] = "COALESCE(deleted_at, '') = ''";
}

if (!empty($search)) {
    $where_conditions[] = "(first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR contact_number LIKE ?)";
    $search_param = "%{$search}%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param, $search_param]);
}

if ($status_filter !== 'all' && $account_status_exists) {
    if ($status_filter === 'active') {
        $where_conditions[] = "COALESCE(account_status, 'Pending Verification') = 'Active'";
    } elseif ($status_filter === 'pending') {
        $where_conditions[] = "COALESCE(account_status, 'Pending Verification') = 'Pending Verification'";
    } elseif ($status_filter === 'inactive') {
        $where_conditions[] = "COALESCE(account_status, 'Pending Verification') = 'Inactive'";
    }
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_query = "SELECT COUNT(*) as total FROM residents $where_clause";
$count_stmt = $pdo->prepare($count_query);
$count_stmt->execute($params);
$total_residents = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_residents / $per_page);

// Get residents
// Use integers directly for LIMIT and OFFSET since they're safe (not user input)
$select_fields = "id, photo, first_name, middle_name, last_name, suffix, email, contact_number, 
         date_of_birth, gender, civil_status, home_number, street, barangay, municipality, city_province, place_of_birth, religion, nationality, created_at";
if ($account_status_exists) {
    $select_fields .= ", account_status";
}
$query = "SELECT $select_fields 
         FROM residents $where_clause 
         ORDER BY created_at DESC 
         LIMIT " . intval($per_page) . " OFFSET " . intval($offset);
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$residents = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
if ($account_status_exists) {
    $stats_query = "SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN COALESCE(account_status, 'Pending Verification') = 'Active' THEN 1 ELSE 0 END) as active,
        SUM(CASE WHEN COALESCE(account_status, 'Pending Verification') = 'Pending Verification' THEN 1 ELSE 0 END) as pending
        FROM residents";
    if ($deleted_at_exists) {
        $stats_query .= " WHERE COALESCE(deleted_at, '') = ''";
    }
} else {
    // If account_status column doesn't exist, treat all as active
    $stats_query = "SELECT 
        COUNT(*) as total,
        COUNT(*) as active,
        0 as pending
        FROM residents";
    if ($deleted_at_exists) {
        $stats_query .= " WHERE COALESCE(deleted_at, '') = ''";
    }
}
$stats = $pdo->query($stats_query)->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars(trans('nav_residents')); ?> - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .main-content {
            flex: 1;
            margin-right: 280px;
            padding: 30px;
            transition: margin-right 0.3s ease;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #1f7a45;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1f7a45 0%, #156238 100%);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(21, 98, 56, 0.35);
            background: linear-gradient(135deg, #156238 0%, #0f4d2c 100%);
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3c3;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .stat-card .value {
            color: #87A96B;
            font-size: 32px;
            font-weight: bold;
        }
        .filters {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filters input[type="text"] {
            flex: 1;
            min-width: 200px;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
        }
        .filters select {
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            background: white;
        }
        .filters button {
            padding: 12px 24px;
            background: #87A96B;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        .filters button:hover {
            background: #7a9660;
        }
        .residents-table {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .table-header {
            background: #87A96B;
            color: white;
            padding: 15px 20px;
            font-weight: 600;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: #f8f9fa;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #2c3e50;
            border-bottom: 2px solid #e0e0e0;
        }
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .resident-photo {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
        }
        .resident-name {
            font-weight: 600;
            color: #2c3e50;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-active {
            background: #d4edda;
            color: #155724;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .status-inactive {
            background: #f8d7da;
            color: #721c24;
        }
        .actions-cell {
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        .action-btn {
            border: 1px solid transparent;
            padding: 8px 12px;
            border-radius: 10px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .action-view {
            background: #ecf4e7;
            color: #2c3e2d;
            border-color: #d8e5d0;
        }
        .action-edit {
            background: #fff7e0;
            color: #8a5b00;
            border-color: #f2dfa4;
        }
        .action-delete {
            background: #fdecec;
            color: #b13232;
            border-color: #f6c7c7;
        }
        .action-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.08);
        }
        .dashboard-modal {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.45);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.2s ease, visibility 0.2s ease;
            z-index: 2000;
        }
        .dashboard-modal.show {
            opacity: 1;
            visibility: visible;
        }
        .modal-card {
            background: #fff;
            border-radius: 14px;
            width: min(820px, 100%);
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 18px 40px rgba(44,62,45,0.16);
            border: 1px solid #e6eedf;
        }
        .modal-card.compact {
            width: min(520px, 100%);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 18px 22px;
            border-bottom: 1px solid #e6eedf;
            background: linear-gradient(135deg, #8fb27b 0%, #7b9f65 100%);
            color: #0c1a0e;
        }
        .modal-header h3 {
            font-size: 18px;
            font-weight: 800;
            color: #0c1a0e;
        }
        .modal-subtitle {
            margin-top: 4px;
            font-size: 13px;
            color: #0c1a0e;
            opacity: 0.85;
        }
        .close-modal {
            background: rgba(255,255,255,0.85);
            border: none;
            border-radius: 50%;
            width: 34px;
            height: 34px;
            display: grid;
            place-items: center;
            font-size: 18px;
            font-weight: 700;
            cursor: pointer;
            color: #2c3e2d;
        }
        .modal-body {
            padding: 22px;
            display: grid;
            gap: 16px;
        }
        .modal-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
        }
        .info-tile {
            background: #f7faf4;
            border: 1px solid #e6eedf;
            border-radius: 10px;
            padding: 12px 14px;
        }
        .info-label {
            font-size: 12px;
            color: #6b7a6d;
            text-transform: uppercase;
            letter-spacing: 0.4px;
            margin-bottom: 4px;
        }
        .info-value {
            font-size: 14px;
            color: #1f2b20;
            font-weight: 700;
        }
        .avatar-stack {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .avatar-stack .avatar {
            width: 64px;
            height: 64px;
            border-radius: 12px;
            background: #87A96B;
            color: #0c1a0e;
            font-weight: 800;
            font-size: 20px;
            display: grid;
            place-items: center;
            overflow: hidden;
            border: 3px solid #e6eedf;
        }
        .avatar-stack .avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 6px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            gap: 6px;
            width: fit-content;
        }
        .badge.success {
            background: #d4edda;
            color: #155724;
        }
        .badge.warning {
            background: #fff3cd;
            color: #856404;
        }
        .badge.danger {
            background: #f8d7da;
            color: #721c24;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 14px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }
        .form-group label {
            font-size: 13px;
            font-weight: 600;
            color: #1f2b20;
        }
        .form-group input,
        .form-group select {
            padding: 11px 12px;
            border-radius: 10px;
            border: 1px solid #d8e5d0;
            background: #fdfefc;
            font-size: 14px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 6px;
        }
        .btn-soft {
            border: 1px solid #d8e5d0;
            background: #f7faf4;
            color: #2c3e2d;
            padding: 10px 16px;
            border-radius: 10px;
            font-weight: 700;
            cursor: pointer;
        }
        .btn-cta {
            background: linear-gradient(135deg, #2c3e2d 0%, #1a2e1b 100%);
            color: #fff;
            border: none;
            padding: 11px 18px;
            border-radius: 10px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 8px 16px rgba(44,62,45,0.25);
        }
        .btn-danger {
            background: #c33;
            color: #fff;
            border: none;
            padding: 11px 18px;
            border-radius: 10px;
            font-weight: 800;
            cursor: pointer;
            box-shadow: 0 8px 16px rgba(195,51,51,0.25);
        }
        body.modal-open {
            overflow: hidden;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
            padding: 20px;
        }
        .pagination a, .pagination span {
            padding: 10px 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            text-decoration: none;
            color: #2c3e50;
        }
        .pagination a:hover {
            background: #87A96B;
            color: white;
            border-color: #87A96B;
        }
        .pagination .current {
            background: #87A96B;
            color: white;
            border-color: #87A96B;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .empty-state svg {
            width: 80px;
            height: 80px;
            margin-bottom: 20px;
            opacity: 0.5;
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </span>
            <?php echo htmlspecialchars(trans('nav_residents')); ?>
        </h1>

        <div class="page-actions">
            <a href="admin_residents_voters.php" class="btn btn-primary">
                <?php echo htmlspecialchars(trans('nav_residents_voters')); ?>
            </a>
            <a href="admin_residents_registered.php" class="btn btn-primary">
                <?php echo htmlspecialchars(trans('nav_residents_registered')); ?>
            </a>
            <a href="admin_residents_archive.php" class="btn btn-primary">
                <?php echo htmlspecialchars(trans('nav_residents_archive')); ?>
            </a>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Residents</h3>
                <div class="value"><?php echo number_format($stats['total'] ?? 0); ?></div>
            </div>
            <div class="stat-card">
                <h3>Active</h3>
                <div class="value"><?php echo number_format($stats['active'] ?? 0); ?></div>
            </div>
            <div class="stat-card">
                <h3>Pending</h3>
                <div class="value"><?php echo number_format($stats['pending'] ?? 0); ?></div>
            </div>
        </div>

        <div class="filters">
            <form method="GET" action="" style="display: flex; gap: 15px; flex: 1; flex-wrap: wrap; align-items: center;">
                <input type="text" name="search" placeholder="Search by name, email, or contact..." value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; min-width: 200px;">
                <select name="status">
                    <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Status</option>
                    <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                    <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="inactive" <?php echo $status_filter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                </select>
                <button type="submit">Search</button>
                <?php if ($search || $status_filter !== 'all'): ?>
                    <a href="admin_residents.php" style="padding: 12px 24px; background: #6c757d; color: white; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 600;">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="residents-table">
            <div class="table-header">
                Residents List (<?php echo number_format($total_residents); ?> total)
            </div>
            <?php if (empty($residents)): ?>
                <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    <h3>No residents found</h3>
                    <p><?php echo $search ? 'Try adjusting your search criteria.' : 'No residents registered yet.'; ?></p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Date of Birth</th>
                            <th>Gender</th>
                            <th>Status</th>
                            <th>Registered</th>
                            <th style="text-align:right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($residents as $resident): 
                            $full_name = trim($resident['first_name'] . ' ' . ($resident['middle_name'] ?? '') . ' ' . $resident['last_name'] . ' ' . ($resident['suffix'] ?? ''));
                            $status = $account_status_exists ? ($resident['account_status'] ?? 'Pending Verification') : 'Active';
                            $status_class = 'status-pending';
                            if ($status === 'Active') $status_class = 'status-active';
                            elseif ($status === 'Inactive') $status_class = 'status-inactive';

                            // Normalize photo path so resident/admin views match
                            $photo_raw = trim($resident['photo'] ?? '');
                            $photo_normalized = '';
                            if (!empty($photo_raw)) {
                                if (file_exists('../' . ltrim($photo_raw, '/\\'))) {
                                    $photo_normalized = '../' . ltrim($photo_raw, '/\\');
                                } elseif (file_exists('../uploads/' . ltrim($photo_raw, '/\\'))) {
                                    $photo_normalized = '../uploads/' . ltrim($photo_raw, '/\\');
                                }
                            }
                        ?>
                            <tr>
                                <td>
                                    <?php if (!empty($photo_normalized)): ?>
                                        <img src="<?php echo htmlspecialchars($photo_normalized); ?>" alt="<?php echo htmlspecialchars($full_name); ?>" class="resident-photo">
                                    <?php else: ?>
                                        <div class="resident-photo" style="background: #87A96B; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                                            <?php echo strtoupper(substr($resident['first_name'], 0, 1)); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="resident-name"><?php echo htmlspecialchars($full_name); ?></div>
                                </td>
                                <td><?php echo htmlspecialchars($resident['email'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($resident['contact_number'] ?? 'N/A'); ?></td>
                                <td><?php echo $resident['date_of_birth'] ? date('M d, Y', strtotime($resident['date_of_birth'])) : 'N/A'; ?></td>
                                <td><?php echo htmlspecialchars($resident['gender'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $status_class; ?>">
                                        <?php echo htmlspecialchars($status); ?>
                                    </span>
                                </td>
                                <td><?php echo $resident['created_at'] ? date('M d, Y', strtotime($resident['created_at'])) : 'N/A'; ?></td>
                                <td class="actions-cell" style="justify-content: flex-end;">
                                    <button
                                        class="action-btn action-view"
                                        data-id="<?php echo (int) $resident['id']; ?>"
                                        data-first="<?php echo htmlspecialchars($resident['first_name'] ?? ''); ?>"
                                        data-middle="<?php echo htmlspecialchars($resident['middle_name'] ?? ''); ?>"
                                        data-last="<?php echo htmlspecialchars($resident['last_name'] ?? ''); ?>"
                                        data-suffix="<?php echo htmlspecialchars($resident['suffix'] ?? ''); ?>"
                                        data-email="<?php echo htmlspecialchars($resident['email'] ?? ''); ?>"
                                        data-contact="<?php echo htmlspecialchars($resident['contact_number'] ?? ''); ?>"
                                        data-dob="<?php echo htmlspecialchars($resident['date_of_birth'] ?? ''); ?>"
                                        data-gender="<?php echo htmlspecialchars($resident['gender'] ?? ''); ?>"
                                        data-civil="<?php echo htmlspecialchars($resident['civil_status'] ?? ''); ?>"
                                        data-home="<?php echo htmlspecialchars($resident['home_number'] ?? ''); ?>"
                                        data-street="<?php echo htmlspecialchars($resident['street'] ?? ''); ?>"
                                        data-barangay="<?php echo htmlspecialchars($resident['barangay'] ?? ''); ?>"
                                        data-municipality="<?php echo htmlspecialchars($resident['municipality'] ?? ''); ?>"
                                        data-city="<?php echo htmlspecialchars($resident['city_province'] ?? ''); ?>"
                                        data-status="<?php echo htmlspecialchars($status); ?>"
                                        data-created="<?php echo htmlspecialchars($resident['created_at'] ?? ''); ?>"
                                        data-photo="<?php echo htmlspecialchars($resident['photo'] ?? ''); ?>"
                                        data-place="<?php echo htmlspecialchars($resident['place_of_birth'] ?? ''); ?>"
                                        data-religion="<?php echo htmlspecialchars($resident['religion'] ?? ''); ?>"
                                        data-nationality="<?php echo htmlspecialchars($resident['nationality'] ?? ''); ?>"
                                    >View</button>
                                    <button
                                        class="action-btn action-edit"
                                        data-id="<?php echo (int) $resident['id']; ?>"
                                        data-first="<?php echo htmlspecialchars($resident['first_name'] ?? ''); ?>"
                                        data-middle="<?php echo htmlspecialchars($resident['middle_name'] ?? ''); ?>"
                                        data-last="<?php echo htmlspecialchars($resident['last_name'] ?? ''); ?>"
                                        data-email="<?php echo htmlspecialchars($resident['email'] ?? ''); ?>"
                                        data-contact="<?php echo htmlspecialchars($resident['contact_number'] ?? ''); ?>"
                                        data-civil="<?php echo htmlspecialchars($resident['civil_status'] ?? ''); ?>"
                                        data-home="<?php echo htmlspecialchars($resident['home_number'] ?? ''); ?>"
                                        data-street="<?php echo htmlspecialchars($resident['street'] ?? ''); ?>"
                                        data-barangay="<?php echo htmlspecialchars($resident['barangay'] ?? ''); ?>"
                                        data-municipality="<?php echo htmlspecialchars($resident['municipality'] ?? ''); ?>"
                                        data-city="<?php echo htmlspecialchars($resident['city_province'] ?? ''); ?>"
                                        data-status="<?php echo htmlspecialchars($status); ?>"
                                    >Edit</button>
                                    <button
                                        class="action-btn action-delete"
                                        data-id="<?php echo (int) $resident['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($full_name); ?>"
                                    >Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">Previous</a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($status_filter); ?>">Next</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- View Modal -->
    <div class="dashboard-modal" id="viewModal">
        <div class="modal-card">
            <div class="modal-header">
                <div>
                    <p class="modal-subtitle">Resident Profile</p>
                    <h3 id="viewName">Resident</h3>
                </div>
                <button class="close-modal" data-close-modal="viewModal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="avatar-stack">
                    <div id="viewAvatar" class="avatar">RS</div>
                    <div>
                        <div class="badge warning" id="viewStatus">Pending Verification</div>
                        <div class="info-label" style="margin-top:6px;">Registered</div>
                        <div class="info-value" id="viewRegistered">N/A</div>
                    </div>
                </div>
                <div class="modal-grid">
                    <div class="info-tile">
                        <div class="info-label">Email</div>
                        <div class="info-value" id="viewEmail">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Contact</div>
                        <div class="info-value" id="viewContact">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Gender</div>
                        <div class="info-value" id="viewGender">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Date of Birth</div>
                        <div class="info-value" id="viewDob">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Civil Status</div>
                        <div class="info-value" id="viewCivil">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Place of Birth</div>
                        <div class="info-value" id="viewPlace">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Address</div>
                        <div class="info-value" id="viewAddress">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Nationality</div>
                        <div class="info-value" id="viewNationality">N/A</div>
                    </div>
                    <div class="info-tile">
                        <div class="info-label">Religion</div>
                        <div class="info-value" id="viewReligion">N/A</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Modal -->
    <div class="dashboard-modal" id="editModal">
        <div class="modal-card">
            <div class="modal-header">
                <div>
                    <p class="modal-subtitle">Edit Resident</p>
                    <h3 id="editName">Update details</h3>
                </div>
                <button class="close-modal" data-close-modal="editModal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editResidentForm" method="POST" action="admin_residents.php">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="resident_id" id="editResidentId">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="editEmail">Email</label>
                            <input type="email" id="editEmail" name="email" placeholder="Email" required>
                        </div>
                        <div class="form-group">
                            <label for="editContact">Contact Number</label>
                            <input type="text" id="editContact" name="contact_number" placeholder="Contact Number">
                        </div>
                        <div class="form-group">
                            <label for="editCivilStatus">Civil Status</label>
                            <input type="text" id="editCivilStatus" name="civil_status" placeholder="Civil Status">
                        </div>
                        <div class="form-group">
                            <label for="editHomeNumber">Home Number</label>
                            <input type="text" id="editHomeNumber" name="home_number" placeholder="Home Number">
                        </div>
                        <div class="form-group">
                            <label for="editStreet">Street</label>
                            <input type="text" id="editStreet" name="street" placeholder="Street">
                        </div>
                        <div class="form-group">
                            <label for="editBarangay">Barangay</label>
                            <input type="text" id="editBarangay" name="barangay" value="San Vicente II" readonly>
                        </div>
                        <div class="form-group">
                            <label for="editMunicipality">Municipality</label>
                            <input type="text" id="editMunicipality" name="municipality" placeholder="Municipality">
                        </div>
                        <div class="form-group">
                            <label for="editCityProvince">City / Province</label>
                            <input type="text" id="editCityProvince" name="city_province" placeholder="City / Province">
                        </div>
                        <?php if ($account_status_exists): ?>
                        <div class="form-group">
                            <label for="editStatus">Account Status</label>
                            <select id="editStatus" name="account_status">
                                <option value="Pending Verification">Pending Verification</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn-soft" data-close-modal="editModal">Cancel</button>
                        <button type="submit" class="btn-cta">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Modal -->
    <div class="dashboard-modal" id="deleteModal">
        <div class="modal-card compact">
            <div class="modal-header">
                <div>
                    <p class="modal-subtitle">Remove Resident</p>
                    <h3>Confirm Delete</h3>
                </div>
                <button class="close-modal" data-close-modal="deleteModal">&times;</button>
            </div>
            <div class="modal-body">
                <p style="font-size:14px; color:#1f2b20;">You are about to remove <strong id="deleteResidentName">this resident</strong>. This action will move the record to archive (if available).</p>
                <form id="deleteResidentForm" method="POST" action="admin_residents.php" style="margin-top:14px;">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="resident_id" id="deleteResidentId">
                    <div class="modal-footer">
                        <button type="button" class="btn-soft" data-close-modal="deleteModal">Cancel</button>
                        <button type="submit" class="btn-danger">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        (function() {
            const openModal = (id) => {
                const modal = document.getElementById(id);
                if (!modal) return;
                modal.classList.add('show');
                document.body.classList.add('modal-open');
            };
            const closeModal = (id) => {
                const modal = document.getElementById(id);
                if (!modal) return;
                modal.classList.remove('show');
                document.body.classList.remove('modal-open');
            };
            const formatDate = (value) => {
                if (!value) return 'N/A';
                const date = new Date(value);
                return isNaN(date.getTime())
                    ? value
                    : date.toLocaleDateString('en-US', { month: 'short', day: '2-digit', year: 'numeric' });
            };
            const statusBadge = (status) => {
                if (status === 'Active') return 'success';
                if (status === 'Inactive') return 'danger';
                return 'warning';
            };
            const FIXED_BARANGAY = 'San Vicente II';

            document.querySelectorAll('[data-close-modal]').forEach(btn => {
                btn.addEventListener('click', () => closeModal(btn.dataset.closeModal));
            });
            window.addEventListener('click', (e) => {
                if (e.target.classList && e.target.classList.contains('dashboard-modal')) {
                    closeModal(e.target.id);
                }
            });

            // View
            const viewMap = {
                name: document.getElementById('viewName'),
                email: document.getElementById('viewEmail'),
                contact: document.getElementById('viewContact'),
                gender: document.getElementById('viewGender'),
                dob: document.getElementById('viewDob'),
                civil: document.getElementById('viewCivil'),
                place: document.getElementById('viewPlace'),
                address: document.getElementById('viewAddress'),
                nationality: document.getElementById('viewNationality'),
                religion: document.getElementById('viewReligion'),
                status: document.getElementById('viewStatus'),
                registered: document.getElementById('viewRegistered'),
                avatar: document.getElementById('viewAvatar')
            };
            document.querySelectorAll('.action-view').forEach(btn => {
                btn.addEventListener('click', () => {
                    const fullName = [btn.dataset.first, btn.dataset.middle, btn.dataset.last, btn.dataset.suffix]
                        .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim() || 'Resident';
                    const initials = ((btn.dataset.first || 'R')[0] + (btn.dataset.last || '')) || 'R';
                    const photoPath = btn.dataset.photo ? '../' + btn.dataset.photo.replace(/^\//, '') : '';
                    if (viewMap.avatar) {
                        viewMap.avatar.innerHTML = photoPath
                            ? '<div class="avatar"><img src="' + photoPath + '" alt="' + fullName + '"></div>'
                            : '<div class="avatar">' + initials.substring(0, 2).toUpperCase() + '</div>';
                    }
                    viewMap.name.textContent = fullName;
                    viewMap.email.textContent = btn.dataset.email || 'N/A';
                    viewMap.contact.textContent = btn.dataset.contact || 'N/A';
                    viewMap.gender.textContent = btn.dataset.gender || 'N/A';
                    viewMap.dob.textContent = formatDate(btn.dataset.dob);
                    viewMap.civil.textContent = btn.dataset.civil || 'N/A';
                    viewMap.place.textContent = btn.dataset.place || 'N/A';
                    viewMap.nationality.textContent = btn.dataset.nationality || 'N/A';
                    viewMap.religion.textContent = btn.dataset.religion || 'N/A';
                    const addressParts = [btn.dataset.home, btn.dataset.street, btn.dataset.barangay, btn.dataset.municipality, btn.dataset.city]
                        .filter(Boolean).join(', ');
                    viewMap.address.textContent = addressParts || 'N/A';
                    const badgeType = statusBadge(btn.dataset.status);
                    viewMap.status.textContent = btn.dataset.status || 'Pending Verification';
                    viewMap.status.className = 'badge ' + badgeType;
                    viewMap.registered.textContent = formatDate(btn.dataset.created);
                    openModal('viewModal');
                });
            });

            // Edit
            const editForm = document.getElementById('editResidentForm');
            const editResidentId = document.getElementById('editResidentId');
            const editName = document.getElementById('editName');
            document.querySelectorAll('.action-edit').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (!editForm) return;
                    const fullName = [btn.dataset.first, btn.dataset.middle, btn.dataset.last]
                        .filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
                    if (editName) editName.textContent = fullName || 'Update details';
                    if (editResidentId) editResidentId.value = btn.dataset.id || '';
                    const map = {
                        editEmail: btn.dataset.email || '',
                        editContact: btn.dataset.contact || '',
                        editCivilStatus: btn.dataset.civil || '',
                        editHomeNumber: btn.dataset.home || '',
                        editStreet: btn.dataset.street || '',
                        editBarangay: FIXED_BARANGAY,
                        editMunicipality: btn.dataset.municipality || '',
                        editCityProvince: btn.dataset.city || ''
                    };
                    Object.keys(map).forEach(key => {
                        const field = document.getElementById(key);
                        if (field) field.value = map[key];
                    });
                    const statusField = document.getElementById('editStatus');
                    if (statusField) statusField.value = btn.dataset.status || 'Pending Verification';
                    openModal('editModal');
                });
            });

            // Delete
            const deleteName = document.getElementById('deleteResidentName');
            const deleteId = document.getElementById('deleteResidentId');
            document.querySelectorAll('.action-delete').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (deleteName) deleteName.textContent = btn.dataset.name || 'this resident';
                    if (deleteId) deleteId.value = btn.dataset.id || '';
                    openModal('deleteModal');
                });
            });
        })();
    </script>
</body>
</html>

