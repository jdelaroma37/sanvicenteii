<?php
// admin/admin_requests.php
session_start();
require '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

// Get admin info
$admin_id = $_SESSION['user_id'];
$page = $_GET['page'] ?? 'monitoring';

// Redirect to specific request pages
if ($page === 'monitoring') {
    header('Location: admin_monitoring_request.php');
    exit;
} elseif ($page === 'issuance') {
    header('Location: admin_issuance_details.php');
    exit;
} elseif ($page === 'walkin') {
    header('Location: admin_walkin_request.php');
    exit;
}

header('Location: admin_monitoring_request.php');
exit;
?>

