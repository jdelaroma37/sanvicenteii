<?php
// admin/admin_announcement_management.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar - IMPORTANT: Set before including sidebar component
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

$announcements_file = __DIR__ . '/../data/announcements/announcement.json';

// Load announcements
$announcements = [];
if (file_exists($announcements_file)) {
    $announcements = json_decode(file_get_contents($announcements_file), true) ?? [];
}
if (!is_array($announcements)) {
    $announcements = [];
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'edit') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $type = trim($_POST['type'] ?? 'General');
        $category = trim($_POST['category'] ?? 'General Announcement');
        $date = trim($_POST['date'] ?? date('F d, Y'));
        $date_value = trim($_POST['date_value'] ?? date('Y-m-d'));
        
        if (!$title || !$description) {
            $_SESSION['error'] = 'Title and description are required.';
            header('Location: admin_announcement_management.php');
            exit;
        }
        
        // Handle image upload
        $image_path = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = __DIR__ . '/../uploads/announcements/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (in_array($file_ext, $allowed_ext)) {
                $new_filename = 'announcement_' . time() . '_' . uniqid() . '.' . $file_ext;
                $upload_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $image_path = 'uploads/announcements/' . $new_filename;
                }
            }
        }
        
        if ($action === 'create') {
            $new_announcement = [
                'id' => uniqid('ann_'),
                'title' => $title,
                'description' => $description,
                'type' => $type,
                'category' => $category,
                'date' => $date,
                'date_value' => $date_value,
                'image' => $image_path,
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $admin_id
            ];
            $announcements[] = $new_announcement;
            $success = 'Announcement created successfully!';
        } else {
            // Edit existing
            $id = $_POST['id'] ?? '';
            $found = false;
            foreach ($announcements as &$ann) {
                if (isset($ann['id']) && $ann['id'] === $id) {
                    $ann['title'] = $title;
                    $ann['description'] = $description;
                    $ann['type'] = $type;
                    $ann['category'] = $category;
                    $ann['date'] = $date;
                    $ann['date_value'] = $date_value;
                    if ($image_path) {
                        // Delete old image if exists
                        if (!empty($ann['image']) && file_exists(__DIR__ . '/../' . $ann['image'])) {
                            unlink(__DIR__ . '/../' . $ann['image']);
                        }
                        $ann['image'] = $image_path;
                    }
                    $ann['updated_at'] = date('Y-m-d H:i:s');
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $success = 'Announcement updated successfully!';
            } else {
                $_SESSION['error'] = 'Announcement not found.';
                header('Location: admin_announcement_management.php');
                exit;
            }
        }
        
        // Save to file
        file_put_contents($announcements_file, json_encode($announcements, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        // Redirect to prevent form resubmission
        $_SESSION['success'] = $success;
        header('Location: admin_announcement_management.php');
        exit;
    } elseif ($action === 'delete') {
        // Check permission - only super admin can delete
        requirePermission('delete');
        
        $id = $_POST['id'] ?? '';
        $found = false;
        foreach ($announcements as $key => $ann) {
            if (isset($ann['id']) && $ann['id'] === $id) {
                // Delete image if exists
                if (!empty($ann['image']) && file_exists(__DIR__ . '/../' . $ann['image'])) {
                    unlink(__DIR__ . '/../' . $ann['image']);
                }
                unset($announcements[$key]);
                $announcements = array_values($announcements); // Re-index array
                $found = true;
                break;
            }
        }
        if ($found) {
            file_put_contents($announcements_file, json_encode($announcements, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['success'] = 'Announcement deleted successfully!';
        } else {
            $_SESSION['error'] = 'Announcement not found.';
        }
        // Redirect to prevent form resubmission
        header('Location: admin_announcement_management.php');
        exit;
    }
}

// Sort announcements by date value (newest first, then by created_at)
usort($announcements, function($a, $b) {
    $dateA = $a['date_value'] ?? $a['created_at'] ?? '';
    $dateB = $b['date_value'] ?? $b['created_at'] ?? '';
    if ($dateA && $dateB) {
        return strcmp($dateB, $dateA);
    }
    return strcmp($b['created_at'] ?? '', $a['created_at'] ?? '');
});

// Get announcement types
$types = ['General', 'Event', 'News', 'Important', 'Update'];

// Get announcement categories
$categories = [
    'General Announcement',
    'Upcoming Announcement',
    'Projects',
    'Events',
    'News',
    'Important Notice',
    'Community Update'
];

// Group announcements by category
$grouped_announcements = [];
foreach ($announcements as $ann) {
    $cat = $ann['category'] ?? 'General Announcement';
    if (!isset($grouped_announcements[$cat])) {
        $grouped_announcements[$cat] = [];
    }
    $grouped_announcements[$cat][] = $ann;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcement Management - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            min-height: 100vh;
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .page-actions .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .btn-primary {
            padding: 12px 24px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Announcements Table */
        .announcements-table-container {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow-x: auto;
            overflow-y: auto;
            max-height: calc(100vh - 300px);
            margin-bottom: 30px;
        }
        .announcements-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            min-width: 1000px;
        }
        .announcements-table th:nth-child(1),
        .announcements-table td:nth-child(1) {
            width: 10%;
            min-width: 80px;
        }
        .announcements-table th:nth-child(2),
        .announcements-table td:nth-child(2) {
            width: 20%;
            min-width: 150px;
        }
        .announcements-table th:nth-child(3),
        .announcements-table td:nth-child(3) {
            width: 30%;
            min-width: 200px;
        }
        .announcements-table th:nth-child(4),
        .announcements-table td:nth-child(4) {
            width: 15%;
            min-width: 150px;
            max-width: 200px;
        }
        .announcements-table th:nth-child(5),
        .announcements-table td:nth-child(5) {
            width: 25%;
            min-width: 280px;
            max-width: none;
        }
        .announcements-table thead {
            background: #2c3e2d;
            position: sticky;
            top: 0;
            z-index: 10;
        }
        .announcements-table th {
            padding: 16px;
            text-align: left;
            color: white;
            font-weight: 700;
            font-size: 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
            vertical-align: middle;
            background: #2c3e2d;
        }
        .announcements-table th:not(:first-child)::before {
            content: '';
            position: absolute;
            left: 0;
            top: 20%;
            bottom: 20%;
            width: 1px;
            background: rgba(212, 175, 55, 0.6);
        }
        .announcements-table th:nth-child(4),
        .announcements-table th:nth-child(5) {
            text-align: left;
            vertical-align: middle;
        }
        .announcements-table td {
            padding: 16px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            font-size: 16px;
            font-weight: 500;
            color: #6b7280;
            vertical-align: middle;
            overflow: hidden;
            word-wrap: break-word;
            position: relative;
            background: white;
        }
        .announcements-table td:nth-child(4),
        .announcements-table td:nth-child(5) {
            vertical-align: middle !important;
            text-align: left;
            padding: 16px !important;
        }
        .announcements-table th:nth-child(4),
        .announcements-table th:nth-child(5) {
            padding: 16px !important;
            vertical-align: middle !important;
        }
        .announcements-table tbody tr:hover td {
            background: rgba(135, 169, 107, 0.05);
        }
        .announcements-table tbody tr:last-child td {
            border-bottom: none;
        }
        .announcement-type-badge {
            display: inline-block;
            padding: 4px 12px;
            background: #2c3e2d;
            color: white;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .announcement-title-cell {
            font-weight: 700;
            color: #2c3e2d;
        }
        .announcement-description-cell {
            color: #4b5563;
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        .announcement-date-cell {
            color: #6b7280;
            font-weight: 500;
            vertical-align: middle !important;
            padding: 16px !important;
            white-space: nowrap;
        }
        .announcement-date-cell svg {
            display: inline-block;
            vertical-align: middle;
            margin-right: 6px;
        }
        .announcement-actions-cell {
            vertical-align: middle !important;
            padding: 16px !important;
            white-space: nowrap !important;
            min-width: 280px !important;
            width: auto;
        }
        .announcement-actions-cell .btn-edit,
        .announcement-actions-cell .btn-delete {
            display: inline-flex !important;
            vertical-align: middle;
            margin-right: 10px;
            visibility: visible !important;
            opacity: 1 !important;
            flex-shrink: 0;
        }
        .announcement-actions-cell .btn-edit:last-child,
        .announcement-actions-cell .btn-delete:last-child {
            margin-right: 0;
        }
        .announcement-date-cell + .announcement-actions-cell {
            border-left: 2px solid transparent;
        }
        .btn-edit, .btn-delete {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            white-space: nowrap;
        }
        .btn-edit {
            background: #d4af37;
            color: white;
        }
        .btn-edit:hover {
            background: #e6c55a;
        }
        .btn-delete {
            background: #c33 !important;
            color: white !important;
            display: inline-flex !important;
            visibility: visible !important;
            opacity: 1 !important;
        }
        .btn-delete:hover {
            background: #a22 !important;
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        /* Delete Modal - centered like other pages */
        #deleteModal {
            display: none;
            align-items: center;
            justify-content: center;
        }
        #deleteModal[style*="display: block"] {
            display: flex !important;
        }
        /* Override modal header styling for delete modal - match other delete modals exactly */
        #deleteModal .modal-header {
            border-bottom: none !important;
            padding-bottom: 0 !important;
            margin-bottom: 20px !important;
        }
        #deleteModal .modal-header h2 {
            font-size: 24px !important;
            color: #1E4D2B !important;
            font-weight: bold !important;
            padding-bottom: 0 !important;
            position: relative !important;
            letter-spacing: normal !important;
        }
        #deleteModal .modal-header h2::after {
            display: none !important;
        }
        .modal-content {
            background: white;
            border-radius: 12px;
            padding: 35px;
            width: 100%;
            max-width: 750px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            border-left: 4px solid #d4af37;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }
        .modal-header h2 {
            font-size: 26px;
            color: #2c3e2d;
            font-weight: 800;
            position: relative;
            padding-bottom: 10px;
            letter-spacing: -0.3px;
        }
        .modal-header h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, #d4af37 0%, #e6c55a 100%);
            border-radius: 2px;
        }
        .close-modal {
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            transition: color 0.3s;
            padding: 4px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .close-modal svg {
            width: 24px;
            height: 24px;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 600;
            font-size: 14px;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }
        .form-group input[type="file"] {
            padding: 8px;
        }
        .image-preview {
            margin-top: 10px;
            max-width: 100%;
            border-radius: 8px;
            max-height: 200px;
            object-fit: cover;
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 10px;
            margin-top: 20px;
        }
        .modal-footer form {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 10px;
            margin: 0;
        }
        .modal-footer button {
            margin: 0;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        .modal-footer .btn-delete {
            background: #dc2626;
            color: white;
            border: none;
        }
        .modal-footer .btn-delete:hover {
            background: #b91c1c;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(220, 38, 38, 0.3);
        }
        .modal-footer .btn-cancel {
            background: #6b7280;
            color: white;
            border: none;
        }
        .modal-footer .btn-cancel:hover {
            background: #4b5563;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(107, 114, 128, 0.3);
        }
        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: #d0d0d0;
        }
        .btn-submit {
            flex: 1;
            padding: 12px;
            background: linear-gradient(135deg, #1a5f3f 0%, #2d7a52 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(26, 95, 63, 0.3);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }
        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
            color: #6b7280;
        }
        .empty-state h3 {
            font-size: 20px;
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 10px;
        }
        .empty-state p {
            font-size: 14px;
            color: #6b7280;
            font-weight: 500;
        }
        .category-section {
            margin-bottom: 40px;
        }
        .category-header {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
            padding-bottom: 10px;
            border-bottom: 2px solid rgba(212, 175, 55, 0.3);
        }
        .category-count {
            font-size: 14px;
            color: #6b7280;
            font-weight: 500;
            background: rgba(212, 175, 55, 0.1);
            padding: 4px 12px;
            border-radius: 12px;
        }
        /* Responsive */
        @media (max-width: 1024px) {
            .announcements-table-container {
                overflow-x: auto;
            }
            .announcements-table {
                min-width: 800px;
            }
        }
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <?php 
    // Ensure admin_role is set before including sidebar
    if (!isset($admin_role)) {
        $admin_id = $_SESSION['user_id'] ?? 0;
        if (isset($_SESSION['admin_role'])) {
            $admin_role = $_SESSION['admin_role'];
        } elseif (isset($pdo) && $admin_id) {
            try {
                $stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
                $stmt->execute([$admin_id]);
                $admin = $stmt->fetch(PDO::FETCH_ASSOC);
                $admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
                $_SESSION['admin_role'] = $admin_role;
            } catch (Exception $e) {
                $admin_role = 'regular_admin';
            }
        } else {
            $admin_role = 'regular_admin';
        }
    }
    include 'admin_dashboard_sidebar.php'; 
    ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                    <polyline points="22,6 12,13 2,6"></polyline>
                </svg>
            </span>
            Announcement Management
        </h1>

        <div class="page-actions">
            <a href="admin_programs_events.php" class="btn btn-primary">Programs and Services</a>
            <a href="admin_event_calendar.php" class="btn btn-primary">Event Calendar</a>
            <a href="admin_progress_projects.php" class="btn btn-primary">Progress and Projects</a>
        </div>

        <div style="display: flex; justify-content: flex-end; margin-bottom: 30px;">
            <button class="btn-primary" onclick="openCreateModal()">Create Announcement</button>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="row-container">
            <?php if (empty($announcements)): ?>
                <div class="empty-state">
                    <div class="empty-state-icon">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M12 4v6m0 4v6m8-8H4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                            <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.5"/>
                        </svg>
                    </div>
                    <h3>No Announcements Yet</h3>
                    <p>Create your first announcement to keep residents informed.</p>
                </div>
            <?php else: ?>
                <?php foreach ($grouped_announcements as $category => $cat_announcements): ?>
                <div class="category-section">
                    <h2 class="category-header">
                        <?php echo htmlspecialchars($category); ?> 
                        <span class="category-count"><?php echo count($cat_announcements); ?></span>
                    </h2>
                    <div class="announcements-table-container">
                        <table class="announcements-table">
                            <colgroup>
                                <col style="width: 10%;">
                                <col style="width: 20%;">
                                <col style="width: 30%;">
                                <col style="width: 15%;">
                                <col style="width: 25%;">
                            </colgroup>
                            <thead>
                                <tr>
                                    <th>Type</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cat_announcements as $ann): ?>
                                <tr>
                                    <td>
                                        <span class="announcement-type-badge"><?php echo htmlspecialchars($ann['type'] ?? 'General'); ?></span>
                                    </td>
                                    <td class="announcement-title-cell"><?php echo htmlspecialchars($ann['title']); ?></td>
                                    <td class="announcement-description-cell"><?php echo htmlspecialchars($ann['description']); ?></td>
                                    <td class="announcement-date-cell">
                                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                            <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                        </svg>
                                        <?php echo htmlspecialchars($ann['date'] ?? 'N/A'); ?>
                                    </td>
                                    <td class="announcement-actions-cell">
                                        <button class="btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($ann)); ?>)">
                                            <svg width="12" height="12" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M4 10l4-4 4 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                            </svg>
                                            Edit
                                        </button>
                                        <button class="btn-delete" onclick="deleteAnnouncement('<?php echo htmlspecialchars($ann['id']); ?>', '<?php echo htmlspecialchars(addslashes($ann['title'])); ?>')">
                                            <svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                            </svg>
                                            Delete
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
    </div>

    <!-- Create/Edit Modal -->
    <div id="announcementModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Create Announcement</h2>
                <button class="close-modal" onclick="closeModal()">
                    <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
            <form id="announcementForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="announcementId">
                
                <div class="form-group">
                    <label for="title">Title *</label>
                    <input type="text" id="title" name="title" required>
                </div>

                <div class="form-group">
                    <label for="category">Category *</label>
                    <select id="category" name="category" required>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="type">Type</label>
                    <select id="type" name="type">
                        <?php foreach ($types as $type): ?>
                            <option value="<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($type); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="description">Description *</label>
                    <textarea id="description" name="description" required></textarea>
                </div>

                <div class="form-group">
                    <label for="date_value">Date *</label>
                    <input type="date" id="date_value" name="date_value" value="<?php echo date('Y-m-d'); ?>" required onchange="updateDateDisplay(this.value)">
                    <input type="hidden" id="date" name="date" value="<?php echo date('F d, Y'); ?>">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">You can set a future date for upcoming announcements</small>
                </div>

                <div class="form-group">
                    <label for="image">Image (Optional)</label>
                    <input type="file" id="image" name="image" accept="image/*" onchange="previewImage(this)">
                    <img id="imagePreview" class="image-preview" style="display: none;">
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Form -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="deleteId">
    </form>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content" style="max-width: 500px; border-left: none; padding: 30px; margin: auto;">
            <div class="modal-header">
                <h2>Delete Announcement</h2>
                <button class="close-modal" onclick="closeDeleteModal()" style="font-size: 28px; font-weight: bold; color: #999; cursor: pointer; border: none; background: none;">
                    &times;
                </button>
            </div>
            <div class="modal-body" style="margin-bottom: 20px;">
                <p style="color: #D9534F; font-weight: 600; font-size: 16px;">
                    Are you sure you want to permanently remove this announcement?
                </p>
                <p style="margin-top: 10px; color: #666;">
                    Announcement: <strong id="deleteAnnouncementName"></strong>
                </p>
                <p style="margin-top: 10px; color: #999; font-size: 12px;">
                    This action will soft delete the announcement. The data will be marked as deleted but can be restored if needed.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn-cancel" onclick="closeDeleteModal()">Cancel</button>
                <button type="button" class="btn-delete" onclick="confirmDelete()">Yes, Delete</button>
            </div>
        </div>
    </div>

    <script>
        function formatDate(dateString) {
            const date = new Date(dateString);
            const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            return months[date.getMonth()] + ' ' + date.getDate() + ', ' + date.getFullYear();
        }

        function updateDateDisplay(dateValue) {
            if (dateValue) {
                document.getElementById('date').value = formatDate(dateValue);
            }
        }

        function openCreateModal() {
            document.getElementById('modalTitle').textContent = 'Create Announcement';
            document.getElementById('formAction').value = 'create';
            document.getElementById('announcementForm').reset();
            document.getElementById('announcementId').value = '';
            document.getElementById('date_value').value = '<?php echo date('Y-m-d'); ?>';
            document.getElementById('date').value = '<?php echo date('F d, Y'); ?>';
            document.getElementById('imagePreview').style.display = 'none';
            document.getElementById('announcementModal').classList.add('show');
        }

        function openEditModal(announcement) {
            document.getElementById('modalTitle').textContent = 'Edit Announcement';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('announcementId').value = announcement.id;
            document.getElementById('title').value = announcement.title || '';
            document.getElementById('category').value = announcement.category || 'General Announcement';
            document.getElementById('type').value = announcement.type || 'General';
            document.getElementById('description').value = announcement.description || '';
            
            // Handle date
            if (announcement.date_value) {
                document.getElementById('date_value').value = announcement.date_value;
                document.getElementById('date').value = announcement.date || formatDate(announcement.date_value);
            } else if (announcement.date) {
                // Try to parse the date string
                const dateStr = announcement.date;
                document.getElementById('date').value = dateStr;
                // Try to convert to date input format
                try {
                    const dateObj = new Date(dateStr);
                    if (!isNaN(dateObj.getTime())) {
                        document.getElementById('date_value').value = dateObj.toISOString().split('T')[0];
                    } else {
                        document.getElementById('date_value').value = '<?php echo date('Y-m-d'); ?>';
                    }
                } catch(e) {
                    document.getElementById('date_value').value = '<?php echo date('Y-m-d'); ?>';
                }
            } else {
                document.getElementById('date_value').value = '<?php echo date('Y-m-d'); ?>';
                document.getElementById('date').value = '<?php echo date('F d, Y'); ?>';
            }
            
            if (announcement.image) {
                document.getElementById('imagePreview').src = '../' + announcement.image;
                document.getElementById('imagePreview').style.display = 'block';
            } else {
                document.getElementById('imagePreview').style.display = 'none';
            }
            
            document.getElementById('announcementModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('announcementModal').classList.remove('show');
        }

        function previewImage(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                    document.getElementById('imagePreview').style.display = 'block';
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        function deleteAnnouncement(id, title) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteAnnouncementName').textContent = title;
            const modal = document.getElementById('deleteModal');
            modal.style.display = 'flex';
            modal.style.alignItems = 'center';
            modal.style.justifyContent = 'center';
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').style.display = 'none';
        }

        function confirmDelete() {
            document.getElementById('deleteForm').submit();
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('announcementModal');
            if (event.target === modal) {
                closeModal();
            }
            const deleteModal = document.getElementById('deleteModal');
            if (event.target === deleteModal) {
                closeDeleteModal();
            }
        }

        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });
    </script>
</body>
</html>

