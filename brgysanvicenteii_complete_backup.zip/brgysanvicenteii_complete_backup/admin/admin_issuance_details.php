<?php
// admin/admin_issuance_details.php
session_start();
require '../config.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT role FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = isset($admin['role']) ? $admin['role'] : 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Load all requests
$requests_dir = __DIR__ . '/../data/requests';
$all_requests = [];
if (is_dir($requests_dir)) {
    $files = glob("$requests_dir/*.json");
    foreach ($files as $file) {
        $filename = basename($file);
        // Skip main requests.json
        if ($filename === 'requests.json') {
            continue;
        }
        
        $content = json_decode(file_get_contents($file), true);
        if ($content) {
            // Handle user summary files (array of requests)
            if (preg_match('/^\d+_requests\.json$/', $filename) && is_array($content)) {
                foreach ($content as $req) {
                    if (is_array($req) && !empty($req['id'])) {
                        $all_requests[] = $req;
                    }
                }
            } 
            // Handle individual request files
            else if (is_array($content)) {
                // Ensure request has an ID, use filename if not
                if (empty($content['id'])) {
                    // Extract ID from filename (e.g., req_xxx.json -> req_xxx)
                    $content['id'] = str_replace('.json', '', $filename);
                }
                // Only add if it has a valid ID
                if (!empty($content['id'])) {
                    $all_requests[] = $content;
                }
            }
        }
    }
}

// Filter for ONLY "Done" requests - this is the issuance details page
$done_requests = array_filter($all_requests, function($req) {
    $status = strtolower(trim($req['status'] ?? ''));
    return $status === 'done';
});

// Sort by completion date (newest first), fallback to date requested
usort($done_requests, function($a, $b) {
    $dateA = $a['doneAt'] ?? $a['dateRequested'] ?? '';
    $dateB = $b['doneAt'] ?? $b['dateRequested'] ?? '';
    return strcmp($dateB, $dateA);
});

// No need to fetch admin/resident names - simplified version
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issuance Details - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
            position: relative;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a i {
            margin-right: 12px;
            width: 24px;
            font-size: 20px;
            text-align: center;
            display: inline-block;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        /* Submenu */
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-secondary,
        .page-actions .btn-secondary {
            background: #4b5563 !important;
            color: white !important;
        }
        .btn-secondary:hover,
        .page-actions .btn-secondary:hover {
            background: #374151 !important;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(75, 85, 99, 0.3);
        }
        .btn-primary {
            background: #2c3e2d;
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .row-container > .section-title:first-child {
            margin-top: 0;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Search and Filter */
        .search-filter-bar {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
            transition: all 0.2s ease;
        }
        .search-filter-bar:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .search-box {
            flex: 1;
            min-width: 250px;
            position: relative;
        }
        .search-box input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.8);
            color: #2c3e2d;
            transition: all 0.3s;
        }
        .search-box input:focus {
            outline: none;
            border-color: #87A96B;
            background: white;
            box-shadow: 0 0 0 3px rgba(135, 169, 107, 0.1);
        }
        .search-box input::placeholder {
            color: #6b7280;
            font-weight: 500;
        }
        .search-box::before {
            content: '';
        }
        .search-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            pointer-events: none;
            width: 18px;
            height: 18px;
            color: #6b7280;
        }
        .filter-select {
            padding: 12px 15px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 500;
            background: rgba(255, 255, 255, 0.8);
            color: #2c3e2d;
            cursor: pointer;
            transition: all 0.3s;
            min-width: 180px;
        }
        .filter-select:focus {
            outline: none;
            border-color: #87A96B;
            background: white;
            box-shadow: 0 0 0 3px rgba(135, 169, 107, 0.1);
        }
        .stats-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            padding: 30px;
            margin-bottom: 20px;
            text-align: center;
            transition: all 0.2s ease;
        }
        .stats-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .stats-card h3 {
            font-size: 18px;
            font-weight: 600;
            color: #6b7280;
            margin-bottom: 12px;
        }
        .stats-card .stat-value {
            font-size: 42px;
            font-weight: 800;
            color: #000000;
            letter-spacing: -0.5px;
        }
        /* Table */
        .content-card {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border: 1px solid #e5e7eb;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            margin-bottom: 20px;
            transition: all 0.2s ease;
        }
        .content-card:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .table-container {
            overflow-x: auto;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th {
            background: #2c3e2d;
            padding: 16px;
            text-align: left;
            font-weight: 700;
            color: white;
            font-size: 16px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            position: relative;
        }
        table th:not(:first-child)::before {
            content: '';
            position: absolute;
            left: 0;
            top: 20%;
            bottom: 20%;
            width: 1px;
            background: rgba(212, 175, 55, 0.6);
        }
        table td {
            padding: 16px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
            font-size: 16px;
            font-weight: 500;
            color: #6b7280;
            background: white;
        }
        table tr:hover td {
            background: rgba(135, 169, 107, 0.05);
        }
        .view-pdf-link {
            color: #2c3e2d;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        .view-pdf-link:hover {
            color: #87A96B;
            text-decoration: underline;
        }
        .btn-view {
            padding: 8px 16px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-view:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .status-badge {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
        }
        .status-badge.done {
            background: rgba(135, 169, 107, 0.2);
            color: #2c3e2d;
            border: 1px solid rgba(135, 169, 107, 0.3);
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .modal-content {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 35px;
            max-width: 700px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .modal-header h2 {
            font-size: 26px;
            color: #2c3e2d;
            font-weight: 800;
            letter-spacing: -0.3px;
            margin: 0;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 32px;
            color: #999;
            cursor: pointer;
            padding: 0;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: all 0.3s;
        }
        .close-modal:hover {
            background: #f0f0f0;
            color: #c33;
        }
        .modal-body {
            color: #2c3e2d;
        }
        .detail-group {
            margin-bottom: 20px;
        }
        .detail-group label {
            font-weight: 700;
            color: #2c3e2d;
            display: block;
            margin-bottom: 8px;
            font-size: 16px;
        }
        .detail-group p {
            margin: 0;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            color: #6b7280;
            font-size: 16px;
            font-weight: 500;
            border: 1px solid rgba(0, 0, 0, 0.1);
        }
        .detail-group .value {
            color: #6b7280;
            font-weight: 500;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .table-container {
                overflow-x: scroll;
            }
            .modal-content {
                width: 95%;
                padding: 20px;
            }
            .search-filter-bar {
                flex-direction: column;
            }
            .search-box {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                    <polyline points="14 2 14 8 20 8"></polyline>
                    <line x1="16" y1="13" x2="8" y2="13"></line>
                    <line x1="16" y1="17" x2="8" y2="17"></line>
                    <polyline points="10 9 9 9 8 9"></polyline>
                </svg>
            </span>
            Issuance Details
        </h1>

        <div class="page-actions">
            <a href="admin_monitoring_request.php" class="btn btn-secondary">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10 3L5 8l5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                Back to Monitoring Request
            </a>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="row-container">
            <!-- Statistics -->
            <div class="stats-card">
            <h3>Total Completed Documents</h3>
            <div class="stat-value"><?php echo count($done_requests); ?></div>
        </div>

        <!-- Search and Filter -->
        <div class="search-filter-bar">
            <div class="search-box">
                <svg class="search-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M10.5 3.75a6.75 6.75 0 100 13.5 6.75 6.75 0 000-13.5zM2.25 10.5a8.25 8.25 0 1114.59 5.28l4.69 4.69a.75.75 0 11-1.06 1.06l-4.69-4.69A8.25 8.25 0 012.25 10.5z" fill="currentColor"/>
                </svg>
                <input type="text" id="searchInput" placeholder="Search by name, document type, or date..." onkeyup="filterTable()">
            </div>
            <select class="filter-select" id="documentFilter" onchange="filterTable()">
                <option value="">All Document Types</option>
                <?php
                $doc_types = array_unique(array_column($done_requests, 'documentType'));
                sort($doc_types);
                foreach ($doc_types as $doc_type):
                ?>
                    <option value="<?php echo htmlspecialchars($doc_type); ?>"><?php echo htmlspecialchars($doc_type); ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Issuance Details Table -->
        <div class="content-card">
            <div class="table-container">
                <table id="issuanceTable">
                    <thead>
                        <tr>
                            <th>Full Name</th>
                            <th>Document Type</th>
                            <th>Date Requested</th>
                            <th>Date Completed</th>
                            <th>PDF Document</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($done_requests)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center; color: #6b7280; font-weight: 500; font-size: 16px; padding: 40px;">No completed documents found</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($done_requests as $request): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($request['fullname'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($request['documentType'] ?? 'N/A'); ?></td>
                                    <td><?php echo htmlspecialchars($request['dateRequested'] ?? '—'); ?></td>
                                    <td>
                                        <?php 
                                        if (!empty($request['doneAt'])) {
                                            // Format the date nicely
                                            $done_date = $request['doneAt'];
                                            if (preg_match('/^\d{4}-\d{2}-\d{2}/', $done_date)) {
                                                $dt = new DateTime($done_date);
                                                echo $dt->format('F d, Y h:i A');
                                            } else {
                                                echo htmlspecialchars($done_date);
                                            }
                                        } else {
                                            echo '—';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php 
                                        $has_pdf = !empty($request['pdf_name']) && file_exists(__DIR__ . '/../data/generated_pdfs/' . $request['pdf_name']);
                                        if ($has_pdf): ?>
                                            <a href="../data/generated_pdfs/<?php echo htmlspecialchars($request['pdf_name']); ?>" target="_blank" class="view-pdf-link">View PDF</a>
                                        <?php else: ?>
                                            <span style="color: #6b7280; font-weight: 500;">No PDF</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button class="btn-view" onclick="viewRequest('<?php echo htmlspecialchars($request['id'] ?? ''); ?>')">View Details</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        </div>

    <!-- View Request Modal -->
    <div id="viewRequestModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Issuance Details</h2>
                <button class="close-modal" onclick="closeModal()">&times;</button>
            </div>
            <div class="modal-body" id="requestModalBody">
                <!-- Request details will be loaded here -->
            </div>
        </div>
    </div>

    <script>
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });

        function filterTable() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const documentFilter = document.getElementById('documentFilter').value.toLowerCase();
            const table = document.getElementById('issuanceTable');
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const cells = row.getElementsByTagName('td');
                
                if (cells.length === 0) continue; // Skip empty rows
                
                const name = cells[0].textContent.toLowerCase();
                const docType = cells[1].textContent.toLowerCase();
                const dateRequested = cells[2].textContent.toLowerCase();
                const dateCompleted = cells[3].textContent.toLowerCase();
                
                const matchesSearch = searchInput === '' || 
                    name.includes(searchInput) || 
                    docType.includes(searchInput) || 
                    dateRequested.includes(searchInput) ||
                    dateCompleted.includes(searchInput);
                
                const matchesFilter = documentFilter === '' || docType.includes(documentFilter);
                
                if (matchesSearch && matchesFilter) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }

        async function viewRequest(requestId) {
            try {
                // Find the request from the loaded data
                const requests = <?php echo json_encode($done_requests); ?>;
                const request = requests.find(r => r.id === requestId);
                
                if (!request) {
                    alert('Request not found.');
                    return;
                }

                // Build the modal content
                const od = request.otherDetails || {};
                const fields = {
                    age: 'Age',
                    gender: 'Gender',
                    dob: 'Date of Birth',
                    civil_status: 'Civil Status',
                    address: 'Address',
                    purpose: 'Purpose',
                    contactNum: 'Contact Number',
                    nameBusiness: 'Name of Business',
                    businessType: 'Type/Nature of Business',
                    businessAddress: 'Business Address',
                    dateEstablished: 'Date Established',
                    propertyType: 'Type of Property',
                    description: 'Description / Details',
                    category: 'Category',
                    resName: 'Respondent Name',
                    resAddress: 'Respondent Address',
                    dtIncident: 'Date & Time of Incident',
                    placeIncident: 'Place of Incident'
                };

                // Format completion date
                let doneAtFormatted = '—';
                if (request.doneAt) {
                    if (request.doneAt.match(/^\d{4}-\d{2}-\d{2}/)) {
                        const dt = new Date(request.doneAt);
                        doneAtFormatted = dt.toLocaleString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                        });
                    } else {
                        doneAtFormatted = request.doneAt;
                    }
                }

                let html = `
                    <div class="detail-group">
                        <label>Full Name</label>
                        <p>${request.fullname || 'N/A'}</p>
                    </div>
                    <div class="detail-group">
                        <label>Document Type</label>
                        <p>${request.documentType || 'N/A'}</p>
                    </div>
                    <div class="detail-group">
                        <label>Date Requested</label>
                        <p>${request.dateRequested || 'N/A'}</p>
                    </div>
                    <div class="detail-group">
                        <label>Date Completed</label>
                        <p>${doneAtFormatted}</p>
                    </div>
                    <div class="detail-group">
                        <label>Status</label>
                        <p><span class="status-badge done">${request.status || 'Done'}</span></p>
                    </div>
                `;

                if (request.pdf_name) {
                    html += `
                        <div class="detail-group">
                            <label>Generated PDF</label>
                            <p><a href="../data/generated_pdfs/${request.pdf_name}" target="_blank" class="view-pdf-link">View PDF</a></p>
                        </div>
                    `;
                }

                // Add other details
                let hasDetails = false;
                let detailsHtml = '<div class="detail-group"><label style="margin-top: 20px; margin-bottom: 10px; font-size: 18px; font-weight: 700; color: #2c3e2d;">Additional Information</label>';
                
                for (const key in fields) {
                    if (od[key]) {
                        detailsHtml += `
                            <div style="margin-bottom: 12px;">
                                <label style="font-size: 16px; font-weight: 700; color: #2c3e2d;">${fields[key]}:</label>
                                <p style="color: #6b7280; font-weight: 500;">${od[key]}</p>
                            </div>
                        `;
                        hasDetails = true;
                    }
                }
                
                if (!hasDetails) {
                    detailsHtml += '<p style="color: #6b7280; font-weight: 500;">No additional details provided.</p>';
                }
                detailsHtml += '</div>';

                html += detailsHtml;

                document.getElementById('requestModalBody').innerHTML = html;
                document.getElementById('viewRequestModal').classList.add('show');
            } catch (error) {
                console.error('Error loading request details:', error);
                alert('Could not load request details.');
            }
        }

        function closeModal() {
            document.getElementById('viewRequestModal').classList.remove('show');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('viewRequestModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>

