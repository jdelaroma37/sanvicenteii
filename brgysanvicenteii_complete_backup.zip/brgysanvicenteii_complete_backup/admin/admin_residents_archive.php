<?php
// admin/admin_residents_archive.php
session_start();
require '../config.php';
require 'role_helper.php';
require_once __DIR__ . '/../lang/language_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

// Check if columns exist
$columns_check = $pdo->query("SHOW COLUMNS FROM residents LIKE 'deleted_at'")->fetch();
$deleted_at_exists = !empty($columns_check);

// Get search and filter parameters
$search = $_GET['search'] ?? '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$per_page = 20;
$offset = ($page - 1) * $per_page;

// Build query for archived/deleted residents only
$where_conditions = [];
$params = [];

if ($deleted_at_exists) {
    $where_conditions[] = "COALESCE(deleted_at, '') != ''";
} else {
    // If deleted_at column doesn't exist, show empty archive
    $where_conditions[] = "1 = 0"; // Always false
}

if (!empty($search)) {
    $where_conditions[] = "(first_name LIKE ? OR middle_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR contact_number LIKE ?)";
    $search_param = "%{$search}%";
    $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param, $search_param]);
}

$where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get total count
$count_query = "SELECT COUNT(*) as total FROM residents $where_clause";
$count_stmt = $pdo->prepare($count_query);
$count_stmt->execute($params);
$total_residents = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_residents / $per_page);

// Get residents
$select_fields = "id, photo, first_name, middle_name, last_name, suffix, email, contact_number, 
         date_of_birth, gender, civil_status, created_at";
if ($deleted_at_exists) {
    $select_fields .= ", deleted_at";
}

$order_by = $deleted_at_exists ? "deleted_at DESC" : "created_at DESC";

$query = "SELECT $select_fields 
         FROM residents $where_clause 
         ORDER BY $order_by 
         LIMIT " . intval($per_page) . " OFFSET " . intval($offset);
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$residents = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$stats_query = "SELECT COUNT(*) as total_archived FROM residents";
if ($deleted_at_exists) {
    $stats_query .= " WHERE COALESCE(deleted_at, '') != ''";
} else {
    $stats_query .= " WHERE 1 = 0";
}
$stats = $pdo->query($stats_query)->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars(trans('nav_residents_archive')); ?> - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .main-content {
            flex: 1;
            margin-right: 280px;
            padding: 30px;
            transition: margin-right 0.3s ease;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #1f7a45;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .page-actions {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            justify-content: flex-end;
            flex-wrap: wrap;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
        }
        .btn-primary {
            background: linear-gradient(135deg, #1f7a45 0%, #156238 100%);
            color: white;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(21, 98, 56, 0.35);
            background: linear-gradient(135deg, #156238 0%, #0f4d2c 100%);
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #3c3;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
        }
        .stat-card .value {
            color: #87A96B;
            font-size: 32px;
            font-weight: bold;
        }
        .filters {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filters input[type="text"] {
            flex: 1;
            min-width: 200px;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
        }
        .filters button {
            padding: 12px 24px;
            background: #87A96B;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 600;
        }
        .filters button:hover {
            background: #7a9660;
        }
        .residents-table {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .table-header {
            background: #6c757d;
            color: white;
            padding: 15px 20px;
            font-weight: 600;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        thead {
            background: #f8f9fa;
        }
        th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: #2c3e50;
            border-bottom: 2px solid #e0e0e0;
        }
        td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        tbody tr:hover {
            background: #f8f9fa;
        }
        .resident-photo {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid #e0e0e0;
        }
        .resident-name {
            font-weight: 600;
            color: #2c3e50;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 20px;
            padding: 20px;
        }
        .pagination a, .pagination span {
            padding: 10px 15px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            text-decoration: none;
            color: #2c3e50;
        }
        .pagination a:hover {
            background: #87A96B;
            color: white;
            border-color: #87A96B;
        }
        .pagination .current {
            background: #87A96B;
            color: white;
            border-color: #87A96B;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>
    
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="3 6 5 6 21 6"></polyline>
                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                </svg>
            </span>
            <?php echo htmlspecialchars(trans('nav_residents_archive')); ?>
        </h1>

        <div class="page-actions">
            <a href="admin_residents.php" class="btn btn-primary">
                <?php echo htmlspecialchars(trans('nav_residents')); ?>
            </a>
            <a href="admin_residents_voters.php" class="btn btn-primary">
                <?php echo htmlspecialchars(trans('nav_residents_voters')); ?>
            </a>
            <a href="admin_residents_registered.php" class="btn btn-primary">
                <?php echo htmlspecialchars(trans('nav_residents_registered')); ?>
            </a>
        </div>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Archived Residents</h3>
                <div class="value"><?php echo number_format($stats['total_archived'] ?? 0); ?></div>
            </div>
        </div>

        <div class="filters">
            <form method="GET" action="" style="display: flex; gap: 15px; flex: 1; flex-wrap: wrap; align-items: center;">
                <input type="text" name="search" placeholder="Search by name, email, or contact..." value="<?php echo htmlspecialchars($search); ?>" style="flex: 1; min-width: 200px;">
                <button type="submit">Search</button>
                <?php if ($search): ?>
                    <a href="admin_residents_archive.php" style="padding: 12px 24px; background: #6c757d; color: white; border-radius: 8px; text-decoration: none; font-size: 14px; font-weight: 600;">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="residents-table">
            <div class="table-header">
                Archived Residents List (<?php echo number_format($total_residents); ?> total)
            </div>
            <?php if (empty($residents)): ?>
                <div class="empty-state">
                    <h3>No archived residents found</h3>
                    <p><?php echo $search ? 'Try adjusting your search criteria.' : 'No archived residents yet.'; ?></p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Date of Birth</th>
                            <th>Gender</th>
                            <th>Archived Date</th>
                            <th>Registered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($residents as $resident): 
                            $full_name = trim($resident['first_name'] . ' ' . ($resident['middle_name'] ?? '') . ' ' . $resident['last_name'] . ' ' . ($resident['suffix'] ?? ''));
                        ?>
                            <tr>
                                <td>
                                    <?php if (!empty($resident['photo']) && file_exists('../' . $resident['photo'])): ?>
                                        <img src="../<?php echo htmlspecialchars($resident['photo']); ?>" alt="<?php echo htmlspecialchars($full_name); ?>" class="resident-photo">
                                    <?php else: ?>
                                        <div class="resident-photo" style="background: #6c757d; color: white; display: flex; align-items: center; justify-content: center; font-weight: bold;">
                                            <?php echo strtoupper(substr($resident['first_name'], 0, 1)); ?>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="resident-name"><?php echo htmlspecialchars($full_name); ?></div>
                                </td>
                                <td><?php echo htmlspecialchars($resident['email'] ?? ''); ?></td>
                                <td><?php echo htmlspecialchars($resident['contact_number'] ?? 'N/A'); ?></td>
                                <td><?php echo $resident['date_of_birth'] ? date('M d, Y', strtotime($resident['date_of_birth'])) : 'N/A'; ?></td>
                                <td><?php echo htmlspecialchars($resident['gender'] ?? 'N/A'); ?></td>
                                <td><?php echo $resident['deleted_at'] ? date('M d, Y', strtotime($resident['deleted_at'])) : 'N/A'; ?></td>
                                <td><?php echo $resident['created_at'] ? date('M d, Y', strtotime($resident['created_at'])) : 'N/A'; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>">Previous</a>
                        <?php endif; ?>
                        
                        <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>">Next</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

