<?php
// admin/admin_officials.php
session_start();
require '../config.php';
require 'role_helper.php';

// Check if admin is logged in
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: admin_login.php');
    exit;
}

$admin_id = $_SESSION['user_id'];
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error']);
unset($_SESSION['success']);

// Get admin role for sidebar
$stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);
$admin_role = $admin['role'] ?? 'regular_admin';
$_SESSION['admin_role'] = $admin_role;

$officials_dir = __DIR__ . '/../data/officials';
if (!is_dir($officials_dir)) {
    mkdir($officials_dir, 0777, true);
}
$officials_file = $officials_dir . '/officials.json';

// Load officials
$officials = [];
if (file_exists($officials_file)) {
    $officials = json_decode(file_get_contents($officials_file), true) ?? [];
}
if (!is_array($officials)) {
    $officials = [];
}

// Initialize default officials if file is empty
if (empty($officials)) {
    $default_officials = [
        ['id' => 'off_pb_001', 'name' => 'Hon. Angelina S. Duguran', 'position' => 'Punong Barangay', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_001', 'name' => 'Hon. Valentin A. Destura Jr.', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_002', 'name' => 'Hon. Eduardo F. Batad', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 2, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_003', 'name' => 'Hon. Martin A. Pasumbal', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 3, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_004', 'name' => 'Hon. Allan D. Creencia', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 4, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_005', 'name' => 'Hon. Gorgonio A. Dimandal', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 5, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_006', 'name' => 'Hon. Herman Emil L. Batino', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 6, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kag_007', 'name' => 'Hon. Roderick S. Monzon', 'position' => 'Kagawad', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 7, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_sk_001', 'name' => 'Hon. Rachel Angela A. Danacay', 'position' => 'SK Chairperson', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_kalihim_001', 'name' => 'Evangeline B. Alvarez', 'position' => 'Kalihim', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_sec_001', 'name' => 'Aizel D. Derla', 'position' => 'Ingat-Yaman', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_cso_001', 'name' => 'Cherrie Ann Ame', 'position' => 'Kababaihan/CSO', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_cso_002', 'name' => 'Regino Villela', 'position' => 'Tau Gama/CSO', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_driver_001', 'name' => 'Mark P. Landicho', 'position' => 'Brgy. Driver', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_tanod_001', 'name' => 'Joerome Toledo', 'position' => 'Chief Tanod', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')],
        ['id' => 'off_bns_001', 'name' => 'Florinda Palabay', 'position' => 'BNS', 'contact' => '', 'email' => '', 'photo' => '', 'year_batch' => '', 'order' => 1, 'created_at' => date('Y-m-d H:i:s')]
    ];
    $officials = $default_officials;
    file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'create' || $action === 'edit') {
        $name = trim($_POST['name'] ?? '');
        $position = trim($_POST['position'] ?? '');
        $contact = trim($_POST['contact'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $order = intval($_POST['order'] ?? 0);
        $year_batch = trim($_POST['year_batch'] ?? '');
        
        if (!$name || !$position) {
            $_SESSION['error'] = 'Name and position are required.';
            header('Location: admin_officials.php');
            exit;
        }
        
        // Handle image upload
        $image_path = '';
        if (isset($_FILES['photo']) && is_uploaded_file($_FILES['photo']['tmp_name'])) {
            if ($_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = __DIR__ . '/../uploads/officials/';
                if (!is_dir($upload_dir)) {
                    if (!mkdir($upload_dir, 0777, true)) {
                        $_SESSION['error'] = 'Failed to create upload directory. Please check folder permissions.';
                        header('Location: admin_officials.php');
                        exit;
                    }
                }
                
                // Check file size (5MB max)
                $max_size = 5 * 1024 * 1024; // 5MB
                if ($_FILES['photo']['size'] > $max_size) {
                    $_SESSION['error'] = 'File size exceeds 5MB limit. Please upload a smaller image.';
                    header('Location: admin_officials.php');
                    exit;
                }
                
                $file_ext = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));
                $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                
                if (in_array($file_ext, $allowed_ext)) {
                    $new_filename = 'official_' . time() . '_' . uniqid() . '.' . $file_ext;
                    $upload_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                        $image_path = 'uploads/officials/' . $new_filename;
                    } else {
                        $_SESSION['error'] = 'Failed to upload image. Please check file permissions on uploads/officials/ folder.';
                        header('Location: admin_officials.php');
                        exit;
                    }
                } else {
                    $_SESSION['error'] = 'Invalid file type. Only JPG, PNG, GIF, and WEBP are allowed.';
                    header('Location: admin_officials.php');
                    exit;
                }
            } else {
                // Handle upload errors
                $upload_errors = [
                    UPLOAD_ERR_INI_SIZE => 'File exceeds upload_max_filesize directive in php.ini.',
                    UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE directive in HTML form.',
                    UPLOAD_ERR_PARTIAL => 'File was only partially uploaded.',
                    UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
                    UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder.',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
                    UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload.'
                ];
                $error_msg = $upload_errors[$_FILES['photo']['error']] ?? 'Unknown upload error (Error code: ' . $_FILES['photo']['error'] . ').';
                $_SESSION['error'] = 'Upload error: ' . $error_msg;
                header('Location: admin_officials.php');
                exit;
            }
        }
        
        if ($action === 'create') {
            $new_official = [
                'id' => uniqid('off_'),
                'name' => $name,
                'position' => $position,
                'contact' => $contact,
                'email' => $email,
                'photo' => $image_path,
                'order' => $order,
                'year_batch' => $year_batch,
                'created_at' => date('Y-m-d H:i:s'),
                'created_by' => $admin_id
            ];
            $officials[] = $new_official;
            $success = 'Official added successfully!';
        } else {
            // Edit existing
            $id = $_POST['id'] ?? '';
            $found = false;
            foreach ($officials as &$off) {
                if (isset($off['id']) && $off['id'] === $id) {
                    $off['name'] = $name;
                    $off['position'] = $position;
                    $off['contact'] = $contact;
                    $off['email'] = $email;
                    $off['order'] = $order;
                    $off['year_batch'] = $year_batch;
                    // Only update photo if a new one was uploaded
                    if ($image_path) {
                        // Delete old image if exists
                        if (!empty($off['photo']) && file_exists(__DIR__ . '/../' . $off['photo'])) {
                            @unlink(__DIR__ . '/../' . $off['photo']);
                        }
                        $off['photo'] = $image_path;
                    }
                    // If no new photo uploaded, keep the existing one (don't change $off['photo'])
                    $off['updated_at'] = date('Y-m-d H:i:s');
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $success = 'Official updated successfully!';
            } else {
                $_SESSION['error'] = 'Official not found.';
                header('Location: admin_officials.php');
                exit;
            }
        }
        
        // Save to file
        file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        $_SESSION['success'] = $success;
        header('Location: admin_officials.php');
        exit;
    } elseif ($action === 'delete') {
        // Check permission - only super admin can delete
        requirePermission('delete_official');
        
        $id = $_POST['id'] ?? '';
        $found = false;
        foreach ($officials as $key => $off) {
            if (isset($off['id']) && $off['id'] === $id) {
                // Delete image if exists
                if (!empty($off['photo']) && file_exists(__DIR__ . '/../' . $off['photo'])) {
                    unlink(__DIR__ . '/../' . $off['photo']);
                }
                unset($officials[$key]);
                $officials = array_values($officials);
                $found = true;
                break;
            }
        }
        if ($found) {
            file_put_contents($officials_file, json_encode($officials, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            $_SESSION['success'] = 'Official deleted successfully!';
        } else {
            $_SESSION['error'] = 'Official not found.';
        }
        header('Location: admin_officials.php');
        exit;
    }
}

// Sort officials by order, then by position hierarchy
$position_order = [
    'Punong Barangay' => 1,
    'Kagawad' => 2,
    'SK Chairperson' => 3,
    'Kalihim' => 4,
    'Ingat-Yaman' => 5,
    'Kababaihan/CSO' => 6,
    'Tau Gama/CSO' => 7,
    'Chief Tanod' => 8,
    'Brgy. Driver' => 9,
    'BNS' => 10
];

usort($officials, function($a, $b) use ($position_order) {
    $posA = $a['position'] ?? '';
    $posB = $b['position'] ?? '';
    $orderA = $position_order[$posA] ?? 999;
    $orderB = $position_order[$posB] ?? 999;
    
    if ($orderA !== $orderB) {
        return $orderA - $orderB;
    }
    
    return ($a['order'] ?? 0) - ($b['order'] ?? 0);
});

// Group by position for hierarchy display
$grouped_officials = [];
foreach ($officials as $off) {
    $pos = $off['position'] ?? 'Other';
    if (!isset($grouped_officials[$pos])) {
        $grouped_officials[$pos] = [];
    }
    $grouped_officials[$pos][] = $off;
}

// Common positions
$common_positions = [
    'Punong Barangay',
    'Kagawad',
    'SK Chairperson',
    'Kalihim',
    'Ingat-Yaman',
    'Kababaihan/CSO',
    'Tau Gama/CSO',
    'Chief Tanod',
    'Brgy. Driver',
    'BNS',
    'Other'
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barangay Officials - Barangay San Vicente II</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
            background: #f5f7f3;
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            width: 280px;
            background: #87A96B;
            color: #000;
            padding: 25px;
            position: fixed;
            right: 0;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            box-shadow: -2px 0 10px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            transition: transform 0.3s ease-in-out;
            z-index: 1000;
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .manage-account-btn {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.1);
            border: 2px solid rgba(0,0,0,0.2);
            border-radius: 8px;
            color: #000;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
            text-decoration: none;
            display: block;
            text-align: center;
        }
        .manage-account-btn:hover {
            background: rgba(0,0,0,0.15);
            border-color: rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a svg {
            flex-shrink: 0;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        /* Submenu */
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(0,0,0,0.6);
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .sidebar-logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            border: 3px solid rgba(0, 0, 0, 0.2);
            object-fit: cover;
            margin-bottom: 10px;
        }
        .sidebar-logo h2 {
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 5px;
            color: #000;
        }
        .sidebar-logo p {
            font-size: 12px;
            color: #000;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-menu li {
            margin-bottom: 5px;
        }
        .nav-menu li:has(.manage-account-btn) {
            margin-bottom: 5px;
        }
        .nav-menu > li > a {
            display: flex;
            align-items: center;
            padding: 14px 18px;
            color: #000;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
            font-size: 16px;
            font-weight: 500;
        }
        .nav-menu > li > a:hover {
            background: rgba(0,0,0,0.1);
            color: #000;
        }
        .nav-menu > li > a.active {
            background: rgba(0,0,0,0.15);
            color: #000;
            font-weight: 600;
        }
        .nav-menu a .arrow-icon {
            margin-left: auto;
            font-size: 14px;
            opacity: 0.7;
            transition: transform 0.3s;
        }
        .nav-menu li.has-submenu.active > a .arrow-icon {
            transform: rotate(90deg);
        }
        .submenu {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s ease-out, opacity 0.3s ease-out;
            opacity: 0;
            margin-left: 20px;
            margin-top: 5px;
        }
        .nav-menu li.has-submenu.active .submenu {
            max-height: 500px;
            opacity: 1;
            transition: max-height 0.4s ease-in, opacity 0.3s ease-in;
        }
        .submenu li {
            margin-bottom: 3px;
        }
        .submenu a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
            color: #000;
            opacity: 0.8;
            text-decoration: none;
            border-radius: 6px;
            transition: all 0.3s;
            font-size: 14px;
            font-weight: 500;
            position: relative;
            padding-left: 35px;
        }
        .submenu a::before {
            content: '';
            position: absolute;
            left: 15px;
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: rgba(0,0,0,0.4);
            transition: all 0.3s;
        }
        .submenu a:hover,
        .submenu a.active {
            background: rgba(0,0,0,0.1);
            color: #000;
            opacity: 1;
        }
        .submenu a.active::before {
            background: rgba(245, 245, 220, 0.8);
            box-shadow: 0 0 8px rgba(245, 245, 220, 0.4);
        }
        .logout-btn {
            width: 100%;
            padding: 14px;
            background: #c33;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        .logout-btn:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        .sidebar-toggle {
            position: absolute;
            top: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.1);
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 1001;
        }
        .sidebar-toggle:hover {
            background: rgba(0, 0, 0, 0.2);
            border-color: rgba(0, 0, 0, 0.3);
            transform: scale(1.05);
            color: #fff;
        }
        .sidebar-toggle svg {
            width: 18px;
            height: 18px;
            transition: transform 0.3s;
        }
        .sidebar.hidden {
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
        }
        .sidebar-toggle-float {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #87A96B;
            border: 2px solid rgba(0, 0, 0, 0.2);
            border-radius: 8px;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            z-index: 999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            color: #000;
        }
        .sidebar-toggle-float:hover {
            background: #7a9660;
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            color: #fff;
        }
        .sidebar-toggle-float svg {
            width: 20px;
            height: 20px;
        }
        body.sidebar-hidden .sidebar-toggle-float {
            display: flex !important;
        }
        /* Main Content */
        .main-content {
            margin-right: 280px;
            padding: 30px;
            width: calc(100% - 280px);
            transition: margin-right 0.3s ease-in-out, width 0.3s ease-in-out;
        }
        body.sidebar-hidden .main-content {
            margin-right: 0 !important;
            width: 100% !important;
        }
        .page-title {
            font-size: 36px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 20px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .page-title-bar {
            width: 4px;
            height: 30px;
            background: rgba(212, 175, 55, 0.6);
            flex-shrink: 0;
        }
        .page-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            flex-shrink: 0;
        }
        .page-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .row-container {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .section-title {
            font-size: 26px;
            font-weight: 800;
            color: #2c3e2d;
            margin-bottom: 6px;
            margin-top: 20px;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .row-container > .section-title:first-child {
            margin-top: 0;
        }
        .section-description {
            color: #6b7280;
            font-size: 18px;
            margin-bottom: 16px;
            font-weight: 600;
        }
        .section-title-icon {
            width: 20px;
            height: 20px;
            color: #2c3e2d;
            opacity: 0.6;
            flex-shrink: 0;
        }
        .section-title-icon svg {
            width: 100%;
            height: 100%;
            display: block;
        }
        .btn-primary {
            padding: 12px 24px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .error {
            background: #fee;
            color: #c33;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #c33;
        }
        .success {
            background: #efe;
            color: #3c3;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 13px;
            border-left: 3px solid #3c3;
        }
        /* Hierarchy Display */
        .hierarchy-container {
            display: flex;
            flex-direction: column;
            gap: 30px;
            align-items: center;
        }
        .hierarchy-top {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            width: 100%;
            max-width: 400px;
            text-align: center;
            transition: all 0.2s ease;
        }
        .hierarchy-top:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .hierarchy-level {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 30px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            width: 100%;
            transition: all 0.2s ease;
        }
        .hierarchy-level:hover {
            border-color: #9ca3af;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .level-header {
            font-size: 26px;
            color: #2c3e2d;
            margin-bottom: 15px;
            font-weight: 800;
            letter-spacing: -0.3px;
            display: flex;
            align-items: center;
            gap: 8px;
            text-align: left;
        }
        .officials-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 25px;
        }
        .kagawad-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            width: 100%;
        }
        .kagawad-column {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .hierarchy-connector {
            width: 2px;
            height: 40px;
            background: #87A96B;
            margin: 0 auto;
            position: relative;
            opacity: 0.5;
        }
        .hierarchy-connector::before {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 0;
            height: 0;
            border-left: 10px solid transparent;
            border-right: 10px solid transparent;
            border-top: 10px solid #87A96B;
            opacity: 0.5;
        }
        .official-card {
            text-align: center;
            padding: 25px;
            background: rgba(255, 255, 255, 0.5);
            border-radius: 8px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            transition: all 0.2s ease;
            position: relative;
        }
        .official-card:hover {
            border-color: #87A96B;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }
        .official-photo {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center;
            border: 2px solid #e5e7eb;
            margin: 0 auto 15px;
            display: block;
            background: #f3f4f6;
            aspect-ratio: 1 / 1;
        }
        .official-photo img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            object-position: center;
        }
        .official-name {
            font-size: 18px;
            font-weight: 700;
            color: #2c3e2d;
            margin-bottom: 8px;
        }
        .official-position {
            font-size: 16px;
            color: #6b7280;
            margin-bottom: 8px;
            font-weight: 500;
        }
        .official-year-batch {
            display: inline-block;
            padding: 4px 12px;
            background: rgba(255, 255, 255, 0.7);
            color: #6b7280;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 12px;
        }
        .official-contact {
            font-size: 14px;
            color: #6b7280;
            font-weight: 500;
            margin-bottom: 5px;
        }
        .official-actions {
            display: flex;
            gap: 8px;
            margin-top: 15px;
            justify-content: center;
        }
        .btn-edit, .btn-delete {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-edit {
            background: #d4af37;
            color: white;
        }
        .btn-edit:hover {
            background: #e6c55a;
            transform: translateY(-2px);
        }
        .btn-delete {
            background: #c33;
            color: white;
        }
        .btn-delete:hover {
            background: #a22;
            transform: translateY(-2px);
        }
        /* Modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .modal.show {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .modal-content {
            background: #E8F0E4;
            background-image: 
                linear-gradient(rgba(255, 255, 255, 0.3) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.3) 1px, transparent 1px);
            background-size: 40px 40px;
            border-radius: 8px;
            border: 1px solid #e5e7eb;
            padding: 35px;
            width: 100%;
            max-width: 600px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
            position: relative;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.1);
        }
        .modal-header h2 {
            font-size: 26px;
            color: #2c3e2d;
            font-weight: 800;
            letter-spacing: -0.3px;
        }
        .close-modal {
            background: none;
            border: none;
            font-size: 28px;
            color: #999;
            cursor: pointer;
            transition: color 0.3s;
        }
        .close-modal:hover {
            color: #c33;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #2c3e2d;
            font-weight: 700;
            font-size: 16px;
        }
        .form-group input,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
            background: #fafafa;
            font-family: inherit;
        }
        .form-group input:focus,
        .form-group select:focus {
            outline: none;
            border-color: #d4af37;
            background: #fff;
            box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.1);
        }
        .photo-preview-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .photo-preview {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            object-position: center;
            border: 2px solid #e5e7eb;
            margin: 0 auto;
            display: block;
            aspect-ratio: 1 / 1;
        }
        .form-group input[type="file"] {
            padding: 8px;
        }
        .modal-actions {
            display: flex;
            gap: 10px;
            margin-top: 25px;
        }
        .btn-cancel {
            flex: 1;
            padding: 12px;
            background: #e0e0e0;
            color: #333;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-cancel:hover {
            background: #d0d0d0;
        }
        .btn-submit {
            flex: 1;
            padding: 12px;
            background: #2c3e2d;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(44, 62, 45, 0.3);
            background: #1a2e1b;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        .empty-state-icon {
            font-size: 64px;
            margin-bottom: 20px;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            .main-content {
                margin-right: 0;
                width: 100%;
                padding: 20px;
            }
            .officials-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            .kagawad-container {
                grid-template-columns: 1fr;
            }
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <?php include 'admin_dashboard_sidebar.php'; ?>

    <!-- Main Content -->
    <div class="main-content">
        <h1 class="page-title">
            <span class="page-title-bar"></span>
            <span class="page-title-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                    <circle cx="9" cy="7" r="4"></circle>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                </svg>
            </span>
            Barangay Officials
        </h1>

        <?php if ($error): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if (empty($officials)): ?>
            <div class="row-container">
            <div class="empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="width: 80px; height: 80px; margin: 0 auto 20px; opacity: 0.3; color: #9ca3af;">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                    <h3 style="color: #2c3e2d; margin-bottom: 10px;">No Officials Added Yet</h3>
                    <p style="color: #6b7280;">Add barangay officials to display the organizational structure.</p>
                </div>
            </div>
        <?php else: ?>
            <div class="row-container">
            <div class="hierarchy-container">
                <?php
                // Separate Punong Barangay
                $punong_barangay = [];
                $kagawad = [];
                $other_officials = [];
                
                foreach ($officials as $off) {
                    $pos = $off['position'] ?? '';
                    if ($pos === 'Punong Barangay') {
                        $punong_barangay[] = $off;
                    } elseif ($pos === 'Kagawad') {
                        $kagawad[] = $off;
                    } else {
                        if (!isset($other_officials[$pos])) {
                            $other_officials[$pos] = [];
                        }
                        $other_officials[$pos][] = $off;
                    }
                }
                ?>
                
                <!-- Punong Barangay at Top -->
                <?php if (!empty($punong_barangay)): ?>
                    <div class="hierarchy-top">
                        <?php foreach ($punong_barangay as $off): ?>
                            <?php 
                            $photo_path = isset($off['photo']) ? trim($off['photo']) : '';
                            $has_photo = !empty($photo_path);
                            ?>
                            <?php if ($has_photo): ?>
                                <img src="../<?php echo htmlspecialchars($photo_path); ?>" alt="<?php echo htmlspecialchars($off['name']); ?>" class="official-photo" style="width: 150px; height: 150px; margin: 0 auto 15px; border-radius: 50%; object-fit: cover; object-position: center; border: 2px solid #e5e7eb; aspect-ratio: 1 / 1;">
                            <?php else: ?>
                                <div class="official-photo" style="width: 150px; height: 150px; margin: 0 auto 15px; display: flex; align-items: center; justify-content: center; background: #2c3e2d; color: white; font-size: 64px; font-weight: 700; border-radius: 50%; border: 2px solid #e5e7eb; aspect-ratio: 1 / 1;">
                                    <?php echo strtoupper(substr($off['name'], 0, 1)); ?>
                                </div>
                            <?php endif; ?>
                            <div class="official-name" style="font-size: 22px; margin-bottom: 8px; font-weight: 700; color: #2c3e2d;"><?php echo htmlspecialchars($off['name']); ?></div>
                            <div class="official-position" style="font-size: 18px; color: #6b7280; font-weight: 500; margin-bottom: 8px;"><?php echo htmlspecialchars($off['position']); ?></div>
                            <?php if (!empty($off['year_batch'])): ?>
                                <div class="official-year-batch">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                        <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                    </svg>
                                    <?php echo htmlspecialchars($off['year_batch']); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($off['contact'])): ?>
                                <div class="official-contact">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                        <path d="M3 3l3 2 2-2 4 4-2 2 2 3-3 3c-2 0-5-3-5-5l3-3-2-2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <?php echo htmlspecialchars($off['contact']); ?>
                                </div>
                            <?php endif; ?>
                            <?php if (!empty($off['email'])): ?>
                                <div class="official-contact">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                        <rect x="2" y="3" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M2 4l6 4 6-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                    </svg>
                                    <?php echo htmlspecialchars($off['email']); ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (!empty($kagawad) || !empty($other_officials)): ?>
                        <div class="hierarchy-connector"></div>
                    <?php endif; ?>
                <?php endif; ?>
                
                <!-- Kagawad in Two Columns -->
                <?php if (!empty($kagawad)): ?>
                    <div class="hierarchy-level">
                        <h2 class="level-header">Sangguniang Barangay (<?php echo count($kagawad); ?>)</h2>
                        <div class="kagawad-container">
                            <div class="kagawad-column">
                                <?php 
                                $midpoint = ceil(count($kagawad) / 2);
                                $left_kagawad = array_slice($kagawad, 0, $midpoint);
                                foreach ($left_kagawad as $off): 
                                ?>
                                    <div class="official-card">
                                        <?php 
                                        $photo_path = isset($off['photo']) ? trim($off['photo']) : '';
                                        $has_photo = !empty($photo_path);
                                        ?>
                                        <?php if ($has_photo): ?>
                                            <img src="../<?php echo htmlspecialchars($photo_path); ?>" alt="<?php echo htmlspecialchars($off['name']); ?>" class="official-photo">
                                        <?php else: ?>
                                            <div class="official-photo" style="display: flex; align-items: center; justify-content: center; background: #2c3e2d; color: white; font-size: 48px; font-weight: 700; border-radius: 50%; aspect-ratio: 1 / 1;">
                                                <?php echo strtoupper(substr($off['name'], 0, 1)); ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="official-name"><?php echo htmlspecialchars($off['name']); ?></div>
                                        <div class="official-position"><?php echo htmlspecialchars($off['position']); ?></div>
                                        <?php if (!empty($off['year_batch'])): ?>
                                            <div class="official-year-batch">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                        <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                    </svg>
                                    <?php echo htmlspecialchars($off['year_batch']); ?>
                                </div>
                                        <?php endif; ?>
                                        <?php if (!empty($off['contact'])): ?>
                                            <div class="official-contact">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                                    <path d="M3 3l3 2 2-2 4 4-2 2 2 3-3 3c-2 0-5-3-5-5l3-3-2-2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <?php echo htmlspecialchars($off['contact']); ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($off['email'])): ?>
                                            <div class="official-contact">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                                    <rect x="2" y="3" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                                    <path d="M2 4l6 4 6-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <?php echo htmlspecialchars($off['email']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <div class="kagawad-column">
                                <?php 
                                $right_kagawad = array_slice($kagawad, $midpoint);
                                foreach ($right_kagawad as $off): 
                                ?>
                                    <div class="official-card">
                                        <?php 
                                        $photo_path = isset($off['photo']) ? trim($off['photo']) : '';
                                        $has_photo = !empty($photo_path);
                                        ?>
                                        <?php if ($has_photo): ?>
                                            <img src="../<?php echo htmlspecialchars($photo_path); ?>" alt="<?php echo htmlspecialchars($off['name']); ?>" class="official-photo">
                                        <?php else: ?>
                                            <div class="official-photo" style="display: flex; align-items: center; justify-content: center; background: #2c3e2d; color: white; font-size: 48px; font-weight: 700; border-radius: 50%; aspect-ratio: 1 / 1;">
                                                <?php echo strtoupper(substr($off['name'], 0, 1)); ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="official-name"><?php echo htmlspecialchars($off['name']); ?></div>
                                        <div class="official-position"><?php echo htmlspecialchars($off['position']); ?></div>
                                        <?php if (!empty($off['year_batch'])): ?>
                                            <div class="official-year-batch">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                        <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                    </svg>
                                    <?php echo htmlspecialchars($off['year_batch']); ?>
                                </div>
                                        <?php endif; ?>
                                        <?php if (!empty($off['contact'])): ?>
                                            <div class="official-contact">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                                    <path d="M3 3l3 2 2-2 4 4-2 2 2 3-3 3c-2 0-5-3-5-5l3-3-2-2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <?php echo htmlspecialchars($off['contact']); ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($off['email'])): ?>
                                            <div class="official-contact">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                                    <rect x="2" y="3" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                                    <path d="M2 4l6 4 6-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <?php echo htmlspecialchars($off['email']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
                <!-- Other Officials -->
                <?php if (!empty($other_officials)): ?>
                    <?php foreach ($other_officials as $position => $position_officials): ?>
                        <div class="hierarchy-level">
                            <h2 class="level-header"><?php echo htmlspecialchars($position); ?> <span style="font-size: 18px; color: #6b7280; font-weight: 600;">(<?php echo count($position_officials); ?>)</span></h2>
                            <div class="officials-grid">
                                <?php foreach ($position_officials as $off): ?>
                                    <div class="official-card">
                                        <?php 
                                        $photo_path = isset($off['photo']) ? trim($off['photo']) : '';
                                        $has_photo = !empty($photo_path);
                                        ?>
                                        <?php if ($has_photo): ?>
                                            <img src="../<?php echo htmlspecialchars($photo_path); ?>" alt="<?php echo htmlspecialchars($off['name']); ?>" class="official-photo">
                                        <?php else: ?>
                                            <div class="official-photo" style="display: flex; align-items: center; justify-content: center; background: #2c3e2d; color: white; font-size: 48px; font-weight: 700; border-radius: 50%; aspect-ratio: 1 / 1;">
                                                <?php echo strtoupper(substr($off['name'], 0, 1)); ?>
                                            </div>
                                        <?php endif; ?>
                                        <div class="official-name"><?php echo htmlspecialchars($off['name']); ?></div>
                                        <div class="official-position"><?php echo htmlspecialchars($off['position']); ?></div>
                                        <?php if (!empty($off['year_batch'])): ?>
                                            <div class="official-year-batch">
                                    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                        <rect x="3" y="3" width="10" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                        <path d="M3 7h10M6 3v4M10 3v4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                    </svg>
                                    <?php echo htmlspecialchars($off['year_batch']); ?>
                                </div>
                                        <?php endif; ?>
                                        <?php if (!empty($off['contact'])): ?>
                                            <div class="official-contact">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                                    <path d="M3 3l3 2 2-2 4 4-2 2 2 3-3 3c-2 0-5-3-5-5l3-3-2-2z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <?php echo htmlspecialchars($off['contact']); ?>
                                            </div>
                                        <?php endif; ?>
                                        <?php if (!empty($off['email'])): ?>
                                            <div class="official-contact">
                                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg" style="display: inline-block; vertical-align: middle; margin-right: 6px;">
                                                    <rect x="2" y="3" width="12" height="10" rx="1" stroke="currentColor" stroke-width="1.5"/>
                                                    <path d="M2 4l6 4 6-4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                                <?php echo htmlspecialchars($off['email']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Create/Edit Modal -->
    <div id="officialModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 id="modalTitle">Add Official</h2>
                <button class="close-modal" onclick="closeModal()">
                    <svg width="24" height="24" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
            <form id="officialForm" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" id="formAction" value="create">
                <input type="hidden" name="id" id="officialId">
                
                <div class="photo-preview-container">
                    <img id="photoPreview" class="photo-preview" style="display: none;">
                    <div id="photoPlaceholder" class="photo-preview" style="display: flex; align-items: center; justify-content: center; background: #2c3e2d; color: white; font-size: 48px; font-weight: 700; border-radius: 50%; aspect-ratio: 1 / 1;">?</div>
                </div>

                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" required placeholder="e.g., Hon. Angelina S. Duguran">
                </div>

                <div class="form-group">
                    <label for="position">Position *</label>
                    <select id="position" name="position" required>
                        <option value="">-- Select Position --</option>
                        <?php foreach ($common_positions as $pos): ?>
                            <option value="<?php echo htmlspecialchars($pos); ?>"><?php echo htmlspecialchars($pos); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="contact">Contact Number</label>
                    <input type="text" id="contact" name="contact" placeholder="e.g., 09123456789">
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="e.g., official@barangay.gov.ph">
                </div>

                <div class="form-group">
                    <label for="year_batch">Year/Batch</label>
                    <input type="text" id="year_batch" name="year_batch" placeholder="e.g., 2023-2025, Batch 2023, or 2 years">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Enter term period, batch year, or years in service</small>
                </div>

                <div class="form-group">
                    <label for="order">Display Order</label>
                    <input type="number" id="order" name="order" value="0" min="0" placeholder="Lower number appears first">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Set order for officials with the same position (0 = default)</small>
                </div>

                <div class="form-group">
                    <label for="photo">Profile Photo</label>
                    <input type="file" id="photo" name="photo" accept="image/jpeg,image/jpg,image/png,image/gif,image/webp" onchange="previewPhoto(this)">
                    <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">Max file size: 5MB. Supported formats: JPG, PNG, GIF, WEBP</small>
                </div>

                <div class="modal-actions">
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                    <button type="submit" class="btn-submit">Save</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Form -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="deleteId">
    </form>

    <script>
        function toggleSubmenu(event, element) {
            event.preventDefault();
            element.classList.toggle('active');
        }
        
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const body = document.body;
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar) {
                sidebar.classList.toggle('hidden');
                body.classList.toggle('sidebar-hidden');
                
                if (toggleFloat) {
                    if (sidebar.classList.contains('hidden')) {
                        toggleFloat.style.display = 'flex';
                    } else {
                        toggleFloat.style.display = 'none';
                    }
                }
            }
        }
        
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const toggleFloat = document.getElementById('sidebarToggleFloat');
            
            if (sidebar && !sidebar.classList.contains('hidden') && toggleFloat) {
                toggleFloat.style.display = 'none';
            }
        });

        function openCreateModal() {
            document.getElementById('modalTitle').textContent = 'Add Official';
            document.getElementById('formAction').value = 'create';
            document.getElementById('officialForm').reset();
            document.getElementById('officialId').value = '';
            document.getElementById('order').value = '0';
            document.getElementById('photo').value = '';
            document.getElementById('photoPreview').style.display = 'none';
            document.getElementById('photoPlaceholder').style.display = 'flex';
            document.getElementById('photoPlaceholder').textContent = '?';
            document.getElementById('officialModal').classList.add('show');
        }

        function openEditModal(official) {
            document.getElementById('modalTitle').textContent = 'Edit Official';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('officialId').value = official.id;
            document.getElementById('name').value = official.name || '';
            document.getElementById('position').value = official.position || '';
            document.getElementById('contact').value = official.contact || '';
            document.getElementById('email').value = official.email || '';
            document.getElementById('year_batch').value = official.year_batch || '';
            document.getElementById('order').value = official.order || 0;
            
            if (official.photo) {
                document.getElementById('photoPreview').src = '../' + official.photo;
                document.getElementById('photoPreview').style.display = 'block';
                document.getElementById('photoPlaceholder').style.display = 'none';
            } else {
                document.getElementById('photoPreview').style.display = 'none';
                document.getElementById('photoPlaceholder').style.display = 'flex';
                document.getElementById('photoPlaceholder').textContent = (official.name || '?').charAt(0).toUpperCase();
            }
            
            document.getElementById('officialModal').classList.add('show');
        }

        function closeModal() {
            document.getElementById('officialModal').classList.remove('show');
        }

        function previewPhoto(input) {
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('photoPreview').src = e.target.result;
                    document.getElementById('photoPreview').style.display = 'block';
                    document.getElementById('photoPlaceholder').style.display = 'none';
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        function deleteOfficial(id) {
            if (confirm('Are you sure you want to delete this official?')) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }

        // Update photo placeholder when name changes
        document.getElementById('name').addEventListener('input', function() {
            if (!document.getElementById('photoPreview').style.display || document.getElementById('photoPreview').style.display === 'none') {
                const initial = this.value.charAt(0).toUpperCase() || '?';
                document.getElementById('photoPlaceholder').textContent = initial;
            }
        });

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('officialModal');
            if (event.target === modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>

